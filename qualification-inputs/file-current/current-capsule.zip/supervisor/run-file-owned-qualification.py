#!/usr/bin/env python3
"""Source-only until reviewed: root/delegated Linux cgroup-v2 finite File lane.

No global process cleanup, container pruning, persistent volume deletion or token
handling. Unresolved cleanup retains the exact group, claim and durable evidence.
"""
import datetime as dt
from contextlib import contextmanager
import hashlib
import base64
import io
import zipfile
import http.client
import json
import os
import re
from pathlib import Path
import select
import signal
import stat
import shutil
import socket
import sys
import time
import uuid
import xml.etree.ElementTree as ET
from urllib.parse import quote

from file_native_admission import admission, consume_once

OWNER = 'file-native-qualification-20261008'
FIXED_FOCUSED_FILTER = 'FullyQualifiedName=Legacy.Maliev.FileService.Tests.Integration.LegacyFileConsumerWriteHttpBoundaryTests.CustomPrefix_PromotesLiteralLowercaseKeyWithoutSelectingCanonicalDecoy|FullyQualifiedName=Legacy.Maliev.FileService.Tests.Integration.LegacyFileConsumerWriteHttpBoundaryTests.CustomPrefix_RawControlRejectsBeforeQuarantineOrProvider|FullyQualifiedName=Legacy.Maliev.FileService.Tests.Integration.LegacyFileConsumerWriteHttpBoundaryTests.CustomPrefix_BatchProgressivelyCleansAndReconcilesOrderedLiteralKeys|FullyQualifiedName=Legacy.Maliev.FileService.Tests.Integration.LegacyFileMoveHttpBoundaryTests.LiteralSource_MissingAliasNeverMovesNormalizedDecoy|FullyQualifiedName=Legacy.Maliev.FileService.Tests.Integration.LegacyFileMoveHttpBoundaryTests.LiteralDestination_PreservesExactSdkMetadataAndJournalIdentity|FullyQualifiedName=Legacy.Maliev.FileService.Tests.Integration.LegacyFileMoveHttpBoundaryTests.LiteralDelete_MissingAliasNeverDeletesNormalizedDecoy|FullyQualifiedName=Legacy.Maliev.FileService.Tests.Integration.LegacyFileMoveHttpBoundaryTests.LiteralControlPrefix_RejectsBeforeAnySdkOrJournalMutation|FullyQualifiedName=Legacy.Maliev.FileService.Tests.Application.FileApplicationServiceTests.DeleteAsync_LiteralAndNormalizedObjectsExist_DeletesOnlyLiteral|FullyQualifiedName=Legacy.Maliev.FileService.Tests.Integration.LegacyFileConsumerWriteHttpBoundaryTests.RepeatedBasenames_IndependentPrivateAuthoritySurvivesReadMoveDeleteAndRecovery|FullyQualifiedName=Legacy.Maliev.FileService.Tests.Integration.LegacyFileConsumerWriteHttpBoundaryTests.LegacyQuarantineLayout_CanonicalRecoveryAcceptedLiteralAliasRejected|FullyQualifiedName=Legacy.Maliev.FileService.Tests.Integration.LegacyFileConsumerWriteHttpBoundaryTests.LiteralKeyedPrefix_ExactReplayConflictAndRecoveryNeverReupload|FullyQualifiedName=Legacy.Maliev.FileService.Tests.Integration.LegacyReplayPrincipalHttpBoundaryTests.OlderNoncanonicalCheckpoint_ConflictsWithoutReturningAliasOrRewritingDurableState|FullyQualifiedName=Legacy.Maliev.FileService.Tests.Infrastructure.OwnedRedisLeaseTests.Settlement_StartupBlocksConsumerObservation|FullyQualifiedName=Legacy.Maliev.FileService.Tests.Infrastructure.OwnedRedisLeaseTests.Settlement_ConsumerBlocksCleanupAfterStartup|FullyQualifiedName=Legacy.Maliev.FileService.Tests.Infrastructure.OwnedRedisLeaseTests.Settlement_ExpiredStartupDoesNotObserveConsumerOrClaimSettlement|FullyQualifiedName=Legacy.Maliev.FileService.Tests.Infrastructure.OwnedRedisLeaseTests.Settlement_ExpiredConsumerRemainsUnsettled|FullyQualifiedName=Legacy.Maliev.FileService.Tests.Infrastructure.OwnedRedisLeaseTests.Admission_CurrentOwnerAssemblyAndFiniteSlot_Accepts|FullyQualifiedName=Legacy.Maliev.FileService.Tests.Infrastructure.OwnedRedisLeaseTests.Admission_InvalidOwnerLeaseRejectsBeforeAllocation|FullyQualifiedName=Legacy.Maliev.FileService.Tests.Infrastructure.OwnedRedisLeaseTests.Resource_ExactEphemeralIdentity_Accepts|FullyQualifiedName=Legacy.Maliev.FileService.Tests.Infrastructure.OwnedRedisLeaseTests.Resource_ChangedOwnershipMountOrClientSurfaceRejectsCleanup|FullyQualifiedName=Legacy.Maliev.FileService.Tests.Infrastructure.OwnedRedisLeaseTests.ClientProbe_OnlyItsOwnLoopbackObserver_Accepts|FullyQualifiedName=Legacy.Maliev.FileService.Tests.Infrastructure.OwnedRedisLeaseTests.ClientProbe_UnknownOrNonquiescentReadershipRejectsCleanup'
LIMIT = 32 * 1024 * 1024
FOCUSED_INVENTORY = {'Legacy.Maliev.FileService.Tests.Integration.LegacyFileConsumerWriteHttpBoundaryTests.CustomPrefix_PromotesLiteralLowercaseKeyWithoutSelectingCanonicalDecoy': 5, 'Legacy.Maliev.FileService.Tests.Integration.LegacyFileConsumerWriteHttpBoundaryTests.CustomPrefix_RawControlRejectsBeforeQuarantineOrProvider': 3, 'Legacy.Maliev.FileService.Tests.Integration.LegacyFileConsumerWriteHttpBoundaryTests.CustomPrefix_BatchProgressivelyCleansAndReconcilesOrderedLiteralKeys': 6, 'Legacy.Maliev.FileService.Tests.Integration.LegacyFileMoveHttpBoundaryTests.LiteralSource_MissingAliasNeverMovesNormalizedDecoy': 2, 'Legacy.Maliev.FileService.Tests.Integration.LegacyFileMoveHttpBoundaryTests.LiteralDestination_PreservesExactSdkMetadataAndJournalIdentity': 2, 'Legacy.Maliev.FileService.Tests.Integration.LegacyFileMoveHttpBoundaryTests.LiteralDelete_MissingAliasNeverDeletesNormalizedDecoy': 2, 'Legacy.Maliev.FileService.Tests.Integration.LegacyFileMoveHttpBoundaryTests.LiteralControlPrefix_RejectsBeforeAnySdkOrJournalMutation': 12, 'Legacy.Maliev.FileService.Tests.Application.FileApplicationServiceTests.DeleteAsync_LiteralAndNormalizedObjectsExist_DeletesOnlyLiteral': 2, 'Legacy.Maliev.FileService.Tests.Integration.LegacyFileConsumerWriteHttpBoundaryTests.RepeatedBasenames_IndependentPrivateAuthoritySurvivesReadMoveDeleteAndRecovery': 4, 'Legacy.Maliev.FileService.Tests.Integration.LegacyFileConsumerWriteHttpBoundaryTests.LegacyQuarantineLayout_CanonicalRecoveryAcceptedLiteralAliasRejected': 2, 'Legacy.Maliev.FileService.Tests.Integration.LegacyFileConsumerWriteHttpBoundaryTests.LiteralKeyedPrefix_ExactReplayConflictAndRecoveryNeverReupload': 5, 'Legacy.Maliev.FileService.Tests.Integration.LegacyReplayPrincipalHttpBoundaryTests.OlderNoncanonicalCheckpoint_ConflictsWithoutReturningAliasOrRewritingDurableState': 14, 'Legacy.Maliev.FileService.Tests.Infrastructure.OwnedRedisLeaseTests.Settlement_StartupBlocksConsumerObservation': 1, 'Legacy.Maliev.FileService.Tests.Infrastructure.OwnedRedisLeaseTests.Settlement_ConsumerBlocksCleanupAfterStartup': 1, 'Legacy.Maliev.FileService.Tests.Infrastructure.OwnedRedisLeaseTests.Settlement_ExpiredStartupDoesNotObserveConsumerOrClaimSettlement': 1, 'Legacy.Maliev.FileService.Tests.Infrastructure.OwnedRedisLeaseTests.Settlement_ExpiredConsumerRemainsUnsettled': 1, 'Legacy.Maliev.FileService.Tests.Infrastructure.OwnedRedisLeaseTests.Admission_CurrentOwnerAssemblyAndFiniteSlot_Accepts': 1, 'Legacy.Maliev.FileService.Tests.Infrastructure.OwnedRedisLeaseTests.Admission_InvalidOwnerLeaseRejectsBeforeAllocation': 10, 'Legacy.Maliev.FileService.Tests.Infrastructure.OwnedRedisLeaseTests.Resource_ExactEphemeralIdentity_Accepts': 1, 'Legacy.Maliev.FileService.Tests.Infrastructure.OwnedRedisLeaseTests.Resource_ChangedOwnershipMountOrClientSurfaceRejectsCleanup': 14, 'Legacy.Maliev.FileService.Tests.Infrastructure.OwnedRedisLeaseTests.ClientProbe_OnlyItsOwnLoopbackObserver_Accepts': 1, 'Legacy.Maliev.FileService.Tests.Infrastructure.OwnedRedisLeaseTests.ClientProbe_UnknownOrNonquiescentReadershipRejectsCleanup': 6}
SDK_SECONDS = 600
CGROUP_ROOT = Path('/sys/fs/cgroup')
SOCKET_IDENTITY = None
RPC_DEADLINE = None
PROJECT_PATHS = {f'Legacy.Maliev.FileService.{name}/Legacy.Maliev.FileService.{name}.csproj'
                 for name in ('Api', 'Application', 'Data', 'Domain', 'Tests')}

@contextmanager
def registration_window():
    """Defer handled cancellation only until a syscall result has an owner."""
    previous = signal.pthread_sigmask(signal.SIG_BLOCK, {signal.SIGINT, signal.SIGTERM})
    try:
        yield previous
    finally:
        signal.pthread_sigmask(signal.SIG_SETMASK, previous)

def guard_child_parent(parent, previous_mask, libc=None):
    import ctypes
    libc = libc if libc is not None else ctypes.CDLL(None, use_last_error=True)
    libc.prctl.argtypes = [ctypes.c_int, *([ctypes.c_ulong] * 4)]
    libc.prctl.restype = ctypes.c_int
    # setuid clears PDEATHSIG, so establish it after dropping privileges.
    if libc.prctl(1, signal.SIGKILL, 0, 0, 0) != 0 or os.getppid() != parent:
        raise RuntimeError('Child parent-death ownership guard unavailable')
    signal.signal(signal.SIGINT, signal.SIG_DFL)
    signal.signal(signal.SIGTERM, signal.SIG_DFL)
    signal.pthread_sigmask(signal.SIG_SETMASK, previous_mask)

def unique_json(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError('Duplicate evidence key')
            result[key] = value
        return result
    return json.loads(raw, object_pairs_hook=pairs)

def bounded_bytes(path, maximum):
    with path.open('rb') as stream:
        raw = stream.read(maximum + 1)
    if len(raw) > maximum:
        raise RuntimeError('Evidence file exceeds quota')
    return raw

def project_build_diagnostics(stdout, stderr, repository):
    """Only known codes and existing File source coordinates; never messages."""
    if len(stdout) + len(stderr) > LIMIT:
        raise RuntimeError('Build projection exceeds original aggregate quota')
    repository = repository.resolve(strict=True)
    text = (stdout + b'\n' + stderr).decode('utf-8', errors='replace')
    pattern = re.compile(r'^(.+?)(?:\((\d{1,7})(?:,(\d{1,7}))?\))?\s*:\s*(error|warning)\s+((?:CS|NU|MSB)\d{4})\s*:', re.M)
    diagnostics = []
    omitted = 0
    encountered = 0
    for match in pattern.finditer(text):
        encountered += 1
        raw_path, line, column, severity, code = match.groups()
        raw_path = raw_path.strip().replace('\\', '/')
        prefix = repository.as_posix().rstrip('/') + '/'
        if raw_path.startswith(prefix):
            raw_path = raw_path[len(prefix):]
        parts = raw_path.split('/')
        if (len(raw_path) > 512 or not re.fullmatch(r'[A-Za-z0-9_./-]+', raw_path)
                or any(part in ('', '.', '..') for part in parts)
                or parts[0] not in {Path(path).parts[0] for path in PROJECT_PATHS}
                or Path(raw_path).suffix not in {'.cs', '.csproj'}):
            continue
        path = repository.joinpath(*parts)
        if any(repository.joinpath(*parts[:index]).is_symlink() for index in range(1, len(parts) + 1)):
            continue
        if not path.is_file() or repository not in path.resolve().parents:
            continue
        row = {'category': {'CS': 'compiler', 'NU': 'restore', 'MSB': 'msbuild'}[re.match(r'[A-Z]+', code).group()],
               'severity': severity, 'code': code, 'file': raw_path,
               'line': int(line) if line else None, 'column': int(column) if column else None}
        if len(diagnostics) < 64:
            diagnostics.append(row)
        else:
            omitted += 1
    def counter(name):
        values = re.findall(r'^\s*(\d{1,7}) ' + name + r'\(s\)\s*$', text, re.M)
        return int(values[0]) if len(values) == 1 else None
    warnings, errors = counter('Warning'), counter('Error')
    availability = 'available' if diagnostics else ('none' if warnings == errors == 0 and encountered == 0 else 'unavailable')
    return {'diagnostics': diagnostics, 'omittedDiagnostics': omitted,
            'diagnosticAvailability': availability, 'warnings': warnings, 'errors': errors,
            'privacy': 'Known code/category and validated File source coordinates only; messages omitted'}

def released_primitive_receipt(run, group, slot):
    for path in (group, slot):
        try:
            os.lstat(path)
        except FileNotFoundError:
            continue
        raise RuntimeError('Released ownership pathname still exists')
    return {'run': run, 'sdkExited': True, 'ownedBackendsAbsent': True,
            'handlesReleased': True, 'slotReleased': True, 'slotAbsent': True, 'cgroupAbsent': True}

def restored_audit_identity(repository):
    solution = repository / 'Legacy.Maliev.FileService.slnx'
    raw = bounded_bytes(solution, 65536)
    if len(raw) > 65536 or b'<!' in raw:
        raise RuntimeError('Invalid bounded solution inventory')
    projects = ET.fromstring(raw).findall('Project')
    if len(projects) != 5 or {node.attrib.get('Path') for node in projects} != PROJECT_PATHS:
        raise RuntimeError('Exact five-project File solution is required')
    expected = {}
    for node in projects:
        project = (repository / node.attrib['Path']).resolve(strict=True)
        if repository.resolve() not in project.parents or project in expected:
            raise RuntimeError('Foreign or duplicate solution project')
        asset_path = project.parent / 'obj' / 'project.assets.json'
        blob = bounded_bytes(asset_path, 16 * 1024 * 1024)
        if len(blob) > 16 * 1024 * 1024:
            raise RuntimeError('Restore identity exceeds quota')
        assets = unique_json(blob)
        restore = assets['project']['restore']
        if Path(restore['projectPath']).resolve() != project or restore['projectStyle'] != 'PackageReference':
            raise RuntimeError('Restore project identity differs')
        frameworks = set(restore['originalTargetFrameworks'])
        if frameworks != {'net10.0'} or set(assets['project']['frameworks']) != frameworks:
            raise RuntimeError('Restored framework identity differs')
        if set(assets['targets']) != frameworks:
            raise RuntimeError('Restored targets are incomplete or foreign')
        sources = set(restore['sources'])
        if sources != {'https://api.nuget.org/v3/index.json'}:
            raise RuntimeError('Unknown restored audit source')
        packages = {tuple(key.rsplit('/', 1)) for key, value in assets['libraries'].items() if value['type'] == 'package'}
        expected[project] = {'frameworks': frameworks, 'packages': packages, 'assets': asset_path,
                             'sha256': hashlib.sha256(blob).hexdigest()}
    return expected

def verify_audit(stdout, stderr, expected):
    if stderr:
        raise RuntimeError('Audit stderr is unavailable/failed evidence')
    report = unique_json(stdout)
    if not isinstance(report, dict):
        raise RuntimeError('Malformed audit report object')
    if type(report.get('version')) is not int or report['version'] != 1:
        raise RuntimeError('Require audit JSON version 1')
    if not set(report) <= {'version', 'parameters', 'sources', 'projects', 'errors', 'warnings', 'problems', 'messages'}:
        raise RuntimeError('Unknown audit report schema')
    if not isinstance(report.get('parameters'), str) or not {'--vulnerable', '--include-transitive'} <= set(report['parameters'].split()):
        raise RuntimeError('Audit report mode differs')
    if report.get('sources') != ['https://api.nuget.org/v3/index.json']:
        raise RuntimeError('Audit source unavailable or foreign')
    def refuse(value):
        if isinstance(value, dict):
            for key, child in value.items():
                if key.lower() in {'error', 'errors', 'warning', 'warnings', 'problem', 'problems', 'messages', 'unavailable', 'vulnerabilities'}:
                    if not isinstance(child, list):
                        raise RuntimeError('Malformed audit diagnostic collection')
                    if child:
                        raise RuntimeError('Audit error, unavailable feed or vulnerability found')
                if key.lower() == 'code' and isinstance(child, str) and child.startswith('NU190'):
                    raise RuntimeError('Audit feed or vulnerability warning found')
                refuse(child)
        elif isinstance(value, list):
            for child in value:
                refuse(child)
    refuse(report)
    projects = report.get('projects')
    if not isinstance(projects, list) or len(projects) != len(expected):
        raise RuntimeError('Audit solution inventory incomplete')
    seen = set()
    for project in projects:
        if not isinstance(project, dict):
            raise RuntimeError('Malformed audit project object')
        if not set(project) <= {'path', 'frameworks', 'errors', 'warnings', 'problems', 'messages'}:
            raise RuntimeError('Unknown audit project schema')
        path = Path(project['path']).resolve()
        if path not in expected or path in seen:
            raise RuntimeError('Audit project is foreign or duplicate')
        seen.add(path)
        # JSONv1 --vulnerable omits frameworks for a clean project. Bind its
        # path to the actual restored assets; never invent a framework row.
        if 'frameworks' in project:
            frameworks = project['frameworks']
            if not isinstance(frameworks, list) or not frameworks:
                raise RuntimeError('Malformed audit framework rows')
            visited = set()
            for framework in frameworks:
                if not isinstance(framework, dict):
                    raise RuntimeError('Malformed audit framework object')
                if not set(framework) <= {'framework', 'topLevelPackages', 'transitivePackages', 'errors', 'warnings', 'problems', 'messages'}:
                    raise RuntimeError('Unknown audit framework schema')
                name = framework['framework']
                if name not in expected[path]['frameworks'] or name in visited:
                    raise RuntimeError('Foreign or duplicate audit framework')
                visited.add(name)
                for kind in ('topLevelPackages', 'transitivePackages'):
                    rows = framework.get(kind, [])
                    if not isinstance(rows, list):
                        raise RuntimeError('Malformed audit package rows')
                    for package in rows:
                        if (package['id'], package['resolvedVersion']) not in expected[path]['packages']:
                            raise RuntimeError('Audit package differs from restore')
                    if rows:
                        raise RuntimeError('Vulnerable-filter package rows are not a clean audit')
    for evidence in expected.values():
        if hashlib.sha256(bounded_bytes(evidence['assets'], 16 * 1024 * 1024)).hexdigest() != evidence['sha256']:
            raise RuntimeError('Restored asset identity changed during audit')

def drop_child_identity(uid, gid, groups, os_api=os, libc=None):
    import ctypes
    if uid <= 0 or gid < 0 or not groups or len(groups) > 32 or any(type(item) is not int or item < 0 for item in groups):
        raise RuntimeError('Invalid original SDK identity')
    libc = libc if libc is not None else ctypes.CDLL(None, use_last_error=True)
    libc.prctl.argtypes = [ctypes.c_int, *([ctypes.c_ulong] * 4)]
    libc.prctl.restype = ctypes.c_int
    # Prevent sudo/setuid or file capabilities from regaining supervisor privileges.
    if libc.prctl(38, 1, 0, 0, 0) != 0:
        raise RuntimeError('PR_SET_NO_NEW_PRIVS refused')
    os_api.setgroups(groups)
    os_api.setgid(gid)
    os_api.setuid(uid)
    if os_api.geteuid() != uid or os_api.getegid() != gid:
        raise RuntimeError('SDK privilege drop did not take effect')
    os_api.umask(0o077)

def write_new(path, value, evidence_owner=None):
    with registration_window():
        _write_new(path, value, evidence_owner)

def _write_new(path, value, evidence_owner=None):
    raw = (json.dumps(value, sort_keys=True, separators=(',', ':')) + '\n').encode()
    if len(raw) > 65536:
        raise ValueError('Evidence frame too large')
    if evidence_owner is not None:
        return _write_owned_projection_evidence(path, raw, evidence_owner)
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(descriptor, 'wb', closefd=False) as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(descriptor)
    finally:
        os.close(descriptor)
    directory = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(directory)
    finally:
        os.close(directory)


def _write_owned_projection_evidence(path, raw, evidence_owner):
    uid, gid = evidence_owner
    if type(uid) is not int or type(gid) is not int or uid <= 0 or gid < 0 or os.geteuid() != 0:
        raise ValueError('Exact root-to-uploader identity required')
    directory = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    descriptor = None
    try:
        parent = os.fstat(directory)
        if parent.st_uid != 0 or not stat.S_ISDIR(parent.st_mode) or parent.st_mode & 0o022:
            raise RuntimeError('Projection evidence parent custody differs')
        descriptor = os.open(path.name, os.O_RDWR | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600, dir_fd=directory)
        os.fchown(descriptor, uid, gid)
        before = os.fstat(descriptor)
        if (before.st_uid, before.st_gid, stat.S_IMODE(before.st_mode)) != (uid, gid, 0o600):
            raise RuntimeError('Projection evidence uploader ownership differs')
        with os.fdopen(descriptor, 'wb', closefd=False) as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(descriptor)
        os.lseek(descriptor, 0, os.SEEK_SET)
        if os.read(descriptor, len(raw) + 1) != raw:
            raise RuntimeError('Projection evidence descriptor readback differs')
        after = os.fstat(descriptor)
        if (after.st_dev, after.st_ino, after.st_uid, after.st_gid, stat.S_IMODE(after.st_mode), after.st_size) != (
                before.st_dev, before.st_ino, uid, gid, 0o600, len(raw)):
            raise RuntimeError('Projection evidence descriptor identity differs')
        os.fsync(directory)
    finally:
        if descriptor is not None:
            os.close(descriptor)
        os.close(directory)

def identity(path):
    value = path.stat()
    return value.st_dev, value.st_ino

def descriptor_identity(descriptor):
    value = os.fstat(descriptor)
    return value.st_dev, value.st_ino

def retained_creation_identity(path, descriptor):
    actual = descriptor_identity(descriptor)
    if identity(path) != actual:
        raise RuntimeError('Creation path differs from its retained descriptor')
    return actual

def persist(path, value):
    with registration_window():
        _persist(path, value)

def _persist(path, value):
    if not path.exists():
        write_new(path, value)
        return
    if unique_json(bounded_bytes(path, 65536)) != value:
        raise RuntimeError('Immutable cleanup receipt changed')
    descriptor = os.open(path, os.O_RDONLY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)

def current_group_empty(group):
    values = dict(line.split() for line in (group / 'cgroup.events').read_text().splitlines())
    if values.get('populated') not in {'0', '1'}:
        raise RuntimeError('Cgroup population unavailable')
    return values['populated'] == '0'

class DeadlineSocket(socket.socket):
    def recv_into(self, buffer, nbytes=0, flags=0):
        remaining = self.deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError('Absolute Docker RPC deadline')
        self.settimeout(remaining)
        return super().recv_into(buffer, nbytes, flags)

class LocalDocker(http.client.HTTPConnection):
    def __init__(self):
        super().__init__('localhost', timeout=10)
    def connect(self):
        global SOCKET_IDENTITY
        actual = identity(Path('/var/run/docker.sock'))
        if SOCKET_IDENTITY is None:
            SOCKET_IDENTITY = actual
        if actual != SOCKET_IDENTITY:
            raise RuntimeError('Local Docker socket identity changed')
        self.sock = DeadlineSocket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.sock.deadline = min(time.monotonic() + 10, RPC_DEADLINE or float('inf'))
        self.sock.settimeout(max(.001, self.sock.deadline - time.monotonic()))
        self.sock.connect('/var/run/docker.sock')

def docker(method, path, body=None):
    if RPC_DEADLINE is not None and time.monotonic() >= RPC_DEADLINE:
        raise TimeoutError('Finite Docker cleanup attempt expired')
    connection = LocalDocker()
    try:
        encoded = None if body is None else json.dumps(body).encode()
        connection.request(method, '/v1.45' + path, body=encoded,
                           headers={} if encoded is None else {'Content-Type': 'application/json'})
        response = connection.getresponse()
        raw = response.read(1024 * 1024 + 1)
        if len(raw) > 1024 * 1024:
            raise RuntimeError('Docker response exceeded quota')
        return response.status, None if not raw else unique_json(raw)
    finally:
        connection.close()

def profile(value, intent, run):
    config, host = value['Config'], value['HostConfig']
    labels = config.get('Labels') or {}
    expected = {'maliev.codex.owner': OWNER, 'maliev.codex.sdk-run': run,
                'maliev.codex.run': intent['childRun'], 'maliev.codex.parent-run': intent['scope'],
                'maliev.codex.persistent-data': 'false'}
    if any(labels.get(key) != item for key, item in expected.items()):
        raise RuntimeError('Foreign container ownership')
    if value['Name'] != '/' + intent['name'] or config['Image'] != intent['image']:
        raise RuntimeError('Container intent mismatch')
    created = dt.datetime.fromisoformat(value['Created'].replace('Z', '+00:00'))
    admitted = dt.datetime.fromisoformat(intent['createdUtc'].replace('Z', '+00:00'))
    if not -5 <= (created - admitted).total_seconds() <= 900:
        raise RuntimeError('Container birth outside exact creation intent')
    expiry = dt.datetime.fromisoformat(labels['maliev.codex.expires-utc'].replace('Z', '+00:00'))
    if not 0 < (expiry - admitted).total_seconds() <= 1805:
        raise RuntimeError('Container expiry profile differs')
    if intent['image'] in {'postgres:18-alpine', 'postgres:18.1-bookworm'}:
        memory, cpu, mount, temporary, port = 512 * 1024 * 1024, 1000000000, '/var/lib/postgresql', 'rw,size=384m', '5432/tcp'
        if config['Cmd'] != ['postgres', '-c', 'statement_timeout=15000', '-c', 'idle_in_transaction_session_timeout=15000']:
            raise RuntimeError('PostgreSQL command profile differs')
        if 'PGDATA=/var/lib/postgresql/18/docker' not in config.get('Env', []):
            raise RuntimeError('PostgreSQL storage profile differs')
    elif intent['image'] == 'redis:8-alpine':
        memory, cpu, mount, temporary, port = 128 * 1024 * 1024, 500000000, '/data', 'rw,size=64m', '6379/tcp'
        if config['Cmd'] != ['redis-server', '--save', '', '--appendonly', 'no', '--maxmemory', '64mb', '--maxmemory-policy', 'noeviction']:
            raise RuntimeError('Redis command profile differs')
    else:
        raise RuntimeError('Unknown container image')
    if (host.get('Memory'), host.get('MemorySwap'), host.get('NanoCpus')) != (memory, memory, cpu):
        raise RuntimeError('Actual container caps differ')
    if host.get('Tmpfs') != {mount: temporary} or host.get('Binds') or host.get('Mounts'):
        raise RuntimeError('Unknown persistent storage')
    if any(item['Type'] != 'tmpfs' or item['Destination'] != mount for item in value.get('Mounts', [])):
        raise RuntimeError('Unknown actual mount')
    bindings = host.get('PortBindings') or {}
    if set(bindings) != {port} or len(bindings[port]) != 1 or bindings[port][0]['HostIp'] != '127.0.0.1':
        raise RuntimeError('Unknown port binding')
    # Never persist Config.Env: Testcontainers' synthetic DB password is still a
    # credential. Only metadata required by exact owned cleanup is journaled.
    return {'Id': value['Id'], 'Created': value['Created'], 'Image': value['Image'], 'Name': value['Name'],
            'imageTag': config['Image'], 'labels': labels, 'command': config['Cmd'],
            'entrypoint': config.get('Entrypoint'), 'memory': memory, 'cpu': cpu,
            'tmpfs': host['Tmpfs'], 'portBindings': bindings}

def refuse_active_clients(value):
    ports = {int(item['HostPort']) for rows in (value['NetworkSettings'].get('Ports') or {}).values()
             for item in (rows or []) if item['HostIp'] == '127.0.0.1'}
    for path in ('/proc/net/tcp', '/proc/net/tcp6'):
        for row in Path(path).read_text().splitlines()[1:]:
            items = row.split()
            if len(items) < 4:
                raise RuntimeError('TCP census unavailable')
            local, remote = (int(items[index].split(':')[1], 16) for index in (1, 2))
            if items[3] == '01' and (local in ports or remote in ports):
                raise RuntimeError('Owned backend still has active local clients')

def recover_backends(root, run, group):
    if not current_group_empty(group):
        raise RuntimeError('SDK producers have not exited')
    paths = sorted((root / 'intents').glob('*.json'))
    if len(paths) > 512:
        raise RuntimeError('Container intent cap exceeded')
    status, info = docker('GET', '/info')
    if status != 200 or info.get('OSType') != 'linux' or not info.get('ID'):
        raise RuntimeError('Local Linux daemon identity unavailable')
    status, inventory = docker('GET', '/containers/json?all=true&filters=' + quote(json.dumps(
        {'label': ['maliev.codex.sdk-run=' + run]}, separators=(',', ':')), safe=''))
    if status != 200 or not isinstance(inventory, list) or len(inventory) > 512:
        raise RuntimeError('Owned container inventory unavailable')
    intended_names = {'/' + unique_json(bounded_bytes(path, 4096))['name'] for path in paths}
    if any(not any(name in intended_names for name in row['Names']) for row in inventory):
        raise RuntimeError('Unregistered container in the exact SDK run')
    for path in paths:
        raw = bounded_bytes(path, 4096)
        if len(raw) > 4096:
            raise RuntimeError('Intent exceeds quota')
        intent = unique_json(raw)
        if intent['sdkRun'] != run or intent['owner'] != OWNER or intent['daemon'] != info['ID']:
            raise RuntimeError('Foreign intent or changed daemon')
        child = intent['childRun']
        if uuid.UUID(hex=child).hex != child or path.name != child + '.json':
            raise RuntimeError('Invalid immutable intent name')
        if uuid.UUID(hex=intent['scope']).hex != intent['scope']:
            raise RuntimeError('Invalid fixture scope')
        prefix = 'file-redis-' if intent['image'] == 'redis:8-alpine' else 'file-postgres-'
        if not intent['name'].startswith(prefix) or uuid.UUID(hex=intent['name'][len(prefix):]).hex != intent['name'][len(prefix):]:
            raise RuntimeError('Invalid exact owned container name')
        # UUID name is recorded before Create. Only reconcile that exact name.
        status, value = docker('GET', '/containers/' + intent['name'] + '/json')
        if status == 404:
            published = root / ('published-' + child + '.json')
            absent = root / ('absent-' + child + '.json')
            if not published.exists() and not absent.exists():
                # A dead SDK and an absent name alone cannot settle a daemon's
                # unacknowledged Create; retain the pre-dispatch UUID intent.
                raise RuntimeError('Unacknowledged Create absence is not proof')
            proof = unique_json(bounded_bytes(published if published.exists() else absent, 4096))
            if proof['sdkRun'] != run or proof['childRun'] != child:
                raise RuntimeError('Foreign publication or absence receipt')
            if published.exists() and (proof['daemon'] != info['ID']
                or docker('GET', '/containers/' + proof['id'] + '/json')[0] != 404):
                raise RuntimeError('Published exact-ID absence is unverified')
            if absent.exists() and unique_json(bounded_bytes(absent, 4096)).get('actualAbsence') is not True:
                raise RuntimeError('Absence receipt did not prove release')
            continue
        if status != 200:
            raise RuntimeError('Exact container observation unavailable')
        expected = profile(value, intent, run)
        checkpoint = root / ('container-' + child + '.json')
        if checkpoint.exists():
            if unique_json(bounded_bytes(checkpoint, 65536)) != expected:
                raise RuntimeError('Captured immutable container identity changed')
        else:
            write_new(checkpoint, expected)
        refuse_active_clients(value)
        status, repeated = docker('GET', '/containers/' + value['Id'] + '/json')
        if status != 200 or profile(repeated, intent, run) != expected:
            raise RuntimeError('Pre-mutation container identity changed')
        if docker('GET', '/info')[1]['ID'] != info['ID']:
            raise RuntimeError('Daemon changed before mutation')
        status, _ = docker('POST', '/containers/' + value['Id'] + '/stop?t=10')
        if status not in {204, 304}:
            raise RuntimeError('Exact container stop failed')
        status, stopped = docker('GET', '/containers/' + value['Id'] + '/json')
        if status != 200 or stopped['State']['Running'] or profile(stopped, intent, run) != expected:
            raise RuntimeError('Exact stopped container identity unverified')
        status, _ = docker('DELETE', '/containers/' + value['Id'] + '?force=false&v=false')
        if status != 204 or docker('GET', '/containers/' + value['Id'] + '/json')[0] != 404:
            raise RuntimeError('Physical owned container absence unverified')

def verify_test_results(directory, phase):
    expected_total = 96 if phase == 'focused' else 1117
    paths = sorted(directory.rglob('*.trx'))
    if len(paths) != 1:
        raise RuntimeError('One actual phase TRX required')
    raw = bounded_bytes(paths[0], LIMIT)
    if len(raw) > LIMIT or b'<!' in raw:
        raise RuntimeError('TRX exceeds quota or contains declarations')
    tree = ET.fromstring(raw)
    ns = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
    if tree.tag != '{' + ns['t'] + '}TestRun':
        raise RuntimeError('Actual native TestRun root required')
    def unique_container(name, direct_path):
        global_nodes = tree.findall('.//t:' + name, ns)
        direct_nodes = tree.findall(direct_path, ns)
        if len(global_nodes) != 1 or len(direct_nodes) != 1 or global_nodes[0] is not direct_nodes[0]:
            raise RuntimeError('Unique native ' + name + ' required at its direct expected position')
        return direct_nodes[0]
    summary = unique_container('ResultSummary', 't:ResultSummary')
    counters = unique_container('Counters', 't:ResultSummary/t:Counters')
    unique_container('Results', 't:Results')
    unique_container('TestDefinitions', 't:TestDefinitions')
    results = tree.findall('t:Results/t:UnitTestResult', ns)
    if summary is None or summary.get('outcome') != 'Completed' or counters is None:
        raise RuntimeError('Complete actual TRX counters required')
    expected_counters = {'total','executed','passed','failed','error','timeout','aborted','inconclusive',
        'passedButRunAborted','notRunnable','notExecuted','disconnected','warning','completed','inProgress','pending'}
    if set(counters.attrib) != expected_counters or any(not re.fullmatch('0|[1-9][0-9]*', value) for value in counters.attrib.values()):
        raise RuntimeError('Complete explicit native TRX counter inventory required')
    values = {key: int(value) for key, value in counters.attrib.items()}
    if any(value < 0 for value in values.values()) or any(values.get(key) != expected_total for key in ('total', 'executed', 'passed')):
        raise RuntimeError('Closed native case inventory differs')
    if any(value != 0 for key, value in values.items() if key not in {'total', 'executed', 'passed'}) or len(results) != expected_total:
        raise RuntimeError('Native suite has skipped/failed/unsettled cases')
    executions = [value.get('executionId') for value in results]
    if None in executions or len(set(executions)) != len(executions) or any(value.get('outcome') != 'Passed' for value in results):
        raise RuntimeError('Actual unique passed case results required')
    if phase == 'focused':
        definitions = {}
        for value in tree.findall('t:TestDefinitions/t:UnitTest', ns):
            method = value.find('t:TestMethod', ns)
            if method is None or value.get('id') in definitions:
                raise RuntimeError('Unique actual focused test definitions required')
            cls = method.get('className', '').split(',', 1)[0]
            name = method.get('name', '').split('(', 1)[0].removeprefix(cls + '.')
            definitions[value.get('id')] = cls + '.' + name
        observed = {}
        for value in results:
            name = definitions.get(value.get('testId'))
            if name not in FOCUSED_INVENTORY:
                raise RuntimeError('Unknown case outside closed focused filter')
            observed[name] = observed.get(name, 0) + 1
        if observed != FOCUSED_INVENTORY:
            raise RuntimeError('Focused per-method native cases differ')
    if phase == 'full':
        from importlib.util import module_from_spec, spec_from_file_location
        spec = spec_from_file_location('file_coverage_gate', Path(__file__).with_name('verify-runner-coverage.py'))
        module = module_from_spec(spec); spec.loader.exec_module(module)
        module.verify(directory)
    persist(directory / 'native-test-gate.json', {'phase': phase, 'actualPassed': len(results),
        'failed': 0, 'skipped': 0, 'trxSha256': hashlib.sha256(raw).hexdigest()})


def verify_release_graph(repository, dependency_root, results):
    if not dependency_root:
        raise RuntimeError('Pinned dependency graph root unavailable')
    expected = {name: repository / name for name in ('Legacy.Maliev.FileService.Api',
        'Legacy.Maliev.FileService.Application', 'Legacy.Maliev.FileService.Domain',
        'Legacy.Maliev.FileService.Data', 'Legacy.Maliev.FileService.Tests')}
    for name in ('Legacy.Maliev.ServiceDefaults', 'Legacy.Maliev.CompatibilityContracts'):
        expected[name] = Path(dependency_root) / name / 'src' / name
    log = bounded_bytes(results.parent / 'sdk.log', LIMIT).decode('utf-8')
    rows = []
    for name, project in expected.items():
        path = project / 'bin' / 'Release' / 'net10.0' / (name + '.dll')
        if path.is_symlink() or not path.is_file() or ('-> ' + str(path)) not in log:
            raise RuntimeError('All seven actual Release output witnesses required')
        raw = bounded_bytes(path, LIMIT)
        if len(raw) < 2 or raw[:2] != b'MZ' or len(raw) > LIMIT:
            raise RuntimeError('Actual Release PE assembly witness unavailable')
        rows.append({'assembly': name, 'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
    if any(re.search(r'-> .*[/\\]bin[/\\]Debug[/\\]', line) for line in log.splitlines()):
        raise RuntimeError('Graph emitted a Debug assembly')
    persist(results / 'release-graph.json', {'configuration': 'Release', 'assemblies': rows})


def verify_predecessor(repository, admitted, pipeline, current_profile=None):
    phases = ('build', 'focused', 'full', 'format', 'audit')
    index = phases.index(admitted.phase)
    if index == 0:
        return
    candidates = sorted((repository / 'runner-results').glob('owned-' + phases[index - 1] + '-*'))
    if len(candidates) > 64:
        raise RuntimeError('Phase predecessor inventory exceeds quota')
    matches = []
    for path in candidates:
        context = unique_json(bounded_bytes(path / 'phase-context.json', 4096))
        if context.get('sourceBinding') == admitted.source_binding and context.get('origin') == admitted.origin and context.get('pipeline') == pipeline:
            matches.append(path)
    if len(matches) != 1:
        raise RuntimeError('Exactly one bound successful predecessor required')
    previous = matches[0]
    status = unique_json(bounded_bytes(previous / 'results/phase-status.json', 4096))
    released = unique_json(bounded_bytes(previous / 'results/release-status.json', 4096))
    if status.get('phase') != phases[index - 1] or status.get('exitCode') != 0 or status.get('signal') is not None:
        raise RuntimeError('Previous fixed phase did not pass')
    if any(released.get(key) is not True for key in ('sdkExited', 'ownedBackendsAbsent', 'handlesReleased', 'slotReleased', 'slotAbsent', 'cgroupAbsent')):
        raise RuntimeError('Previous exact resource owner did not release')
    if phases[index - 1] == 'build':
        graph = unique_json(bounded_bytes(previous / 'results/release-graph.json', 16384))
        if graph.get('configuration') != 'Release' or len(graph.get('assemblies', [])) != 7:
            raise RuntimeError('Previous all-seven Release graph missing')
    if phases[index - 1] in {'focused', 'full'}:
        tests = unique_json(bounded_bytes(previous / 'results/native-test-gate.json', 4096))
        expected = current_profile.expected_total(phases[index - 1]) if current_profile is not None else (96 if phases[index - 1] == 'focused' else 1117)
        if tests.get('actualPassed') != expected or tests.get('failed') != 0 or tests.get('skipped') != 0:
            raise RuntimeError('Previous native test gate did not pass')


def process_birth(pid):
    raw = Path('/proc/' + str(pid) + '/stat').read_text()
    fields = raw[raw.rfind(')') + 2:].split()
    if len(fields) < 20 or not fields[19].isdigit() or int(fields[19]) <= 0:
        raise RuntimeError('Owned process birth unavailable')
    return fields[19]


def graceful_stop(child, handle, group, expected_group, pending, state):
    """One fixed TERM grace; retained pidfds and immutable group precede force."""
    if state['deadline'] is None:
        state['deadline'] = time.monotonic() + 5
    if child is not None and not state['primary']:
        if handle is not None:
            signal.pidfd_send_signal(handle, signal.SIGTERM)
        else:
            # Only the original unreaped direct child; its PID cannot be reused.
            os.kill(child, signal.SIGTERM)
        state['primary'] = True
    if expected_group is not None:
        if identity(group) != expected_group:
            raise RuntimeError('Exact group identity changed before graceful stop')
        values = (group / 'cgroup.procs').read_text().split()
        if len(values) > 64 or len(values) != len(set(values)) or any(not value.isdigit() or int(value) <= 0 for value in values):
            raise RuntimeError('Bounded owned group census unavailable')
        for value in values:
            pid = int(value)
            if pid == child and state['primary']:
                continue
            try:
                birth = process_birth(pid)
            except FileNotFoundError:
                continue  # No signal is sent from an absent process path.
            if (pid, birth) in state['groups']:
                continue
            with registration_window():
                descriptor = os.pidfd_open(pid, 0)
                pending[descriptor] = None
            pending[descriptor] = descriptor_identity(descriptor)
            try:
                same_birth = process_birth(pid) == birth
                membership = Path('/proc/' + value + '/cgroup').read_text().splitlines()
            except FileNotFoundError:
                continue  # Retain the exact pidfd for the enclosing cleanup owner.
            if not same_birth or ('0::/' + group.name) not in membership or identity(group) != expected_group:
                raise RuntimeError('Process/group ownership changed before TERM; preserve it')
            signal.pidfd_send_signal(descriptor, signal.SIGTERM)
            state['groups'].add((pid, birth))
    while time.monotonic() < state['deadline']:
        primary_gone = child is None or handle is not None and bool(select.select([handle], [], [], 0)[0])
        group_gone = expected_group is None or current_group_empty(group)
        if primary_gone and group_gone:
            return
        time.sleep(.05)
    if child is not None:
        if handle is not None:
            if not select.select([handle], [], [], 0)[0]:
                signal.pidfd_send_signal(handle, signal.SIGKILL)
        else:
            os.kill(child, signal.SIGKILL)
    if expected_group is not None:
        if identity(group) != expected_group:
            raise RuntimeError('Exact group changed before bounded force')
        if not current_group_empty(group):
            (group / 'cgroup.kill').write_text('1')


VSTEST_SDK_VERSION = '10.0.401'
VSTEST_PROVIDER_HOST_SHA256 = '7dda7a639bc35fba05c40d308b0296450aa4e628d109245a6312c385da9b0931'
TEST_RELEASE_RELATIVE = 'Legacy.Maliev.FileService.Tests/bin/Release/net10.0/Legacy.Maliev.FileService.Tests.dll'


SDK_ARCHIVE_URL = 'https://builds.dotnet.microsoft.com/dotnet/Sdk/10.0.401/dotnet-sdk-10.0.401-linux-x64.tar.gz'
SDK_ARCHIVE_SHA512 = '51c8b999af9e8dd9998c9edc5944e19a90788862068acd38694e098889054ce8c23d4f0c5cccfa16bf187d044562359e5ee69a9f8ad0bbe913ba90311fbce25b'
SDK_ARCHIVE_MAX = 512 * 1024 * 1024
SDK_EXPANDED_MAX = 2 * 1024 * 1024 * 1024
SDK_FILE_MAX = 256 * 1024 * 1024
SDK_ENTRIES_MAX = 30000
SDK_PROJECTION_ANCHOR = Path('/root')
ACTIVE_SDK_PROJECTIONS = {}
QUALIFICATION_SDK_ARCHIVE_BYTES = 240059572
QUALIFICATION_SDK_CONTENT_ROWS = 5631
QUALIFICATION_SDK_CONTENT_SHA256 = 'a84e1056855fea7408ebf127745018f7728ce6a2b613dd91fd0d5e4068455519'
QUALIFICATION_PROVIDER_PINS = {
    'dotnet': (71808, '01d89e0a0191052bfea616cd4ce624c8faf13b05bbddf7f64499c23e2a9d9269'),
    'sdk/10.0.401/vstest.console.dll': (654160, '5ade254908c4604a4cd7999531793033fd4aedbb2587889228ab1f28f2a5bd75'),
    'sdk/10.0.401/vstest.console.deps.json': (28347, 'c14a38f41841451b464ad5af622539a1b80cd69958b2fc0690b64fd94411a53b'),
    'sdk/10.0.401/vstest.console.runtimeconfig.json': (359, '8502b8971de54c8095e736ee788aab412cd51f69fae3a0a4a1404d188383eeb9'),
}


def qualification_sdk_content(rows, archive_bytes):
    if type(archive_bytes) is not int or archive_bytes != QUALIFICATION_SDK_ARCHIVE_BYTES:
        raise ValueError('Qualified official archive byte count differs')
    if type(rows) is not list or len(rows) != QUALIFICATION_SDK_CONTENT_ROWS:
        raise ValueError('Qualified SDK content row count differs')
    content = []
    seen = set()
    base = {'path', 'mode', 'bytes', 'uid', 'device', 'inode', 'ctimeNs'}
    for row in rows:
        if type(row) is not dict or type(row.get('path')) is not str:
            raise ValueError('Qualified SDK row schema differs')
        path = row['path']
        if (not path or path.startswith('/') or '\\' in path or ':' in path or
                any(ord(char) < 32 for char in path) or
                (path != '.' and any(part in ('', '.', '..') for part in path.split('/'))) or path in seen):
            raise ValueError('Qualified SDK content path differs')
        seen.add(path)
        limits = {'mode': (0, 65535), 'bytes': (0, SDK_FILE_MAX), 'uid': (0, 0),
                  'device': (0, 2**64-1), 'inode': (1, 2**64-1), 'ctimeNs': (0, 2**63-1)}
        if any(type(row.get(key)) is not int or not lo <= row[key] <= hi for key, (lo, hi) in limits.items()):
            raise ValueError('Qualified SDK metadata differs')
        directory = row['mode'] == stat.S_IFDIR | 0o755
        regular = row['mode'] in (stat.S_IFREG | 0o444, stat.S_IFREG | 0o555)
        if (not directory and not regular or set(row) != (base if directory else base | {'sha256'}) or
                directory and row['bytes'] != 0 or path == '.' and not directory or
                regular and (type(row['sha256']) is not str or not re.fullmatch('[0-9a-f]{64}', row['sha256']))):
            raise ValueError('Qualified SDK readonly content differs')
        content.append({key: row[key] for key in ('path', 'mode', 'bytes', 'sha256') if key in row})
    if sum(row['bytes'] for row in content) > SDK_EXPANDED_MAX:
        raise ValueError('Qualified SDK expansion quota differs')
    raw = (json.dumps(sorted(content, key=lambda row: row['path']), sort_keys=True, separators=(',', ':')) + '\n').encode()
    digest = hashlib.sha256(raw).hexdigest()
    if digest != QUALIFICATION_SDK_CONTENT_SHA256:
        raise ValueError('Qualified SDK deterministic content seal differs')
    return digest


def projection_check_deadline(deadline):
    if time.monotonic() >= deadline:
        raise RuntimeError('SDK projection lifetime expired')


def projection_trust(path):
    path = Path(path)
    for component_index, component in enumerate([path, *path.parents]):
        info = component.lstat()
        is_link = stat.S_ISLNK(info.st_mode)
        if info.st_uid != 0 or info.st_mode & 0o022 or is_link:
            raise SDKProjectionTrustError(path, component_index, info, is_link)
    return path.lstat()


def anchor_evidence_owner():
    import pwd
    values = [os.environ.get(key, '') for key in ('MALIEV_FILE_EVIDENCE_UID', 'MALIEV_FILE_EVIDENCE_GID')]
    if (not re.fullmatch(r'[1-9][0-9]{0,9}', values[0]) or
            not re.fullmatch(r'0|[1-9][0-9]{0,9}', values[1])):
        raise ValueError('Original uploader identity unavailable')
    uid, gid = map(int, values)
    if uid > 2147483647 or gid > 2147483647 or pwd.getpwuid(uid).pw_gid != gid:
        raise ValueError('Original uploader account differs')
    return uid, gid


def write_sdk_projection_evidence(path, value):
    if not re.fullmatch(r'sdk-projection(?:-(?:intent|release|unreleased|trust-failure|inventory-[0-9]{4}))?\.json', path.name):
        raise ValueError('Only named projection evidence can transfer ownership')
    write_new(path, value, anchor_evidence_owner())


def retain_sdk_anchor_failure(failure, evidence):
    if not isinstance(failure, SDKProjectionTrustError) or type(failure.anchor_role) is not int or failure.anchor_role != 1:
        raise ValueError('Only the fixed SDK anchor failure can be projected')
    witness = project_vstest_trust_failure(failure.closed_provider_error)
    value = {'schemaVersion': 1, 'operationKind': 1, 'anchorRole': 1,
             'SDKStarted': False, 'nativeTestsExecuted': False, 'witness': witness}
    if len((json.dumps(value, sort_keys=True) + '\n').encode()) > 4096:
        raise ValueError('SDK anchor failure frame exceeds quota')
    write_sdk_projection_evidence(Path(evidence) / 'sdk-projection-trust-failure.json', value)


def projection_inventory(root, deadline):
    import stat as file_stat
    rows = []
    stack = [Path(root)]
    while stack:
        projection_check_deadline(deadline)
        path = stack.pop()
        info = projection_trust(path)
        relative = path.relative_to(root).as_posix()
        row = {'path': relative, 'device': info.st_dev, 'inode': info.st_ino,
               'ctimeNs': info.st_ctime_ns, 'mode': info.st_mode, 'uid': info.st_uid,
               'bytes': info.st_size if file_stat.S_ISREG(info.st_mode) else 0}
        if file_stat.S_ISDIR(info.st_mode):
            with os.scandir(path) as scan:
                for item in scan:
                    stack.append(Path(item.path))
                    if len(stack) + len(rows) > SDK_ENTRIES_MAX:
                        raise RuntimeError('SDK projection inventory quota')
        elif file_stat.S_ISREG(info.st_mode):
            if info.st_size > SDK_FILE_MAX or info.st_nlink != 1:
                raise RuntimeError('SDK projection file quota or hard link')
            digest = hashlib.sha256()
            with path.open('rb') as handle:
                while True:
                    projection_check_deadline(deadline)
                    chunk = handle.read(1024 * 1024)
                    if not chunk:
                        break
                    digest.update(chunk)
            after = path.lstat()
            if (after.st_dev, after.st_ino, after.st_ctime_ns, after.st_size) != (info.st_dev, info.st_ino, info.st_ctime_ns, info.st_size):
                raise RuntimeError('SDK projection changed while hashing')
            row['sha256'] = digest.hexdigest()
        else:
            raise RuntimeError('SDK projection special file')
        rows.append(row)
    return sorted(rows, key=lambda row: row['path'])


def projection_archive_plan(archive, deadline):
    from pathlib import PurePosixPath
    import tarfile
    members = []
    seen = set()
    total = 0
    with tarfile.open(archive, 'r:gz') as source:
        for member in source:
            projection_check_deadline(deadline)
            name = member.name
            while name.startswith('./'):
                name = name[2:]
            if name in ('', '.') and member.isdir():
                continue
            parts = PurePosixPath(name).parts
            if (not name or name.startswith('/') or '\\' in name or ':' in name or any(ord(c) < 32 or ord(c) == 127 for c in name) or
                    any(part in ('', '.', '..') for part in name.split('/')) or
                    len(parts) > 32 or len(name.encode('utf-8')) > 1024 or name in seen):
                raise RuntimeError('SDK archive path differs')
            if not (member.isdir() or member.isreg()) or member.mode & 0o7022:
                raise RuntimeError('SDK archive link, special or writable member')
            if member.size < 0 or member.size > SDK_FILE_MAX or (member.isdir() and member.size):
                raise RuntimeError('SDK archive member quota')
            seen.add(name)
            total += member.size
            if total > SDK_EXPANDED_MAX or len(seen) > SDK_ENTRIES_MAX:
                raise RuntimeError('SDK archive expansion quota')
            members.append((name, member))
    regular = {name for name, member in members if member.isreg()}
    for name in seen:
        if any('/'.join(name.split('/')[:i]) in regular for i in range(1, len(name.split('/')))):
            raise RuntimeError('SDK archive file-directory collision')
    required = {'dotnet', 'sdk/10.0.401/vstest.console.dll',
                'sdk/10.0.401/vstest.console.deps.json', 'sdk/10.0.401/vstest.console.runtimeconfig.json',
                'shared/Microsoft.NETCore.App/10.0.12/libcoreclr.so', 'host/fxr/10.0.12/libhostfxr.so'}
    if not required <= regular:
        raise RuntimeError('Complete exact SDK/runtime graph unavailable')
    return members


def projection_cleanup(root, custody):
    root = Path(root)
    expected = {str(path): value for path, value in custody.items()}
    for path, expected_identity in custody.items():
        info = path.lstat()
        if (info.st_dev, info.st_ino) != expected_identity or info.st_uid != 0 or stat.S_ISLNK(info.st_mode):
            raise RuntimeError('SDK projection cleanup identity differs; custody retained')
    actual = {str(root)}
    for directory, directories, files in os.walk(root, followlinks=False):
        for name in directories + files:
            path = str(Path(directory) / name)
            if path not in expected:
                raise RuntimeError('SDK projection cleanup inventory differs; custody retained')
            actual.add(path)
    if actual != set(expected):
        raise RuntimeError('SDK projection cleanup inventory differs; custody retained')
    for path in sorted(custody, key=lambda item: len(item.parts), reverse=True):
        if stat.S_ISDIR(path.lstat().st_mode):
            path.rmdir()
        else:
            path.unlink()
    if root.exists():
        raise RuntimeError('SDK projection cleanup incomplete')


def projection_mkdir(path, custody, mode=0o755):
    with registration_window():
        path.mkdir(mode=mode)
        info = path.lstat()
        custody[path] = (info.st_dev, info.st_ino)


@contextmanager
def projection_output(path, custody):
    handle = None
    try:
        with registration_window():
            handle = path.open('xb')
            info = os.fstat(handle.fileno())
            custody[path] = (info.st_dev, info.st_ino)
        yield handle
    finally:
        if handle is not None:
            handle.close()


def publish_qualified_sdk_access(root, sdk, custody, rows, deadline):
    """Expose only authenticated vendor bytes; prove access without SDK execution."""
    import subprocess
    root, sdk = Path(root), Path(sdk)
    projection_check_deadline(deadline)
    if root.parent != Path('/') or sdk.parent != root or root not in custody:
        raise RuntimeError('Qualified SDK must be directly under trusted root')
    anchor = projection_trust(Path('/'))
    if not stat.S_ISDIR(anchor.st_mode) or anchor.st_mode & 0o111 != 0o111:
        raise RuntimeError('Qualified root traversal unavailable')
    before = projection_trust(root)
    if (before.st_dev, before.st_ino) != custody[root] or stat.S_IMODE(before.st_mode) != 0o700 or not stat.S_ISDIR(before.st_mode):
        raise RuntimeError('Private SDK staging custody differs')
    if projection_inventory(sdk, deadline) != rows:
        raise RuntimeError('SDK changed before access publication')
    uid, gid = anchor_evidence_owner()
    descriptor = os.open(root, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        held = os.fstat(descriptor)
        if (held.st_dev, held.st_ino, held.st_uid, held.st_mode) != (before.st_dev, before.st_ino, 0, before.st_mode):
            raise RuntimeError('Held SDK staging custody differs')
        os.fchmod(descriptor, 0o555)
        published = os.fstat(descriptor)
        current = projection_trust(root)
        if (current.st_dev, current.st_ino, current.st_ctime_ns, current.st_mode) != (published.st_dev, published.st_ino, published.st_ctime_ns, published.st_mode) or stat.S_IMODE(current.st_mode) != 0o555:
            raise RuntimeError('Read-only SDK publication differs')
        pins = {name: (row['bytes'], row['sha256']) for name in QUALIFICATION_PROVIDER_PINS
                for row in rows if row['path'] == name}
        if pins != QUALIFICATION_PROVIDER_PINS:
            raise RuntimeError('Qualified access provider seal differs')
        # Fixed Python observer: setuid/setgid/empty supplementary groups via Popen,
        # timeout kills and waits internally; no dotnet/SDK process is launched.
        code = ('import os,sys,json,hashlib,pathlib; '
                'root=pathlib.Path(sys.argv[1]); sdk=root/"sdk-root"; '
                'assert os.getuid()==int(sys.argv[2]) and os.getgid()==int(sys.argv[3]) and os.getgroups()==[]; '
                'assert os.access(root,os.X_OK) and not os.access(root,os.W_OK); '
                'assert os.access(sdk/"dotnet",os.X_OK); '
                'result={}; '
                '\nfor name in json.loads(sys.argv[4]):\n'
                ' p=sdk/name; raw=p.read_bytes(); assert not os.access(p,os.W_OK); '
                'result[name]=[len(raw),hashlib.sha256(raw).hexdigest()]\n'
                'print(json.dumps({"pins":result,"pid":os.getpid(),'
                '"startTicks":pathlib.Path("/proc/self/stat").read_text().rsplit(")",1)[1].split()[19],'
                '"executable":os.readlink("/proc/self/exe")},sort_keys=True))')
        timeout = min(5, deadline - time.monotonic())
        if timeout <= 0:
            raise RuntimeError('SDK projection lifetime expired')
        result = subprocess.run([sys.executable, '-I', '-B', '-c', code, str(root), str(uid), str(gid), json.dumps(sorted(pins))],
                                user=uid, group=gid, extra_groups=[], capture_output=True, timeout=timeout, check=False)
        if result.returncode != 0 or result.stderr or len(result.stdout) > 4096:
            raise RuntimeError('Dropped-user SDK access proof differs')
        observed = unique_json(result.stdout)
        if (type(observed) is not dict or set(observed) != {'pins', 'pid', 'startTicks', 'executable'} or
                observed['pins'] != {name: list(pin) for name, pin in pins.items()} or
                type(observed['pid']) is not int or observed['pid'] <= 0 or
                type(observed['startTicks']) is not str or not re.fullmatch('[1-9][0-9]{0,19}', observed['startTicks']) or
                observed['executable'] != str(Path(sys.executable).resolve(strict=True))):
            raise RuntimeError('Dropped-user observer identity or pins differ')
        projection_check_deadline(deadline)
        after = projection_trust(root)
        if (after.st_dev, after.st_ino, after.st_ctime_ns, after.st_mode) != (published.st_dev, published.st_ino, published.st_ctime_ns, published.st_mode) or projection_inventory(sdk, deadline) != rows:
            raise RuntimeError('SDK custody changed during dropped-user observation')
        anchor_after = projection_trust(Path('/'))
        # Root directory ctime can change due to unrelated trusted tasks; retain
        # ownership, identity and mode, without assuming exclusive global custody.
        if (anchor_after.st_dev, anchor_after.st_ino, anchor_after.st_uid, anchor_after.st_mode) != (anchor.st_dev, anchor.st_ino, anchor.st_uid, anchor.st_mode):
            raise RuntimeError('Trusted root changed during access proof')
        return {'uid': uid, 'gid': gid, 'supplementaryGroups': [], 'observerExited': True,
                'SDKStarted': False, 'namespaceIdentity': [after.st_dev, after.st_ino, after.st_ctime_ns, after.st_mode],
                'observer': {'pid': observed['pid'], 'startTicks': observed['startTicks'],
                             'executable': observed['executable'], 'timeoutSeconds': timeout,
                             'purpose': 'read-only dropped-user vendor-provider observation', 'exitCode': result.returncode},
                'providerPins': {name: list(pin) for name, pin in pins.items()}}
    finally:
        os.close(descriptor)


def trusted_sdk_projection(run_id, attempt, evidence, *, qualified_access=False):
    """Context manager: authenticated full SDK, zero SDK execution, exact cleanup."""
    from contextlib import contextmanager
    import urllib.request
    import tarfile
    @contextmanager
    def owned():
        if sys.platform != 'linux' or os.geteuid() != 0:
            raise RuntimeError('Root-owned Linux SDK projection required')
        if not re.fullmatch('[1-9][0-9]{0,19}', str(run_id)) or not re.fullmatch('[1-9][0-9]{0,3}', str(attempt)):
            raise RuntimeError('SDK projection run identity differs')
        if type(qualified_access) is not bool:
            raise ValueError('Exact qualified access selector required')
        anchor = Path('/') if qualified_access else SDK_PROJECTION_ANCHOR
        try:
            projection_trust(anchor)
        except BaseException as failure:
            try:
                retain_sdk_anchor_failure(failure, evidence)
            except BaseException:
                pass
            raise
        if shutil.disk_usage(anchor).free < 3 * 1024 * 1024 * 1024:
            raise RuntimeError('SDK projection disk admission unavailable')
        deadline = time.monotonic() + 300
        expires = (dt.datetime.now(dt.timezone.utc) + dt.timedelta(seconds=300)).isoformat()
        root = anchor / ('maliev-file-sdk-' + str(run_id) + '-' + str(attempt) + '-' + uuid.uuid4().hex)
        custody = {}
        failure = None
        projection = None
        try:
            projection_mkdir(root, custody, 0o700)
            intent = {'owner': OWNER, 'run': str(run_id), 'attempt': str(attempt), 'namespace': str(root),
                      'device': custody[root][0], 'inode': custody[root][1], 'expiresUtc': expires,
                      'purpose': 'authenticated disposable full SDK observation', 'persistentData': False,
                      'archiveSha512': SDK_ARCHIVE_SHA512, 'SDKStarted': False}
            write_sdk_projection_evidence(Path(evidence) / 'sdk-projection-intent.json', intent)
            sdk = root / 'sdk-root'
            projection_mkdir(sdk, custody)
            archive = root / 'official-sdk.tar.gz'
            digest = hashlib.sha512()
            count = 0
            with projection_output(archive, custody) as handle:
                with urllib.request.urlopen(SDK_ARCHIVE_URL, timeout=15) as response:
                    if response.geturl() != SDK_ARCHIVE_URL:
                        raise RuntimeError('SDK archive supplier URL differs')
                    while True:
                        projection_check_deadline(deadline)
                        chunk = response.read(1024 * 1024)
                        if not chunk:
                            break
                        count += len(chunk)
                        if count > SDK_ARCHIVE_MAX:
                            raise RuntimeError('SDK archive download quota')
                        digest.update(chunk)
                        handle.write(chunk)
                os.fchmod(handle.fileno(), 0o444)
            if digest.hexdigest() != SDK_ARCHIVE_SHA512:
                raise RuntimeError('Official SDK archive SHA512 differs')
            archive_info = archive.lstat()
            archive_identity = (archive_info.st_dev, archive_info.st_ino, archive_info.st_ctime_ns, archive_info.st_size)
            members = projection_archive_plan(archive, deadline)
            with tarfile.open(archive, 'r:gz') as source:
                for name, member in members:
                    projection_check_deadline(deadline)
                    path = sdk / name
                    for directory in reversed([path.parent, *path.parent.parents]):
                        if directory == sdk or sdk in directory.parents:
                            if not directory.exists():
                                projection_mkdir(directory, custody)
                    if member.isdir():
                        if not path.exists():
                            projection_mkdir(path, custody)
                    else:
                        with source.extractfile(member) as incoming, projection_output(path, custody) as target:
                            remaining = member.size
                            while remaining:
                                projection_check_deadline(deadline)
                                chunk = incoming.read(min(remaining, 1024 * 1024))
                                if not chunk:
                                    raise RuntimeError('SDK archive partial member')
                                target.write(chunk)
                                remaining -= len(chunk)
                            os.fchmod(target.fileno(), 0o555 if member.mode & 0o111 else 0o444)
            archive_after = archive.lstat()
            if (archive_after.st_dev, archive_after.st_ino, archive_after.st_ctime_ns, archive_after.st_size) != archive_identity:
                raise RuntimeError('Authenticated SDK archive changed during extraction')
            rows = projection_inventory(sdk, deadline)
            access = None
            if qualified_access:
                qualification_sdk_content(rows, count)
                access = publish_qualified_sdk_access(root, sdk, custody, rows, deadline)
            for index in range(0, len(rows), 16):
                write_sdk_projection_evidence(Path(evidence) / ('sdk-projection-inventory-' + str(index // 16).zfill(4) + '.json'),
                          {'schemaVersion': 1, 'index': index // 16, 'inventoryCount': len(rows), 'rows': rows[index:index + 16]})
            host = next(row for row in rows if row['path'] == 'dotnet')
            projection = {'root': str(root), 'sdkRoot': str(sdk), 'deadline': deadline,
                          'archiveSha512': SDK_ARCHIVE_SHA512, 'archiveBytes': count, 'sdkVersion': VSTEST_SDK_VERSION,
                          'rows': rows, 'hostSha256': host['sha256']}
            if access is not None:
                projection['droppedUserAccess'] = access
            summary = {'schemaVersion': 1, 'run': str(run_id), 'attempt': str(attempt),
                       'namespaceDevice': custody[root][0], 'namespaceInode': custody[root][1],
                       'archiveSha512': SDK_ARCHIVE_SHA512, 'archiveBytes': count,
                       'treeSha256': hashlib.sha256(json.dumps(rows, sort_keys=True).encode()).hexdigest(),
                       'inventoryCount': len(rows), 'inventoryFrames': (len(rows) + 15) // 16, 'sdkVersion': VSTEST_SDK_VERSION,
                       'lifetimeSeconds': 300, 'expiresUtc': expires, 'namespace': str(root), 'SDKStarted': False}
            if access is not None:
                summary['droppedUserAccess'] = access
            write_sdk_projection_evidence(Path(evidence) / 'sdk-projection.json', summary)
            ACTIVE_SDK_PROJECTIONS[id(projection)] = (projection, json.loads(json.dumps(projection)))
            yield projection
        except BaseException as error:
            failure = error
            raise
        finally:
            if projection is not None:
                ACTIVE_SDK_PROJECTIONS.pop(id(projection), None)
            try:
                if root not in custody:
                    if root.exists():
                        raise RuntimeError('SDK namespace creation custody unavailable')
                else:
                    with registration_window():
                        projection_cleanup(root, custody)
                release = {'namespaceAbsent': True, 'archiveAbsent': True, 'SDKStarted': False,
                           'handlesReleased': True, 'run': str(run_id), 'attempt': str(attempt)}
                write_sdk_projection_evidence(Path(evidence) / 'sdk-projection-release.json', release)
            except BaseException:
                try:
                    write_sdk_projection_evidence(Path(evidence) / 'sdk-projection-unreleased.json', {'namespaceAbsent': not root.exists(), 'custodyRetained': root.exists(), 'SDKStarted': False, 'run': str(run_id), 'attempt': str(attempt), 'namespace': str(root), 'device': custody.get(root, (0, 0))[0], 'inode': custody.get(root, (0, 0))[1], 'expiresUtc': expires, 'persistentData': False})
                except BaseException:
                    pass
                if failure is None:
                    raise
    @contextmanager
    def cancellable():
        previous = {}
        def cancel(signum, frame):
            raise KeyboardInterrupt('Owned SDK projection cancellation')
        try:
            for signum in (signal.SIGINT, signal.SIGTERM):
                previous[signum] = signal.signal(signum, cancel)
            with owned() as projection:
                yield projection
        finally:
            for signum, handler in previous.items():
                signal.signal(signum, handler)
    return cancellable()


def bind_trusted_projected_provider(executable, projection):
    active = ACTIVE_SDK_PROJECTIONS.get(id(projection))
    if active is None or active[0] is not projection or active[1] != projection:
        raise RuntimeError('Unissued or changed SDK projection capability')
    if projection['archiveSha512'] != SDK_ARCHIVE_SHA512 or projection['sdkVersion'] != VSTEST_SDK_VERSION:
        raise RuntimeError('Trusted SDK supplier seal differs')
    sdk = Path(projection['sdkRoot'])
    if Path(executable) != sdk / 'dotnet' or sdk.parent != Path(projection['root']):
        raise RuntimeError('Trusted SDK executable namespace differs')
    if projection_inventory(sdk, projection['deadline']) != projection['rows']:
        raise RuntimeError('Trusted full SDK graph changed')
    if 'droppedUserAccess' in projection:
        namespace = projection_trust(Path(projection['root']))
        if [namespace.st_dev, namespace.st_ino, namespace.st_ctime_ns, namespace.st_mode] != projection['droppedUserAccess']['namespaceIdentity']:
            raise RuntimeError('Published namespace custody changed')
    provider = bind_vstest_provider(executable, expected_host_sha=projection['hostSha256'])
    provider['supplierArchiveSha512'] = SDK_ARCHIVE_SHA512
    provider['fullSDKTreeSha256'] = hashlib.sha256(json.dumps(projection['rows'], sort_keys=True).encode()).hexdigest()
    return provider


def bind_qualification_projected_provider(executable, projection):
    # Content binding only: this does not mint SDK authority or enable the disabled CLI.
    provider = bind_trusted_projected_provider(executable, projection)
    digest = qualification_sdk_content(projection['rows'], projection['archiveBytes'])
    root = Path(projection['sdkRoot'])
    observed = {}
    for pin in [provider['host'], *provider['files']]:
        relative = Path(pin['path']).relative_to(root).as_posix()
        if relative in observed or type(pin['bytes']) is not int:
            raise ValueError('Qualified provider inventory differs')
        observed[relative] = (pin['bytes'], pin['sha256'])
    if observed != QUALIFICATION_PROVIDER_PINS:
        raise ValueError('Qualified provider exact content differs')
    provider['qualificationContentSha256'] = digest
    return provider



class SDKProjectionTrustError(RuntimeError):
    def __init__(self, path, component_index, info, is_link):
        super().__init__('SDK projection custody differs')
        self.anchor_role = 1 if Path(path) == SDK_PROJECTION_ANCHOR else 0
        self.closed_provider_error = VstestProviderTrustError(path, component_index, info, is_link, 0)


class VstestProviderTrustError(RuntimeError):
    def __init__(self, path, component_index, info, is_link, expected_uid):
        super().__init__('VSTest provider ownership or path differs')
        known = {Path('/usr/share/dotnet/dotnet'): 1,
                 **{Path('/usr/share/dotnet/sdk/10.0.401') / name: kind for name, kind in
                    [('vstest.console.dll', 2), ('vstest.console.deps.json', 3),
                     ('vstest.console.runtimeconfig.json', 4)]}}
        self.trust_witness = {'anchorKind': 1 if path in known else 0,
            'pathKind': known.get(path, 0), 'componentIndex': component_index,
            'uid': info.st_uid, 'gid': info.st_gid, 'mode': info.st_mode,
            'isLink': int(is_link), 'device': info.st_dev, 'inode': info.st_ino,
            'ctimeNs': info.st_ctime_ns, 'expectedUid': expected_uid,
            'reasonBits': (1 if info.st_uid != expected_uid else 0) |
                          (2 if info.st_mode & 0o022 else 0) | (4 if is_link else 0)}


def project_vstest_trust_failure(failure):
    if not isinstance(failure, VstestProviderTrustError):
        raise ValueError('Only closed provider trust failures can be projected')
    witness = dict(failure.trust_witness)
    bounds = {'anchorKind': (0, 1), 'pathKind': (0, 4), 'componentIndex': (0, 32),
        'uid': (0, 2**32-1), 'gid': (0, 2**32-1), 'mode': (0, 65535),
        'isLink': (0, 1), 'device': (0, 2**64-1), 'inode': (1, 2**64-1),
        'ctimeNs': (0, 2**63-1), 'expectedUid': (0, 0), 'reasonBits': (1, 7)}
    if set(witness) != set(bounds) or any(type(witness[k]) is not int or not lo <= witness[k] <= hi
                                         for k, (lo, hi) in bounds.items()):
        raise ValueError('Provider trust witness schema differs')
    reason = (1 if witness['uid'] != witness['expectedUid'] else 0) | \
             (2 if witness['mode'] & 0o022 else 0) | (4 if witness['isLink'] else 0)
    if reason != witness['reasonBits'] or (witness['anchorKind'] == 0) != (witness['pathKind'] == 0):
        raise ValueError('Provider trust witness predicates differ')
    return witness


def vstest_file_pin(path, expected_uid=0):
    path = Path(path)
    components = [path, *path.parents]
    if len(components) > 33:
        raise RuntimeError('VSTest provider ancestry exceeds quota')
    for component_index, component in enumerate(components):
        info = component.lstat()
        is_link = component.is_symlink()
        if is_link or info.st_uid != expected_uid or info.st_mode & 0o022:
            raise VstestProviderTrustError(path, component_index, info, is_link, expected_uid)
    before = identity(path)
    raw = bounded_bytes(path, 16 * 1024 * 1024)
    if not raw or identity(path) != before:
        raise RuntimeError('VSTest input unavailable or changed while binding')
    return {'path': str(path), 'identity': list(before), 'bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest()}


def bind_vstest_provider(executable, expected_host_sha=VSTEST_PROVIDER_HOST_SHA256):
    executable = Path(executable)
    host = vstest_file_pin(executable)
    if executable.name != 'dotnet' or host['sha256'] != expected_host_sha:
        raise RuntimeError('Exact reviewed VSTest provider host differs')
    directory = executable.parent / 'sdk' / VSTEST_SDK_VERSION
    pins = [vstest_file_pin(directory / name) for name in
            ('vstest.console.dll', 'vstest.console.deps.json', 'vstest.console.runtimeconfig.json')]
    if bounded_bytes(Path(pins[0]['path']), 16 * 1024 * 1024)[:2] != b'MZ':
        raise RuntimeError('SDK VSTest provider is not a PE assembly')
    for pin in pins[1:]:
        unique_json(bounded_bytes(Path(pin['path']), 16 * 1024 * 1024))
    directories = [{'path': str(path), 'identity': list(identity(path))} for path in
                   (directory, directory.parent, executable.parent)]
    return {'sdkVersion': VSTEST_SDK_VERSION, 'host': host, 'files': pins, 'directories': directories}


def bind_vstest_release(repository, admitted, pipeline):
    repository = Path(repository)
    candidates = sorted((repository / 'runner-results').glob('owned-build-*'))
    if len(candidates) > 64:
        raise RuntimeError('VSTest build inventory exceeds quota')
    matches = []
    for previous in candidates:
        context = unique_json(bounded_bytes(previous / 'phase-context.json', 4096))
        if (context.get('sourceBinding'), context.get('origin'), context.get('pipeline')) == (
                admitted.source_binding, admitted.origin, pipeline):
            matches.append(previous)
    if len(matches) != 1:
        raise RuntimeError('Exactly one original bound Release build required')
    previous = matches[0]
    status = unique_json(bounded_bytes(previous / 'results/phase-status.json', 4096))
    released = unique_json(bounded_bytes(previous / 'results/release-status.json', 4096))
    if status.get('phase') != 'build' or status.get('exitCode') != 0 or status.get('signal') is not None:
        raise RuntimeError('Original Release build did not pass')
    if any(released.get(key) is not True for key in
           ('sdkExited', 'ownedBackendsAbsent', 'handlesReleased', 'slotReleased', 'slotAbsent', 'cgroupAbsent')):
        raise RuntimeError('Original Release build owner did not release')
    graph = unique_json(bounded_bytes(previous / 'results/release-graph.json', 16384))
    expected = repository / TEST_RELEASE_RELATIVE
    rows = graph.get('assemblies', [])
    tests = [r for r in rows if r.get('assembly') == 'Legacy.Maliev.FileService.Tests']
    if graph.get('configuration') != 'Release' or len(rows) != 7 or len(tests) != 1:
        raise RuntimeError('Exact original Release test assembly witness missing')
    row = tests[0]
    if row.get('path') != str(expected) or not re.fullmatch('[a-f0-9]{64}', row.get('sha256', '')):
        raise RuntimeError('Original Release test assembly path or hash differs')
    for component in [expected, *expected.parents]:
        if component.is_symlink():
            raise RuntimeError('Release test assembly path contains link')
    before = identity(expected)
    raw = bounded_bytes(expected, LIMIT)
    if (len(raw) != row.get('bytes') or raw[:2] != b'MZ' or hashlib.sha256(raw).hexdigest() != row['sha256']
            or identity(expected) != before):
        raise RuntimeError('Original Release test assembly bytes changed')
    return {'path': str(expected), 'identity': list(before), 'bytes': len(raw), 'sha256': row['sha256'], 'buildRoot': str(previous)}



COLLECTOR_PACKAGE_SHA256 = '89e89497b1b9a55290e15eabc6111ed1e85ea74feed51043dc4008eb70104c8d'
COLLECTOR_PACKAGE_BYTES = 2243960


def collector_file_pin(path):
    path = Path(path)
    if len(path.parts) > 33 or not path.is_absolute() or ';' in str(path):
        raise RuntimeError('Collector input path differs')
    for component in (path, *path.parents):
        if component.is_symlink():
            raise RuntimeError('Collector input contains link')
    before = identity(path)
    raw = bounded_bytes(path, 16 * 1024 * 1024)
    if not raw or identity(path) != before:
        raise RuntimeError('Collector input changed while binding')
    return {'path': str(path), 'identity': list(before), 'bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest()}


def collector_subtree(directory, expected_files):
    """Close adapter discovery to exact authenticated regular files/directories."""
    if len(expected_files) != 57:
        raise RuntimeError('Collector expected subtree differs')
    expected_directories = {directory}
    for path in expected_files:
        expected_directories.update(parent for parent in path.parents if parent == directory or directory in parent.parents)
    pending = [directory]
    observed_files = set()
    directories = []
    seen = 0
    while pending:
        current = pending.pop()
        info = current.lstat()
        if (not stat.S_ISDIR(info.st_mode) or current.is_symlink()
                or getattr(info, 'st_file_attributes', 0) & getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0)):
            raise RuntimeError('Collector subtree directory is linked or nonregular')
        directories.append({'path': str(current), 'identity': list(identity(current))})
        with os.scandir(current) as entries:
            for entry in entries:
                seen += 1
                if seen > len(expected_files) + len(expected_directories) - 1:
                    raise RuntimeError('Collector physical subtree exceeds exact inventory')
                path = Path(entry.path)
                info = entry.stat(follow_symlinks=False)
                if (stat.S_ISLNK(info.st_mode)
                        or getattr(info, 'st_file_attributes', 0) & getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0)):
                    raise RuntimeError('Collector subtree contains link')
                if stat.S_ISDIR(info.st_mode) and path in expected_directories:
                    pending.append(path)
                elif stat.S_ISREG(info.st_mode) and path in expected_files:
                    observed_files.add(path)
                else:
                    raise RuntimeError('Collector subtree contains foreign or nonregular entry')
    if observed_files != expected_files or {Path(row['path']) for row in directories} != expected_directories:
        raise RuntimeError('Collector exact physical subtree differs')
    return sorted(directories, key=lambda row: row['path'])


def bind_vstest_collector(repository, assembly):
    repository = Path(repository)
    previous = Path(assembly['buildRoot'])
    if previous.parent != repository / 'runner-results' or not previous.name.startswith('owned-build-'):
        raise RuntimeError('Collector original build identity differs')
    packages = previous / 'home/.nuget/packages'
    asset_path = repository / 'Legacy.Maliev.FileService.Tests/obj/project.assets.json'
    asset_pin = collector_file_pin(asset_path)
    assets = unique_json(bounded_bytes(asset_path, 16 * 1024 * 1024))
    restore = assets['project']['restore']
    project = repository / 'Legacy.Maliev.FileService.Tests/Legacy.Maliev.FileService.Tests.csproj'
    if (restore['projectPath'] != str(project) or restore['projectStyle'] != 'PackageReference'
            or set(restore['sources']) != {'https://api.nuget.org/v3/index.json'}
            or set(assets['packageFolders']) != {str(packages) + '/'}
            or set(assets['targets']) != {'net10.0'}):
        raise RuntimeError('Collector original restore identity differs')
    library = assets['libraries']['coverlet.collector/6.0.4']
    build_relative = 'build/netstandard2.0/coverlet.collector.targets'
    if (library['type'] != 'package' or library['path'] != 'coverlet.collector/6.0.4'
            or list(assets['targets']['net10.0']['coverlet.collector/6.0.4']['build']) != [build_relative]):
        raise RuntimeError('Collector package identity differs')
    package_root = packages / 'coverlet.collector/6.0.4'
    nupkg = package_root / 'coverlet.collector.6.0.4.nupkg'
    package_pin = collector_file_pin(nupkg)
    raw = bounded_bytes(nupkg, 16 * 1024 * 1024)
    if (package_pin['bytes'] != COLLECTOR_PACKAGE_BYTES
            or package_pin['sha256'] != COLLECTOR_PACKAGE_SHA256
            or library['sha512'] != base64.b64encode(hashlib.sha512(raw).digest()).decode('ascii')):
        raise RuntimeError('Collector exact public package content differs')
    files = []
    directory = package_root / 'build/netstandard2.0'
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        infos = archive.infolist()
        if len(infos) != 64 or len({i.filename for i in infos}) != 64:
            raise RuntimeError('Collector package member inventory differs')
        expected_files = {package_root / info.filename for info in infos
                          if info.filename.startswith('build/netstandard2.0/')}
        directories = collector_subtree(directory, expected_files)
        for info in infos:
            if not info.filename.startswith('build/netstandard2.0/'):
                continue
            if (info.is_dir() or '..' in Path(info.filename).parts
                    or info.file_size > 16 * 1024 * 1024
                    or stat.S_ISLNK(info.external_attr >> 16)):
                raise RuntimeError('Collector package member differs')
            pin = collector_file_pin(package_root / info.filename)
            expected = archive.read(info)
            if pin['bytes'] != len(expected) or pin['sha256'] != hashlib.sha256(expected).hexdigest():
                raise RuntimeError('Restored collector file differs from exact public package')
            files.append(pin)
    if len(files) != 57 or build_relative not in library['files']:
        raise RuntimeError('Collector complete build inventory differs')
    if collector_subtree(directory, expected_files) != directories:
        raise RuntimeError('Collector physical subtree changed while binding')
    return {'directory': str(directory), 'directoryIdentity': list(identity(directory)),
            'asset': asset_pin, 'package': package_pin, 'files': files, 'directories': directories}


def recheck_vstest_collector(repository, assembly, collector):
    if bind_vstest_collector(repository, assembly) != collector:
        raise RuntimeError('Bound collector changed before exec')


def direct_vstest_command(phase, provider, assembly, results, collector=None):
    if phase not in {'focused', 'full'}:
        raise ValueError('Direct VSTest only applies to fixed test phases')
    directory = str(Path(assembly['path']).parent)
    command = ['exec', provider['files'][0]['path'], assembly['path'],
               '--Settings:scripts/owned-file-tests.runsettings', '--TestAdapterPath:' + directory,
               '--Logger:trx;LogFileName=file-' + phase + '.trx', '--ResultsDirectory:' + str(results)]
    if phase == 'focused':
        command.append('--TestCaseFilter:' + FIXED_FOCUSED_FILTER)
    else:
        if collector is None:
            raise RuntimeError('Bound collector required for full phase')
        command[4] += ';' + collector['directory']
        command.append('--Collect:XPlat Code Coverage')
    return command


def recheck_vstest_inputs(provider, assembly):
    for directory in provider['directories']:
        path = Path(directory['path'])
        if path.is_symlink() or list(identity(path)) != directory['identity']:
            raise RuntimeError('Bound VSTest provider directory changed before exec')
    for pin in [provider['host'], *provider['files']]:
        if vstest_file_pin(Path(pin['path'])) != pin:
            raise RuntimeError('Bound VSTest provider changed before exec')
    pins = [provider['host'], *provider['files'], assembly]
    for pin in pins:
        path = Path(pin['path'])
        if path.is_symlink() or list(identity(path)) != pin['identity']:
            raise RuntimeError('Bound VSTest input identity changed before exec')
        raw = bounded_bytes(path, LIMIT)
        if len(raw) != pin['bytes'] or hashlib.sha256(raw).hexdigest() != pin['sha256']:
            raise RuntimeError('Bound VSTest input bytes changed before exec')


def qualified_phase_deadline(projection, remaining, now):
    """Never extend custody, grant or SDK ceilings; reserve30s for exact cleanup."""
    if projection is None:
        return now + remaining
    if type(remaining) not in (int, float) or remaining <= 0 or remaining > SDK_SECONDS:
        raise ValueError("Original finite phase budget differs")
    bind_qualification_projected_provider(Path(projection["sdkRoot"]) / "dotnet", projection)
    deadline = min(now + remaining, projection["deadline"]) - 30
    if deadline <= time.monotonic():
        raise RuntimeError("Qualified custody has no execution budget before cleanup reserve")
    return deadline


def run_owned_phase(projection=None, current_profile=None):
    global RPC_DEADLINE
    if sys.platform != 'linux' or len(sys.argv) != 3 or sys.argv[1] not in {'build', 'focused', 'full', 'format', 'audit'}:
        raise RuntimeError('Only the reviewed explicit Linux phase is supported')
    phase, executable = sys.argv[1], Path(sys.argv[2]).resolve(strict=True)
    admitted = admission(os.environ, phase, Path.cwd(), dt.datetime.now(dt.timezone.utc))
    pipeline = os.environ['GITHUB_RUN_ID'] + ':' + os.environ['GITHUB_RUN_ATTEMPT']
    if current_profile is not None:
        current_profile.check_admission(admitted,Path.cwd(),phase)
    verify_predecessor(Path.cwd(), admitted, pipeline, current_profile)
    evidence_uid = int(os.environ.get('MALIEV_FILE_EVIDENCE_UID', '-1'))
    evidence_gid = int(os.environ.get('MALIEV_FILE_EVIDENCE_GID', '-1'))
    if evidence_uid <= 0 or evidence_gid < 0:
        raise RuntimeError('Original hosted evidence owner is required')
    import pwd
    account = pwd.getpwuid(evidence_uid)
    if account.pw_gid != evidence_gid:
        raise RuntimeError('Original owner primary group differs')
    original_groups = sorted(set(os.getgrouplist(account.pw_name, evidence_gid)))
    if len(original_groups) > 32:
        raise RuntimeError('Original supplementary group inventory exceeds cap')
    if not executable.is_file() or executable.name != 'dotnet':
        raise RuntimeError('Exact SDK executable unavailable')
    if os.execve not in os.supports_fd:
        raise RuntimeError('Exact descriptor-based SDK exec is unsupported')
    executable_identity = identity(executable)
    executable_sha = hashlib.sha256(executable.read_bytes()).hexdigest()
    memory = dict(line.split(':', 1) for line in Path('/proc/meminfo').read_text().splitlines())
    if int(memory['MemAvailable'].split()[0]) < 4096 * 1024:
        raise RuntimeError('Memory below 4096 MiB')
    if not (CGROUP_ROOT / 'cgroup.controllers').exists() or os.geteuid() != 0:
        raise RuntimeError('Exact root-owned cgroup-v2 boundary unavailable')
    # Read-only census is admission, never a process-name cleanup selector.
    for path in Path('/proc').glob('[0-9]*/exe'):
        try:
            if path.resolve(strict=True).name == 'dotnet':
                raise RuntimeError('Another SDK process is active')
        except FileNotFoundError:
            pass
    qualified_deadline = None
    if projection is not None:
        if executable != Path(projection["sdkRoot"]) / "dotnet":
            raise ValueError("Exact qualified phase executable differs")
        qualified_deadline = qualified_phase_deadline(projection, admitted.remaining_seconds(dt.datetime.now(dt.timezone.utc)), time.monotonic())
    consume_once(admitted, '/tmp/maliev-file-phase-claims')
    run = uuid.uuid4().hex
    root = Path.cwd() / 'runner-results' / ('owned-' + phase + '-' + run)
    root.mkdir(parents=True, mode=0o700, exist_ok=False)
    (root / 'intents').mkdir(mode=0o700)
    (root / 'results').mkdir(mode=0o700)
    (root / 'home').mkdir(mode=0o700)
    write_new(root / 'phase-context.json', {'origin': admitted.origin, 'sourceBinding': admitted.source_binding,
        'phase': phase, 'pipeline': pipeline, 'originalExpiryUtc': admitted.expires_utc.isoformat()})
    group = CGROUP_ROOT / ('maliev-file-' + run)
    slot = Path('/tmp/maliev-file-sdk-exclusive.lock')
    slot_value = {'run': run, 'root': str(root), 'ownerPid': os.getpid()}
    slot_raw = (json.dumps(slot_value, sort_keys=True, separators=(',', ':')) + '\n').encode()
    slot_identity = None
    slot_descriptor = None
    slot_created = False
    group_identity = None
    group_descriptor = None
    group_created = False
    remaining = admitted.remaining_seconds(dt.datetime.now(dt.timezone.utc))
    deadline = qualified_deadline if projection is not None else time.monotonic() + remaining
    remaining = min(remaining, deadline - time.monotonic())
    phase_expiry = min(admitted.expires_utc, dt.datetime.now(dt.timezone.utc) + dt.timedelta(seconds=remaining))
    project = 'Legacy.Maliev.FileService.Tests/Legacy.Maliev.FileService.Tests.csproj'
    common = ['-c', 'Release', '--disable-build-servers', '--tl:off', '-m:1', '/p:UseSharedCompilation=false', '/nr:false', '/warnaserror', '/p:ShouldUnsetParentConfigurationAndPlatform=false']
    commands = {'build': ['build', project, *common],
        'format': ['format', 'Legacy.Maliev.FileService.slnx', '--verify-no-changes', '--no-restore'],
        'audit': ['list', 'Legacy.Maliev.FileService.slnx', 'package', '--vulnerable', '--include-transitive', '--no-restore',
                  '--format', 'json', '--output-version', '1', '--source', 'https://api.nuget.org/v3/index.json']}
    vstest_provider = vstest_assembly = vstest_collector = None
    if phase in {'focused', 'full'} and current_profile is None:
        vstest_provider = (bind_qualification_projected_provider(executable, projection)
                           if projection is not None else bind_vstest_provider(executable))
        vstest_assembly = bind_vstest_release(Path.cwd(), admitted, pipeline)
        if phase == 'full':
            vstest_collector = bind_vstest_collector(Path.cwd(), vstest_assembly)
        commands[phase] = direct_vstest_command(phase, vstest_provider, vstest_assembly, root / 'results', vstest_collector)
        write_new(root / 'vstest-inputs.json', {'provider': vstest_provider, 'assembly': vstest_assembly,
            'invocation': 'direct-sdk-assembly-exec', 'phase': phase, 'collector': vstest_collector})
    audit_identity = restored_audit_identity(Path.cwd()) if phase == 'audit' else None
    env = {key: value for key, value in os.environ.items() if key in {'PATH', 'DOTNET_ROOT', 'MalievWorkspaceRoot'}}
    env.update(HOME=str(root / 'home'), DOTNET_CLI_HOME=str(root / 'home'))
    env.update(MALIEV_FILE_RESOURCE_ADMISSION='owned-finite-v1', MALIEV_FILE_SDK_RUN=run,
               MALIEV_FILE_SDK_ROOT=str(root), DOTNET_CLI_DO_NOT_USE_MSBUILD_SERVER='1',
               MSBUILDDISABLENODEREUSE='1', DOTNET_CLI_TELEMETRY_OPTOUT='1', DOTNET_CLI_UI_LANGUAGE='en-US',
               DOTNET_NOLOGO='1', DOTNET_SKIP_FIRST_TIME_EXPERIENCE='1',
               USE_LOCAL_MALIEV_DEPENDENCIES='true', GITHUB_ACTIONS='false', DOTNET_PROCESSOR_COUNT='1')
    if vstest_provider is not None:
        env.update(VSTEST_DOTNET_ROOT_PATH=str(executable.parent), VSTEST_DOTNET_ROOT_ARCHITECTURE='X64')
    read_fd = write_fd = error_read_fd = error_write_fd = None
    child = handle = exec_fd = None
    first_failure = None
    exited = False
    output = None
    output_descriptor = None
    error_output = None
    error_output_descriptor = None
    pending_descriptors = {}
    sdk_dispatched = False
    census_state = {'attempted': 0, 'dropped': 0, 'nextPoll': 0, 'lastDenied': 0,
                    'nearRecorded': False, 'unavailableRecorded': False}
    stderr_emissions = []
    stderr_offset = 0
    stderr_dropped = 0
    stop_state = {'deadline': None, 'primary': False, 'groups': set()}
    try:
        with registration_window():
            descriptor = os.open(slot, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            slot_descriptor = descriptor
            slot_created = True
            pending_descriptors[descriptor] = None
        slot_identity = retained_creation_identity(slot, descriptor)
        pending_descriptors[descriptor] = slot_identity
        with os.fdopen(descriptor, 'wb', closefd=False) as stream:
            stream.write(slot_raw)
            stream.flush()
            os.fsync(descriptor)
        with registration_window():
            os.close(descriptor)
            del pending_descriptors[descriptor]
            slot_descriptor = None
        with registration_window():
            group.mkdir()
            group_created = True
        with registration_window():
            group_descriptor = os.open(group, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
            pending_descriptors[group_descriptor] = None
        group_identity = retained_creation_identity(group, group_descriptor)
        pending_descriptors[group_descriptor] = group_identity
        if identity(group) != group_identity:
            raise RuntimeError('Created cgroup pathname differs from retained directory handle')
        for name, value in {'memory.max': '2147483648', 'pids.max': '64', 'cpu.max': '100000 100000'}.items():
            (group / name).write_text(value)
        RPC_DEADLINE = time.monotonic() + 20
        status, daemon = docker('GET', '/info')
        if status != 200 or daemon.get('OSType') != 'linux' or not daemon.get('ID'):
            raise RuntimeError('Reviewed local Linux daemon is unavailable')
        write_new(root / 'admission.json', {'run': run, 'cgroup': '/' + group.name, 'daemon': daemon['ID'],
                  'expiresUtc': phase_expiry.isoformat(),
                  'origin': admitted.origin, 'sourceBinding': admitted.source_binding, 'phase': phase,
                  'dotnetPath': str(executable), 'dotnetSha256': executable_sha})
        with registration_window():
            exec_fd = os.open(executable, os.O_RDONLY)
            pending_descriptors[exec_fd] = None
        pending_descriptors[exec_fd] = descriptor_identity(exec_fd)
        if pending_descriptors[exec_fd] != executable_identity:
            raise RuntimeError('SDK executable inode changed before acquisition')
        with registration_window():
            read_fd, write_fd = os.pipe()
            pending_descriptors[read_fd] = pending_descriptors[write_fd] = None
        pending_descriptors[read_fd] = descriptor_identity(read_fd)
        pending_descriptors[write_fd] = descriptor_identity(write_fd)
        with registration_window():
            error_read_fd, error_write_fd = os.pipe()
            pending_descriptors[error_read_fd] = pending_descriptors[error_write_fd] = None
        pending_descriptors[error_read_fd] = descriptor_identity(error_read_fd)
        pending_descriptors[error_write_fd] = descriptor_identity(error_write_fd)
        with registration_window():
            output = (root / 'sdk.log').open('xb')
            output_descriptor = output.fileno()
        with registration_window():
            error_output = (root / 'sdk.stderr.log').open('xb')
            error_output_descriptor = error_output.fileno()
        for path in (root, root / 'intents', root / 'results', root / 'home', root / 'admission.json'):
            os.chown(path, evidence_uid, evidence_gid, follow_symlinks=False)
        parent = os.getpid()
        with registration_window() as child_mask:
            child = os.fork()
            if child == 0:
                try:
                    os.close(read_fd)
                    os.close(error_read_fd)
                    os.dup2(write_fd, 1)
                    os.dup2(error_write_fd, 2)
                    os.close(write_fd)
                    os.close(error_write_fd)
                    drop_child_identity(evidence_uid, evidence_gid, original_groups)
                    guard_child_parent(parent, child_mask)
                    os.kill(os.getpid(), signal.SIGSTOP)
                    if projection is not None:
                        bind_qualification_projected_provider(executable, projection)
                        projection_check_deadline(deadline)
                    if vstest_provider is not None:
                        recheck_vstest_inputs(vstest_provider, vstest_assembly)
                    if vstest_collector is not None:
                        recheck_vstest_collector(Path.cwd(), vstest_assembly, vstest_collector)
                    if current_profile is not None:
                        import sys as current_sys
                        current_profile.execute_steps(current_sys.modules[__name__],exec_fd,executable,phase,root,env,deadline,projection)
                        os._exit(0)
                    os.execve(exec_fd, [str(executable), *commands[phase]], env)
                except BaseException:
                    os._exit(127)
        with registration_window():
            handle = os.pidfd_open(child)
            pending_descriptors[handle] = None
        pending_descriptors[handle] = descriptor_identity(handle)
        with registration_window():
            os.close(write_fd)
            del pending_descriptors[write_fd]
            write_fd = None
            os.close(error_write_fd)
            del pending_descriptors[error_write_fd]
            error_write_fd = None
        while True:
            with registration_window():
                waited, state = os.waitpid(child, os.WUNTRACED | os.WNOHANG)
                if waited == child and (os.WIFEXITED(state) or os.WIFSIGNALED(state)):
                    exited = True
            if waited == child:
                break
            if time.monotonic() >= deadline:
                raise TimeoutError('Pre-exec SDK admission timed out')
            time.sleep(.01)
        if waited != child or not os.WIFSTOPPED(state):
            exited = os.WIFEXITED(state) or os.WIFSIGNALED(state)
            raise RuntimeError('Pre-exec SDK reservation unavailable')
        (group / 'cgroup.procs').write_text(str(child))
        if Path('/proc/' + str(child) + '/cgroup').read_text().strip() != '0::/' + group.name:
            raise RuntimeError('SDK child cgroup assignment failed')
        child_birth = Path('/proc/' + str(child) + '/stat').read_text().rsplit(')', 1)[1].split()[19]
        write_new(root / 'child.json', {'pid': child,
                                      'startTicks': child_birth,
                                      'cgroupIdentity': group_identity})
        sdk_dispatched = True
        retain_resource_snapshot(root, group, group_identity, 'admitted')
        try:
            retain_task_census(root, group, group_identity, child, child_birth, census_state, 0)
        except BaseException:
            pass
        signal.pidfd_send_signal(handle, signal.SIGCONT)
        os.set_blocking(read_fd, False)
        os.set_blocking(error_read_fd, False)
        count = 0
        readers = {read_fd, error_read_fd}
        while readers:
            poll_task_census(root, group, group_identity, child, child_birth, census_state)
            if time.monotonic() >= deadline:
                raise TimeoutError('Finite SDK phase deadline')
            ready, _, _ = select.select(list(readers), [], [], .1)
            for descriptor in ready:
                block = os.read(descriptor, min(65536, LIMIT - count + 1))
                if not block:
                    readers.remove(descriptor)
                    continue
                if count + len(block) > LIMIT:
                    raise RuntimeError('SDK output quota exceeded')
                (error_output if descriptor == error_read_fd else output).write(block)
                count += len(block)
                if descriptor == error_read_fd:
                    if len(stderr_emissions) < 32:
                        stderr_emissions.append({'monotonic': time.monotonic(), 'offset': stderr_offset,
                            'bytes': len(block), 'sdkOwnerPid': child, 'sdkOwnerStartTicks': child_birth,
                            'emitterPidAvailable': False})
                        try:
                            persist(root / ('stderr-sample-' + str(len(stderr_emissions) - 1).zfill(2) + '.json'), {'schemaVersion': 1,
                                'events': stderr_emissions, 'droppedChunks': stderr_dropped,
                                'totalBytes': stderr_offset + len(block)})
                        except BaseException:
                            pass  # Exact raw stderr remains authoritative; cleanup must proceed.
                        retain_resource_snapshot(root, group, group_identity, 'stderr-' + str(len(stderr_emissions) - 1).zfill(2))
                    else:
                        stderr_dropped += 1
                    stderr_offset += len(block)
        while True:
            with registration_window():
                waited, state = os.waitpid(child, os.WNOHANG)
                if waited == child:
                    exited = True
            if waited == child:
                break
            if time.monotonic() >= deadline:
                raise TimeoutError('SDK exited-output but phase still running')
            poll_task_census(root, group, group_identity, child, child_birth, census_state)
            time.sleep(.01)
        exited = waited == child
        sdk_failure = RuntimeError('SDK phase failed') if not exited or not os.WIFEXITED(state) or os.WEXITSTATUS(state) != 0 else None
        try:
            output.flush()
            error_output.flush()
            persist(root / 'results' / 'phase-status.json', {'run': run, 'phase': phase,
                    'waitStatus': state, 'exitCode': os.WEXITSTATUS(state) if os.WIFEXITED(state) else None,
                    'signal': os.WTERMSIG(state) if os.WIFSIGNALED(state) else None})
            if phase == 'build':
                diagnostics = project_build_diagnostics(
                    bounded_bytes(root / 'sdk.log', LIMIT), bounded_bytes(root / 'sdk.stderr.log', LIMIT), Path.cwd())
                if sdk_failure is not None and diagnostics['diagnosticAvailability'] == 'none':
                    diagnostics['diagnosticAvailability'] = 'unavailable'
                persist(root / 'results' / 'build-diagnostics.json', diagnostics)
        except BaseException:
            if sdk_failure is None:
                raise
            # Publication cannot replace the original unsuccessful SDK status.
        if sdk_failure is not None:
            raise sdk_failure
        if current_profile is not None:
            import sys as current_sys
            current_profile.verify_phase(current_sys.modules[__name__],phase,root)
        if phase in {'focused', 'full'} and current_profile is None:
            verify_test_results(root / 'results', phase)
        if phase == 'audit' and current_profile is None:
            verify_audit(bounded_bytes(root / 'sdk.log', LIMIT), bounded_bytes(root / 'sdk.stderr.log', LIMIT), audit_identity)
        if phase == 'build' and current_profile is None:
            text = (root / 'sdk.log').read_text(errors='strict')
            if len(re.findall(r'^\s*0 Warning\(s\)\s*$', text, re.M)) != 1 or len(re.findall(r'^\s*0 Error\(s\)\s*$', text, re.M)) != 1:
                raise RuntimeError('Build lacks actual zero-warning zero-error summary')
            verify_release_graph(Path.cwd(), env.get('MalievWorkspaceRoot'), root / 'results')
    except BaseException as failure:
        first_failure = failure
    finally:
        if sdk_dispatched:
            try:
                persist(root / 'stderr-summary.json', {'schemaVersion': 1,
                    'events': stderr_emissions, 'droppedChunks': stderr_dropped, 'totalBytes': stderr_offset})
            except BaseException:
                pass
        if group_identity is not None and sdk_dispatched:
            retain_resource_snapshot(root, group, group_identity, 'before-cleanup')
            try:
                retain_task_census(root, group, group_identity, child, child_birth, census_state, 3)
                persist(root / 'task-census-summary.json', {'schemaVersion': 1,
                    'attempted': census_state['attempted'], 'dropped': census_state['dropped']})
            except BaseException:
                pass
        # Finite attempts, same owner retained until all physical release succeeds.
        errors = 0
        while True:
            try:
                RPC_DEADLINE = time.monotonic() + 20
                # Retry transient metadata faults on the same retained creation
                # descriptors, never by treating a fresh path lookup as birth.
                if slot_created and slot_identity is None and slot_descriptor is not None:
                    slot_identity = retained_creation_identity(slot, slot_descriptor)
                    pending_descriptors[slot_descriptor] = slot_identity
                if group_created and group_identity is None and group_descriptor is not None:
                    group_identity = retained_creation_identity(group, group_descriptor)
                    pending_descriptors[group_descriptor] = group_identity
                if group_created and group_identity is None or slot_created and slot_identity is None:
                    raise RuntimeError('Created ownership primitive identity is unverified; retain claim')
                # Also covers a forked child still stopped before cgroup assignment.
                if child is not None and not exited:
                    with registration_window():
                        waited, _ = os.waitpid(child, os.WNOHANG)
                        if waited == child:
                            exited = True
                    if waited == child:
                        exited = True
                    else:
                        graceful_stop(child, handle, group, group_identity, pending_descriptors, stop_state)
                if group_identity is not None:
                    if identity(group) != group_identity:
                        raise RuntimeError('Cgroup immutable identity changed')
                    if not current_group_empty(group):
                        graceful_stop(None, None, group, group_identity, pending_descriptors, stop_state)
                        until = time.monotonic() + 20
                        while not current_group_empty(group):
                            if time.monotonic() >= until:
                                raise TimeoutError('Exact cgroup exit unverified')
                            time.sleep(.05)
                if child is not None and not exited:
                    with registration_window():
                        waited, _ = os.waitpid(child, os.WNOHANG)
                        if waited == child:
                            exited = True
                    if waited != child:
                        raise RuntimeError('Exact SDK child unreaped')
                    exited = True
                if group_identity is not None and sdk_dispatched:
                    recover_backends(root, run, group)
                for descriptor, expected in list(pending_descriptors.items()):
                    try:
                        actual = descriptor_identity(descriptor)
                    except OSError as failure:
                        if failure.errno != 9:
                            raise
                        del pending_descriptors[descriptor]
                        continue
                    if expected is None:
                        pending_descriptors[descriptor] = actual
                    elif actual != expected:
                        raise RuntimeError('Owned descriptor identity changed')
                    with registration_window():
                        os.close(descriptor)
                        del pending_descriptors[descriptor]
                if output is not None:
                    if output.closed:
                        try:
                            descriptor_identity(output_descriptor)
                        except OSError as failure:
                            if failure.errno != 9:
                                raise
                        else:
                            raise RuntimeError('Closed output wrapper still has a live descriptor')
                    else:
                        output.flush()
                        os.fsync(output.fileno())
                        with registration_window():
                            output.close()
                            output = None
                    output = None
                if error_output is not None:
                    if error_output.closed:
                        try:
                            descriptor_identity(error_output_descriptor)
                        except OSError as failure:
                            if failure.errno != 9:
                                raise
                        else:
                            raise RuntimeError('Closed error wrapper still has a live descriptor')
                    else:
                        error_output.flush()
                        os.fsync(error_output.fileno())
                        with registration_window():
                            error_output.close()
                            error_output = None
                    error_output = None
                persist(root / 'graceful-stop.json', {'run': run, 'requested': stop_state['deadline'] is not None,
                    'originalGraceDeadlineMonotonic': stop_state['deadline'], 'finiteGraceSeconds': 5,
                    'primaryTermRequested': stop_state['primary'], 'groupTermBirths': sorted(stop_state['groups'])})
                persist(root / 'cleanup-barrier.json', {'run': run, 'sdkExited': True,
                         'ownedBackendsAbsent': True, 'handlesReleased': True, 'slotReleased': False})
                break
            except BaseException as failure:
                if first_failure is None:
                    first_failure = failure
                errors += 1
                if errors <= 16 or errors % 180 == 0 and errors // 180 <= 32:
                    try:
                        write_new(root / ('quarantine-' + str(errors) + '.json'),
                                  {'failureType': type(failure).__name__, 'attempt': errors, 'released': False})
                    except BaseException:
                        pass  # Journal failure never abandons retained cleanup ownership.
                try:
                    time.sleep(5)
                except BaseException as failure:
                    if first_failure is None:
                        first_failure = failure
        # Partial slot writes are still owned by their exclusive creation inode.
        # Release errors remain supervised; never abandon a failed rmdir/unlink.
        while group_identity is not None or slot_identity is not None:
            try:
                if group_identity is not None:
                    if identity(group) != group_identity:
                        raise RuntimeError('Exact cgroup release identity changed')
                    with registration_window():
                        group.rmdir()
                        group_identity = None
                if slot_identity is not None:
                    if identity(slot) != slot_identity or not slot_raw.startswith(bounded_bytes(slot, len(slot_raw))):
                        raise RuntimeError('Exact SDK slot identity or partial prefix changed')
                    with registration_window():
                        slot.unlink()
                        slot_identity = None
            except BaseException as failure:
                if first_failure is None:
                    first_failure = failure
                try:
                    time.sleep(5)
                except BaseException:
                    pass
        try:
            persist(root / 'results' / 'release-status.json', released_primitive_receipt(run, group, slot))
        except BaseException as failure:
            if first_failure is None:
                first_failure = failure
        # Private while running; return only this run's evidence to the original
        # hosted checkout owner after physical cleanup and exact claim release.
        try:
            for directory, directories, files in os.walk(root, followlinks=False):
                paths = [Path(directory), *[Path(directory) / item for item in directories + files]]
                for path in paths:
                    if path.is_symlink():
                        raise RuntimeError('Foreign symlink in owned evidence root')
                    os.chown(path, evidence_uid, evidence_gid, follow_symlinks=False)
        except BaseException as failure:
            if first_failure is None:
                first_failure = failure
            else:
                try:
                    print('Secondary final evidence ownership transfer fault: ' + type(failure).__name__, file=sys.stderr)
                except BaseException:
                    pass  # Diagnostic failure cannot replace the first owned failure.
    if first_failure is not None:
        raise first_failure

def census_ids(raw):
    values = raw.decode('ascii', errors='strict').split()
    if len(values) > 64 or len(values) != len(set(values)) or any(
            not re.fullmatch(r'[1-9][0-9]{0,9}', value) or int(value) > 2147483647 for value in values):
        raise ValueError('Closed census numeric inventory differs')
    return sorted(int(value) for value in values)


def census_stat(raw, expected_pid):
    prefix, fields = raw.rsplit(b')', 1)
    if prefix.split(b'(', 1)[0].strip() != str(expected_pid).encode('ascii'):
        raise ValueError('Census stat identity differs')
    fields = fields.split()
    if len(fields) < 20 or not fields[19].isdigit() or int(fields[19]) <= 0:
        raise ValueError('Census birth unavailable')
    # No raw comm, path, cmdline, environment or exception strings are retained.
    states = {b'R': 1, b'S': 2, b'D': 3, b'Z': 4, b'T': 5, b't': 6, b'X': 7, b'I': 8}
    return int(fields[19]), states.get(fields[0], 0)


def owned_task_census(group, expected, sdk_pid, sdk_birth, proc_root=Path('/proc')):
    if identity(group) != expected or not re.fullmatch(r'maliev-file-[a-f0-9]{32}', group.name):
        raise ValueError('Census exact group differs')
    current = bounded_bytes(group / 'pids.current', 4096).strip()
    denied = bounded_bytes(group / 'pids.events', 4096).strip()
    peak = bounded_bytes(group / 'pids.peak', 4096).strip()
    if not current.isdigit() or not peak.isdigit() or not re.fullmatch(rb'max [0-9]+', denied):
        raise ValueError('Census fixed counters unavailable')
    counters = {'current': int(current), 'peak': int(peak), 'denied': int(denied.split()[1])}
    before = census_ids(bounded_bytes(group / 'cgroup.procs', 4096))
    tids_before = census_ids(bounded_bytes(group / 'cgroup.threads', 4096))
    members, total = [], 0
    hints = {b'.NET TP Worker': 1, b'.NET TP Gate': 2, b'.NET Timer': 3,
             b'.NET Finalizer': 4, b'.NET Server GC': 5, b'DefaultSocketMa': 6,
             b'Console logger ': 7, b'xUnit.net worke': 8, b'.NET Long Runni': 9}
    for pid in before:
        directory = proc_root / str(pid)
        birth, state = census_stat(bounded_bytes(directory / 'stat', 4096), pid)
        if pid == sdk_pid and str(birth) != sdk_birth:
            raise ValueError('Original SDK process birth differs')
        if bounded_bytes(directory / 'cgroup', 4096).decode('ascii').splitlines() != ['0::/' + group.name]:
            raise ValueError('Census member is foreign')
        executable = os.readlink(directory / 'exe')
        executable_identity = identity(directory / 'exe')
        basename = Path(executable).name
        executable_kind = 1 if basename == 'dotnet' else 2 if re.fullmatch(r'python3(?:\.[0-9]+)?', basename) else 0
        task_paths = []
        for task_path in (directory / 'task').iterdir():
            task_paths.append(task_path)
            if len(task_paths) + total > 64:
                raise ValueError('Census task cap differs')
        tasks = []
        for task_path in sorted(task_paths, key=lambda p: int(p.name) if p.name.isdigit() else -1):
            tid = census_ids(task_path.name.encode('ascii'))
            if len(tid) != 1:
                raise ValueError('Census task identity unavailable')
            tid = tid[0]
            task_birth, task_state = census_stat(bounded_bytes(task_path / 'stat', 4096), tid)
            comm = bounded_bytes(task_path / 'comm', 64).rstrip(b'\n')
            hint = hints.get(comm, 0)
            task_after, _ = census_stat(bounded_bytes(task_path / 'stat', 4096), tid)
            if task_after != task_birth:
                raise ValueError('Census task birth changed')
            tasks.append({'tid': tid, 'startTicks': task_birth, 'state': task_state, 'nameHint': hint})
        after, _ = census_stat(bounded_bytes(directory / 'stat', 4096), pid)
        if after != birth or os.readlink(directory / 'exe') != executable or identity(directory / 'exe') != executable_identity or identity(group) != expected:
            raise ValueError('Census process identity changed')
        if bounded_bytes(directory / 'cgroup', 4096).decode('ascii').splitlines() != ['0::/' + group.name]:
            raise ValueError('Census member moved')
        members.append({'pid': pid, 'startTicks': birth, 'state': state,
                        'role': 1 if pid == sdk_pid else 2, 'executableKind': executable_kind,
                        'executableIdentity': list(executable_identity), 'tasks': tasks})
        total += len(tasks)
    after = census_ids(bounded_bytes(group / 'cgroup.procs', 4096))
    tids_after = census_ids(bounded_bytes(group / 'cgroup.threads', 4096))
    if identity(group) != expected:
        raise ValueError('Census group changed')
    observed = sorted(task['tid'] for member in members for task in member['tasks'])
    return {'members': members, 'taskCount': total, 'pidsCounters': counters,
            'membershipStable': before == after and tids_before == tids_after == observed}


def retain_task_census(root, group, expected, sdk_pid, sdk_birth, state, reason):
    # Numeric reasons: admitted0, near-limit1, denial-counter-change2, before-cleanup3, unavailable4.
    if state['attempted'] >= 16:
        state['dropped'] += 1
        return
    sequence = state['attempted']; state['attempted'] += 1
    try:
        value = {'schemaVersion': 1, 'sequence': sequence, 'reason': reason,
                 'utcUnixNs': time.time_ns(), 'monotonic': time.monotonic(),
                 'sdkOwnerPid': sdk_pid, 'sdkOwnerStartTicks': int(sdk_birth),
                 'available': True, 'census': owned_task_census(group, expected, sdk_pid, sdk_birth)}
        if len((json.dumps(value, sort_keys=True, separators=(',', ':')) + '\n').encode('utf-8')) > 16384:
            raise ValueError('Census evidence byte cap differs')
    except BaseException as failure:
        value = {'schemaVersion': 1, 'sequence': sequence, 'reason': reason, 'available': False,
                 'failureKind': 1 if isinstance(failure, OSError) else 2 if isinstance(failure, ValueError) else 0}
    try:
        persist(root / ('task-census-' + str(sequence).zfill(2) + '.json'), value)
    except BaseException:
        pass  # Evidence failure cannot replace the SDK failure or stop mandatory cleanup.


def poll_task_census(root, group, expected, sdk_pid, sdk_birth, state):
    try:
        now = time.monotonic()
        if now < state['nextPoll']:
            return
        state['nextPoll'] = now + 1  # Bounded one-Hz observation; no helper or extra thread.
        if identity(group) != expected:
            raise ValueError('Census poll group differs')
        current = bounded_bytes(group / 'pids.current', 4096).strip()
        denied = bounded_bytes(group / 'pids.events', 4096).strip()
        if not current.isdigit() or not re.fullmatch(rb'max [0-9]+', denied):
            raise ValueError('Census poll counters differ')
        current, denied = int(current), int(denied.split()[1])
        if denied != state['lastDenied']:
            state['lastDenied'] = denied
            retain_task_census(root, group, expected, sdk_pid, sdk_birth, state, 2)
        elif current >= 60 and not state['nearRecorded']:
            state['nearRecorded'] = True
            retain_task_census(root, group, expected, sdk_pid, sdk_birth, state, 1)
    except BaseException:
        if not state['unavailableRecorded']:
            state['unavailableRecorded'] = True
            try:
                retain_task_census(root, group, expected, sdk_pid, sdk_birth, state, 4)
            except BaseException:
                pass


def resource_snapshot(group, expected):
    """Read fixed numeric counters only from the exact retained cgroup."""
    if identity(group) != expected:
        raise RuntimeError('Diagnostic cgroup identity differs')
    counters = {}
    for name in ('memory.events', 'memory.current', 'memory.peak', 'memory.max',
                 'pids.events', 'pids.current', 'pids.peak', 'pids.max'):
        try:
            raw = bounded_bytes(group / name, 4096).decode('ascii', errors='strict')
            lines = raw.splitlines()
            if not lines or any(not re.fullmatch(r'(?:[a-z_]+ )?[0-9]+', line) for line in lines):
                raise ValueError('Non-numeric diagnostic counter')
            counters[name] = {'available': True, 'values': raw.strip()}
        except (OSError, ValueError, UnicodeError) as failure:
            counters[name] = {'available': False, 'failureType': type(failure).__name__}
    if identity(group) != expected:
        raise RuntimeError('Diagnostic cgroup changed during read')
    return counters


def retain_resource_snapshot(root, group, expected, context):
    # Diagnostic faults never replace the phase failure or impede mandatory cleanup.
    try:
        value = {'schemaVersion': 1, 'context': context, 'monotonic': time.monotonic(),
                 'counters': resource_snapshot(group, expected)}
    except BaseException as failure:
        value = {'schemaVersion': 1, 'context': context, 'available': False,
                 'failureType': type(failure).__name__}
    try:
        persist(root / ('resource-' + context + '.json'), value)
    except BaseException:
        pass


def main(projection=None, current_profile=None):
    def cancel(signum, frame):
        raise KeyboardInterrupt('Owned phase cancellation')
    previous = {}
    try:
        for signum in (signal.SIGINT, signal.SIGTERM):
            previous[signum] = signal.signal(signum, cancel)
        if projection is None:
            run_owned_phase(current_profile=current_profile)
        else:
            run_owned_phase(projection,current_profile)
    finally:
        for signum, handler in previous.items():
            signal.signal(signum, handler)

if __name__ == '__main__':
    main()
