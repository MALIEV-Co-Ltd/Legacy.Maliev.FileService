"""Pure Root phase authority validation; this module never starts an SDK or Docker."""
from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
import re

OWNER = '01a1009d-1c8e-7821-a1f2-fded3ac6928d'
ISSUER = '019fc21e-50f0-7112-834f-9fb3b35b9dfe'
PHASES = ('build', 'focused', 'full', 'format', 'audit')
BINDING_KEYS = ('candidateManifestSha256', 'supervisorManifestSha256', 'dependencyManifestSha256')
FIELDS = frozenset(('owner', 'issuedBy', 'phase', 'leaseId', 'issuedUtc', 'expiresUtc', *BINDING_KEYS))
MAX_BYTES = 4096


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('Duplicate authority field')
        result[key] = value
    return result


def timestamp(value):
    if not isinstance(value, str):
        raise ValueError('Original timestamp must be text')
    result = datetime.fromisoformat(value.replace('Z', '+00:00'))
    if result.tzinfo is None:
        raise ValueError('Authority requires aware UTC timestamps')
    return result.astimezone(timezone.utc)


@dataclass(frozen=True)
class PhaseAuthority:
    phase: str
    lease_id: str
    raw_sha256: str
    issued_utc: datetime
    expires_utc: datetime

    def remaining_seconds(self, now):
        if now.tzinfo is None or not self.issued_utc <= now < self.expires_utc:
            raise ValueError('Original Root authority is not live')
        return min(600.0, (self.expires_utc - now).total_seconds())


def validate_grant(raw, expected_raw_sha256, phase, sealed_bindings, now):
    """Caller supplies independently sealed bindings and original Root byte hash.

    Validation cannot create, extend, consume or renew a Root grant. The outer
    reviewed transport must claim the lease exactly once before allocating.
    """
    if not isinstance(raw, bytes) or not 0 < len(raw) <= MAX_BYTES:
        raise ValueError('Bounded original Root bytes required')
    if not isinstance(expected_raw_sha256, str) or not re.fullmatch('[0-9a-f]{64}', expected_raw_sha256):
        raise ValueError('Exact original Root hash required')
    if hashlib.sha256(raw).hexdigest() != expected_raw_sha256:
        raise ValueError('Original Root bytes differ')
    if phase not in PHASES:
        raise ValueError('Closed qualification phase required')
    if set(sealed_bindings) != set(BINDING_KEYS) or any(
        not isinstance(value, str) or not re.fullmatch('[0-9a-f]{64}', value)
        for value in sealed_bindings.values()
    ):
        raise ValueError('Exact sealed source bindings required')
    value = json.loads(raw.decode('utf-8'), object_pairs_hook=unique_object)
    if not isinstance(value, dict) or set(value) != FIELDS:
        raise ValueError('Exactly nine Root fields required')
    if value['owner'] != OWNER or value['issuedBy'] != ISSUER or value['phase'] != phase:
        raise ValueError('Original Root owner/issuer/phase differs')
    if any(value[key] != sealed_bindings[key] for key in BINDING_KEYS):
        raise ValueError('Reviewed source bindings differ')
    lease = value['leaseId']
    if not isinstance(lease, str) or not 1 <= len(lease) <= 128 or not lease.strip() or any(ord(c) < 32 for c in lease):
        raise ValueError('Exact bounded lease identity required')
    issued, expiry = timestamp(value['issuedUtc']), timestamp(value['expiresUtc'])
    if not 0 < (expiry - issued).total_seconds() <= 900:
        raise ValueError('Root lifetime must remain original and at most 900 seconds')
    result = PhaseAuthority(phase, lease, expected_raw_sha256, issued, expiry)
    result.remaining_seconds(now)
    return result
