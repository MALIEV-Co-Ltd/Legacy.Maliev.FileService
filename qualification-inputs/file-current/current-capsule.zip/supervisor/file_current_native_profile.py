"""File-specific current RED/GREEN profile for the existing finite owner.
No grants, SDK installation, Docker mutation or generic dispatch registry.
"""
import hashlib
import json
import os
from pathlib import Path
import re
import select
import signal
import time
import xml.etree.ElementTree as ET
from collections import Counter
from materialize_file_native import load_current_policy, verify_current_materialization
from sealed_source_capsule import digest, reject_links

APP='Legacy.Maliev.FileService.Tests.Application.FileApplicationServiceTests.'
HTTP='Legacy.Maliev.FileService.Tests.Integration.LegacyFileConsumerWriteHttpBoundaryTests.'
MOVE='Legacy.Maliev.FileService.Tests.Integration.LegacyFileMoveHttpBoundaryTests.'
FOCUSED={
    APP+'CurrentLiteralDelete_PreservesNormalizedSiblingAndDeletesOnlyRequestedObject':2,
    APP+'CurrentLiteralDelete_RejectsRawControlCharactersBeforeAnyDelete':2,
    APP+'CurrentLiteralDelete_PreservesReservedNamespaceAdmissionBeforeAnyDelete':2,
    HTTP+'CurrentLiteralDelete_ActualConsumerAndRuntimeRemoveOnlyRequestedCoordinate':2,
    MOVE+'CurrentLiteralMove_PreservesBothNormalizedSiblingsAndExactGenerationBoundCoordinates':4,
    MOVE+'CurrentLiteralMove_SafetyAdmissionPreservesSourceBeforeAnySdkEffect':4,
}
PHASES=('build','focused','full','format','audit')
COUNTERS={'total','executed','passed','failed','error','timeout','aborted','inconclusive','passedButRunAborted',
          'notRunnable','notExecuted','disconnected','warning','completed','inProgress','pending'}
SETTINGS_SHA='10ebbdc6b5bc235bbe35cc746f22c5da8a04486ba9977ec5f60aef245810b64d'
TEST_DLL='Legacy.Maliev.FileService.Tests/bin/Release/net10.0/Legacy.Maliev.FileService.Tests.dll'

def discovery_names(raw):
    if not isinstance(raw,bytes) or len(raw)>32*1024*1024:
        raise ValueError('Bounded actual compiled discovery required')
    text=raw.decode('utf-8')
    marker='The following Tests are available:'
    if text.count(marker)!=1:
        raise ValueError('One actual unfiltered VSTest discovery listing required')
    rows=[line.strip() for line in text.split(marker,1)[1].splitlines() if line.strip()]
    if len(rows)!=1571:
        raise ValueError('Exactly 1571 compiled case rows required')
    return Counter(rows)

def parse_trx(raw,total,passed,failed):
    if len(raw)>32*1024*1024 or b'<!' in raw:raise ValueError('Bounded ordinary raw TRX required')
    tree=ET.fromstring(raw);ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
    if tree.tag!='{'+ns['t']+'}TestRun':raise ValueError('Actual TestRun required')
    for name,direct in [('Results','t:Results'),('TestDefinitions','t:TestDefinitions'),
                        ('TestEntries','t:TestEntries'),('ResultSummary','t:ResultSummary'),
                        ('Counters','t:ResultSummary/t:Counters')]:
        if len(tree.findall('.//t:'+name,ns))!=1 or len(tree.findall(direct,ns))!=1:
            raise ValueError('Unique directly placed TRX containers required')
    summary=tree.find('t:ResultSummary',ns)
    if summary.get('outcome')!=('Failed' if failed else 'Completed'):
        raise ValueError('Actual color-specific terminal summary required')
    counters=tree.find('t:ResultSummary/t:Counters',ns).attrib
    if set(counters)!=COUNTERS or any(not re.fullmatch('0|[1-9][0-9]*',x) for x in counters.values()):
        raise ValueError('All sixteen explicit counters required')
    counts={key:int(value) for key,value in counters.items()}
    if (counts['total'],counts['executed'],counts['passed'],counts['failed'])!=(total,total,passed,failed) or any(
            value!=0 for key,value in counts.items() if key not in ('total','executed','passed','failed')):
        raise ValueError('Exact no-skip RED/GREEN counters required')
    definitions=tree.findall('t:TestDefinitions/t:UnitTest',ns);entries=tree.findall('t:TestEntries/t:TestEntry',ns)
    results=tree.findall('t:Results/t:UnitTestResult',ns)
    if (len(definitions),len(entries),len(results))!=(total,total,total):
        raise ValueError('Complete definition/entry/result roster required')
    defs={d.get('id'):d for d in definitions};joined={e.get('testId'):e for e in entries}
    if len(defs)!=total or len(joined)!=total:raise ValueError('Duplicate identity')
    cases=[];seen=set();executions=set()
    for result in results:
        test_id=result.get('testId');execution=result.get('executionId')
        definition=defs.get(test_id);entry=joined.get(test_id)
        if not test_id or not execution or test_id in seen or execution in executions or definition is None or entry is None:
            raise ValueError('Unique joined raw identity required')
        if entry.get('executionId')!=execution or definition.find('t:Execution',ns).get('id')!=execution:
            raise ValueError('Raw execution joins differ')
        method=definition.find('t:TestMethod',ns)
        cls=method.get('className','').split(',',1)[0]
        name=method.get('name','').split('(',1)[0].removeprefix(cls+'.')
        storage=definition.get('storage','').replace('\\','/').split('/')[-1].casefold()
        if storage!='legacy.maliev.fileservice.tests.dll' or result.get('outcome') not in ('Passed','Failed'):
            raise ValueError('Actual bound assembly/non-skip outcome required')
        cases.append({'method':cls+'.'+name,'name':result.get('testName'),'outcome':result.get('outcome'),
                      'identity':(storage,method.get('className'),method.get('name'),result.get('testName'))})
        seen.add(test_id);executions.add(execution)
    if sum(row['outcome']=='Passed' for row in cases)!=passed:
        raise ValueError('Joined semantic roster/outcomes differ')
    return cases

def focused_gate(cases,color):
    observed={}
    for row in cases:
        method=row['method']
        if method not in FOCUSED:raise ValueError('Unknown focused case')
        observed[method]=observed.get(method,0)+1
        expected='Passed'
        if color=='RED':
            expected='Passed' if method==APP+'CurrentLiteralDelete_PreservesReservedNamespaceAdmissionBeforeAnyDelete' else 'Failed'
            if method==MOVE+'CurrentLiteralMove_SafetyAdmissionPreservesSourceBeforeAnySdkEffect':
                if 'kind: "reserved"' in row['name']:expected='Passed'
                elif 'kind: "control"' in row['name']:expected='Failed'
                else:raise ValueError('Exact discovered move guard kind required')
        if row['outcome']!=expected:raise ValueError('Actual per-case RED/GREEN result differs')
    if observed!=FOCUSED:raise ValueError('Exactly six methods/sixteen discovered cases required')

class CurrentFileProfile:
    def __init__(self,red,green,raw_policy,red_receipt_sha,green_receipt_sha,supervisor):
        self.policy=load_current_policy(raw_policy);self.raw_policy=raw_policy
        self.roots={'RED':Path(red),'GREEN':Path(green)}
        self.receipts={'RED':red_receipt_sha,'GREEN':green_receipt_sha}
        self.supervisor=Path(supervisor)
        for color,root in self.roots.items():
            receipt=verify_current_materialization(root,raw_policy,self.receipts[color])
            if receipt['phase']!=color:raise ValueError('RED/GREEN reconstruction color differs')
        settings=self.supervisor/'owned-file-tests.runsettings'
        reject_links(settings)
        if digest(settings.read_bytes())!=SETTINGS_SHA:raise ValueError('Exact serialized fixture settings required')
        xml=ET.fromstring(settings.read_bytes())
        if xml.findtext('RunConfiguration/MaxCpuCount')!='1' or xml.findtext('xUnit/MaxParallelThreads')!='1' or xml.findtext('xUnit/ParallelizeTestCollections')!='false':
            raise ValueError('Fixture serialization cannot be weakened')
        self.source_binding=digest(raw_policy)

    def check_admission(self,admitted,repository,phase):
        if self.policy['executionEnabled'] is not True:
            raise ValueError('Current route remains source-only; no execution allocation')
        if self.policy['rootAllocation'] is None or self.policy['qualifiedSharedSecurityProducer'] is None:
            raise ValueError('Original allocation and qualified producer required')
        if phase not in PHASES or admitted.origin!='root-candidate' or admitted.root_authority is None or admitted.source_binding!=self.source_binding:
            raise ValueError('Original current-source Root phase authority required')
        if Path(repository)!=self.roots['GREEN']/'candidate':
            raise ValueError('Exact GREEN candidate owner route required')

    def roles(self,phase):
        return {'build':('build-RED','build-GREEN'),
                'focused':('discovery-GREEN','focused-RED','focused-GREEN'),
                'full':('full-GREEN',),'format':('format-GREEN',),'audit':('audit-GREEN',)}[phase]

    def expected_total(self,phase):
        return 16 if phase=='focused' else 1571

    def _previous(self,owner,phase):
        candidate=self.roots['GREEN']/'candidate'
        paths=list((candidate/'runner-results').glob('owned-'+phase+'-*'))
        matching=[]
        for path in paths:
            context=owner.unique_json(owner.bounded_bytes(path/'phase-context.json',4096))
            if context.get('sourceBinding')==self.source_binding and context.get('pipeline')==os.environ['GITHUB_RUN_ID']+':'+os.environ['GITHUB_RUN_ATTEMPT']:
                matching.append(path)
        if len(matching)!=1:raise ValueError('Exactly one same-source current predecessor required')
        return matching[0]

    def _release(self,owner,color):
        build=self._previous(owner,'build')
        graph=owner.unique_json(owner.bounded_bytes(build/'results/current'/('build-'+color)/'results/release-graph.json',16384))
        rows=[row for row in graph['assemblies'] if row['assembly']=='Legacy.Maliev.FileService.Tests']
        if graph.get('configuration')!='Release' or len(graph['assemblies'])!=7 or len(rows)!=1:
            raise ValueError('Seven actual Release outputs per color required')
        row=rows[0];path=self.roots[color]/'candidate'/TEST_DLL
        if row['path']!=str(path):raise ValueError('Current color Release assembly path differs')
        raw=owner.bounded_bytes(path,owner.LIMIT)
        if len(raw)!=row['bytes'] or digest(raw)!=row['sha256'] or raw[:2]!=b'MZ':
            raise ValueError('Current color Release assembly bytes differ')
        return {'path':str(path),'identity':list(owner.identity(path)),'bytes':len(raw),'sha256':digest(raw),'buildRoot':str(build)}

    def _command(self,owner,role,step,env,projection):
        operation,color=role.split('-');candidate=self.roots[color]/'candidate'
        common=['-c','Release','--disable-build-servers','--tl:off','-m:1','/p:UseSharedCompilation=false','/nr:false','/warnaserror','/p:ShouldUnsetParentConfigurationAndPlatform=false']
        if operation=='build':return ['build',str(candidate/'Legacy.Maliev.FileService.Tests/Legacy.Maliev.FileService.Tests.csproj'),*common],None,None,None
        if operation=='format':return ['format',str(candidate/'Legacy.Maliev.FileService.slnx'),'--verify-no-changes','--no-restore'],None,None,None
        if operation=='audit':return ['list',str(candidate/'Legacy.Maliev.FileService.slnx'),'package','--vulnerable','--include-transitive','--no-restore','--format','json','--output-version','1','--source','https://api.nuget.org/v3/index.json'],None,None,None
        provider=owner.bind_qualification_projected_provider(Path(projection['sdkRoot'])/'dotnet',projection)
        assembly=self._release(owner,color)
        settings=self.supervisor/'owned-file-tests.runsettings'
        results=step/'results'
        command=['exec',provider['files'][0]['path'],assembly['path'],'--Settings:'+str(settings),
                 '--TestAdapterPath:'+str(Path(assembly['path']).parent)]
        collector=None
        if operation=='discovery':command.append('--ListTests')
        else:
            command.extend(['--Logger:trx;LogFileName=file-'+operation+'.trx','--ResultsDirectory:'+str(results)])
            if operation=='focused':
                command.append('--TestCaseFilter:'+'|'.join('FullyQualifiedName='+name for name in FOCUSED))
            else:
                collector=owner.bind_vstest_collector(candidate,assembly)
                command[4]+=';'+collector['directory'];command.append('--Collect:XPlat Code Coverage')
        return command,provider,assembly,collector

    def execute_steps(self,owner,exec_fd,executable,phase,root,env,deadline,projection):
        if self.policy['executionEnabled'] is not True or self.policy['rootAllocation'] is None or self.policy['qualifiedSharedSecurityProducer'] is None:
            raise ValueError('Current SDK step dispatch disabled without original allocation/security')
        if projection is None:raise ValueError('Current route requires original qualified projection')
        total_output=0
        for role in self.roles(phase):
            owner.projection_check_deadline(deadline)
            step=root/'results/current'/role;step.mkdir(parents=True,exist_ok=False);(step/'results').mkdir()
            command,provider,assembly,collector=self._command(owner,role,step,env,projection)
            total_output=self._step(owner,exec_fd,executable,role,step,command,env,deadline,projection,
                                    provider,assembly,collector,total_output)
            self._step_gate(owner,role,step,env)
            # Every SDK child has exited before another starts. Do not advance
            # while fixture publication/absence custody is unresolved.
            status,containers=owner.docker('GET','/containers/json?all=true&filters='+owner.quote(
                json.dumps({'label':['maliev.codex.sdk-run='+env['MALIEV_FILE_SDK_RUN']]},separators=(',',':')),safe=''))
            if status!=200 or containers:raise ValueError('Exact current SDK backends not absent between steps')
        return 0

    def _step(self,owner,exec_fd,executable,role,step,command,env,deadline,projection,provider,assembly,collector,total_output):
        """One exact nested SDK child, in the same existing owned cgroup/budget."""
        if self.policy['executionEnabled'] is not True:
            raise ValueError('Current SDK leaf dispatch remains disabled')
        read_fd=write_fd=error_read=error_write=None
        pid=None;pidfd=None;reaped=False;handles={};primary=None
        wrapper=os.getpid()
        try:
            # Each allocation is registered before cancellation can escape.
            with owner.registration_window():
                read_fd,write_fd=os.pipe()
            with owner.registration_window():
                error_read,error_write=os.pipe()
            streams={read_fd:step/'sdk.log',error_read:step/'sdk.stderr.log'}
            with owner.registration_window() as mask:
                pid=os.fork()
                if pid==0:
                    try:
                        os.close(read_fd);os.close(error_read)
                        os.dup2(write_fd,1);os.dup2(error_write,2);os.close(write_fd);os.close(error_write)
                        owner.guard_child_parent(wrapper,mask)
                        os.kill(os.getpid(),signal.SIGSTOP)
                        owner.projection_check_deadline(deadline)
                        owner.bind_qualification_projected_provider(executable,projection)
                        if provider is not None:owner.recheck_vstest_inputs(provider,assembly)
                        if collector is not None:owner.recheck_vstest_collector(self.roots['GREEN']/'candidate',assembly,collector)
                        os.chdir(self.roots[role.split('-')[1]]/'candidate')
                        os.execve(exec_fd,[str(executable),*command],env)
                    except BaseException:os._exit(127)
            with owner.registration_window():
                pidfd=os.pidfd_open(pid)
            with owner.registration_window():
                os.close(write_fd);write_fd=None
            with owner.registration_window():
                os.close(error_write);error_write=None
            while True:
                waited,state=os.waitpid(pid,os.WUNTRACED|os.WNOHANG)
                if waited==pid:break
                owner.projection_check_deadline(deadline);time.sleep(.01)
            if not os.WIFSTOPPED(state):
                reaped=os.WIFEXITED(state) or os.WIFSIGNALED(state);raise ValueError('Stopped exact SDK step reservation required')
            birth=owner.process_birth(pid)
            if Path('/proc/'+str(pid)+'/cgroup').read_text()!=Path('/proc/self/cgroup').read_text():
                raise ValueError('SDK step must inherit same admitted cgroup')
            owner.write_new(step/'child.json',{'pid':pid,'startTicks':birth,'executable':str(executable),
                'role':role,'sourceBinding':self.source_binding,'deadline':deadline,'cgroupInherited':True})
            for descriptor,path in streams.items():
                with owner.registration_window():
                    handles[descriptor]=path.open('xb')
                os.set_blocking(descriptor,False)
            signal.pidfd_send_signal(pidfd,signal.SIGCONT)
            pending=set(streams)
            while pending:
                owner.projection_check_deadline(deadline)
                ready,_,_=select.select(list(pending),[],[],.1)
                for descriptor in ready:
                    block=os.read(descriptor,min(65536,owner.LIMIT-total_output+1))
                    if not block:pending.remove(descriptor);continue
                    total_output+=len(block)
                    if total_output>owner.LIMIT:raise ValueError('Original aggregate SDK output quota exceeded')
                    handles[descriptor].write(block)
                    os.write(2 if descriptor==error_read else 1,block)
            while True:
                waited,state=os.waitpid(pid,os.WNOHANG)
                if waited==pid:reaped=True;break
                owner.projection_check_deadline(deadline);time.sleep(.01)
            code=os.WEXITSTATUS(state) if os.WIFEXITED(state) else None
            if code not in ((1,) if role=='focused-RED' else (0,)):
                raise ValueError('Actual color-specific SDK exit differs')
            owner.write_new(step/'resource.json',{'pid':pid,'startTicks':birth,'exited':True,'exitCode':code,
                'role':role,'sourceBinding':self.source_binding})
            return total_output
        except BaseException as error:
            primary=error
            raise
        finally:
            self._cleanup_step(owner,step,wrapper,pid,pidfd,reaped,
                (read_fd,error_read,write_fd,error_write),handles,primary)

    def _cleanup_step(self,owner,step,wrapper,pid,pidfd,reaped,descriptors,handles,primary):
        """Finite direct-child cleanup; unresolved custody stays with outer owner."""
        failures=[];categories=set();lost_child=False
        def record(category,error):
            if category not in categories:
                categories.add(category);failures.append((category,error))
        def poll():
            nonlocal reaped,lost_child
            try:
                with owner.registration_window():
                    waited,state=os.waitpid(pid,os.WNOHANG)
                    if waited==pid and (os.WIFEXITED(state) or os.WIFSIGNALED(state)):
                        reaped=True
                return waited==0
            except ChildProcessError as error:
                # ECHILD is not proof of this child's exit. Never signal that PID.
                lost_child=True;record('wait-ownership',error)
            except BaseException as error:record('wait',error)
            return False
        def send(request):
            if reaped:return
            try:
                with owner.registration_window():
                    if pidfd is not None:
                        signal.pidfd_send_signal(pidfd,request)
                    elif not lost_child and os.getpid()==wrapper and poll() and not reaped:
                        # This exact fork result remains our unreaped direct child.
                        # No process census or borrowed PID/parent identity.
                        os.kill(pid,request)
            except BaseException as error:
                record('term' if request==signal.SIGTERM else 'kill',error)
        if pid is not None and not reaped:
            started=time.monotonic();grace=started+5;until=started+10;killed=False
            send(signal.SIGTERM)
            # Independent force/reap attempts continue after TERM or wait faults.
            for _ in range(1002):
                poll()
                if reaped:break
                now=time.monotonic()
                if not killed and now>=grace:
                    killed=True;send(signal.SIGKILL)
                if now>=until:break
                try:time.sleep(min(.01,max(0,until-now)))
                except BaseException as error:record('sleep',error)
            if not reaped and not killed:
                # Repeated interrupted sleeps cannot suppress the force attempt.
                send(signal.SIGKILL);poll()
            if not reaped:
                record('exit-unproved',TimeoutError('Exact direct SDK child exit unproved'))
                self._quarantine_step(owner,step,primary,failures,'exit-unproved')
                raise RuntimeError('Unresolved custody must not return')
        # A live writer can never reach descriptor or log-stream disposal.
        # One failure cannot skip another independently owned disposal attempt.
        for index,descriptor in enumerate((*descriptors,pidfd)):
            if descriptor is not None:
                try:
                    with owner.registration_window():os.close(descriptor)
                except BaseException as error:record('descriptor-'+str(index),error)
        for index,stream in enumerate(handles.values()):
            try:
                with owner.registration_window():stream.close()
            except BaseException as error:record('stream-'+str(index),error)
        if any(category.startswith(('descriptor-','stream-')) for category in categories):
            self._quarantine_step(owner,step,primary,failures,'handles-unproved')
            raise RuntimeError('Unresolved handles must not return')
        if failures:
            self._note_cleanup_failure(owner,step,primary,failures,'settled')
            if primary is None:raise failures[0][1]

    def _note_cleanup_failure(self,owner,step,primary,failures,state):
        # Only fixed categories cross the evidence/diagnostic boundary.
        codes=[category for category,_ in failures]
        if primary is not None:
            try:primary.add_note('File SDK leaf cleanup: '+','.join(codes))
            except BaseException:pass
        try:
            owner.persist(step/'cleanup-failure.json',{'state':state,'released':False,
                'primaryFailurePresent':primary is not None,'categories':codes})
        except BaseException:pass

    def _quarantine_step(self,owner,step,primary,failures,reason):
        self._note_cleanup_failure(owner,step,primary,failures,reason)
        # Preserve live pipes/logs and the same original owner allocation.
        # The original finite outer phase supervisor stops this same wrapper
        # and its admitted cgroup; no lease, release receipt or new grant here.
        while True:
            try:os.kill(os.getpid(),signal.SIGSTOP)
            except BaseException:
                # Diagnostic/cancellation failure cannot abandon custody.
                try:time.sleep(.05)
                except BaseException:pass

    def _step_gate(self,owner,role,step,env):
        operation,color=role.split('-')
        if operation=='build':
            text=(owner.bounded_bytes(step/'sdk.log',owner.LIMIT)+owner.bounded_bytes(step/'sdk.stderr.log',owner.LIMIT)).decode('utf-8')
            if len(re.findall(r'^\s*0 Warning\(s\)\s*$',text,re.M))!=1 or len(re.findall(r'^\s*0 Error\(s\)\s*$',text,re.M))!=1:
                raise ValueError('Each color must build first with zero warnings/errors')
            owner.verify_release_graph(self.roots[color]/'candidate',env['MalievWorkspaceRoot'],step/'results')
        elif operation=='discovery':
            discovery_names(owner.bounded_bytes(step/'sdk.log',owner.LIMIT))
        elif operation in ('focused','full'):
            paths=list((step/'results').rglob('*.trx'))
            if len(paths)!=1:raise ValueError('One raw per-color TRX required')
            raw=owner.bounded_bytes(paths[0],owner.LIMIT)
            cases=parse_trx(raw,1571 if operation=='full' else 16,4 if color=='RED' else (1571 if operation=='full' else 16),12 if color=='RED' else 0)
            if operation=='focused':focused_gate(cases,color)
            else:
                focused=self._previous(owner,'focused')
                discovered=discovery_names(owner.bounded_bytes(focused/'results/current/discovery-GREEN/sdk.log',owner.LIMIT))
                if Counter(row['name'] for row in cases)!=discovered:raise ValueError('Full raw TRX must match actual compiled discovery multiplicities')
                import zipfile
                with zipfile.ZipFile(self.roots['GREEN']/'baseline-artifact.zip') as archive:
                    baseline=parse_trx(archive.read(self.policy['baseline']['trxPath']),1555,1555,0)
                baseline_ids=Counter(row['identity'] for row in baseline);actual_ids=Counter(row['identity'] for row in cases)
                additions=actual_ids-baseline_ids
                if baseline_ids-actual_ids or sum(additions.values())!=16:
                    raise ValueError('All baseline1555 identities plus exactly16 required')
                new_cases=[]
                for row in cases:
                    if additions[row['identity']]:
                        new_cases.append(row);additions[row['identity']]-=1
                focused_gate(new_cases,'GREEN')
                spec=__import__('importlib.util',fromlist=['util'])
                module_spec=spec.spec_from_file_location('current_file_coverage',self.supervisor/'verify-runner-coverage.py')
                module=spec.module_from_spec(module_spec);module_spec.loader.exec_module(module);module.verify(step/'results')
            owner.persist(step/'results/native-test-gate.json',{'phase':operation,'color':color,'actualPassed':sum(x['outcome']=='Passed' for x in cases),'failed':sum(x['outcome']=='Failed' for x in cases),'skipped':0,'trxSha256':digest(raw)})
        elif operation=='audit':
            owner.verify_audit(owner.bounded_bytes(step/'sdk.log',owner.LIMIT),owner.bounded_bytes(step/'sdk.stderr.log',owner.LIMIT),owner.restored_audit_identity(self.roots['GREEN']/'candidate'))

    def verify_phase(self,owner,phase,root):
        expected=self.roles(phase)
        actual=tuple(path.name for path in (root/'results/current').iterdir() if path.is_dir())
        if set(actual)!=set(expected) or len(actual)!=len(expected):raise ValueError('Closed current phase step roster required')
        for role in expected:
            resource=owner.unique_json(owner.bounded_bytes(root/'results/current'/role/'resource.json',4096))
            if resource.get('exited') is not True or resource.get('sourceBinding')!=self.source_binding:
                raise ValueError('Exact current SDK step release required')
        if phase=='build':
            raw=owner.bounded_bytes(root/'results/current/build-GREEN/results/release-graph.json',16384)
            owner.write_new(root/'results/release-graph.json',owner.unique_json(raw))
        if phase in ('focused','full'):
            owner.write_new(root/'results/native-test-gate.json',{'phase':phase,'actualPassed':self.expected_total(phase),
                'failed':0,'skipped':0,'sourceBinding':self.source_binding,'currentRoles':list(expected)})
        owner.write_new(root/'results/current-phase-gate.json',{'phase':phase,'roles':list(expected),
            'sourceBinding':self.source_binding,'budgetRenewed':False,'allStepsExited':True})
