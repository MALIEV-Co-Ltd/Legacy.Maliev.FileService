"""Closed admission sources for the single File Linux resource owner."""
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess

from file_root_phase_grant import BINDING_KEYS, PHASES, PhaseAuthority, unique_object, validate_grant

REPOSITORY = 'MALIEV-Co-Ltd/Legacy.Maliev.FileService'
WORKFLOWS = {'pr-validation.yml': 'pull_request', 'ci-main.yml': 'push',
             'ci-develop.yml': 'push', 'ci-staging.yml': 'push'}


@dataclass(frozen=True)
class Admission:
    origin: str
    phase: str
    source_binding: str
    claim_id: str
    expires_utc: datetime
    root_authority: PhaseAuthority | None = None

    def remaining_seconds(self, now):
        if self.root_authority is not None:
            return self.root_authority.remaining_seconds(now)
        if now.tzinfo is None or now >= self.expires_utc:
            raise ValueError('Fixed protected CI phase expired')
        return min(600.0, (self.expires_utc - now).total_seconds())


def bounded_original(path, expected_sha):
    path = Path(path)
    if path.is_symlink() or not path.is_file():
        raise ValueError('Ordinary immutable authority file required')
    with path.open('rb') as stream:
        raw = stream.read(4097)
    if len(raw) > 4096 or not re.fullmatch('[0-9a-f]{64}', expected_sha or '') or hashlib.sha256(raw).hexdigest() != expected_sha:
        raise ValueError('Authority bytes/hash differ or exceed quota')
    return raw


def candidate_admission(env, phase, now):
    if env.get('GITHUB_ACTIONS') != 'true' or env.get('GITHUB_REPOSITORY') != REPOSITORY or env.get('GITHUB_EVENT_NAME') != 'workflow_dispatch':
        raise ValueError('Candidate-only protected hosted dispatch required')
    if env.get('GITHUB_WORKFLOW_REF') != REPOSITORY + '/.github/workflows/file-native-qualification.yml@refs/heads/main':
        raise ValueError('Exact protected candidate workflow/main ref required')
    if not re.fullmatch('[0-9a-f]{40}', env.get('GITHUB_SHA', '')) or env.get('GITHUB_WORKFLOW_SHA') != env['GITHUB_SHA']:
        raise ValueError('Current protected candidate workflow/head identity required')
    for key in ('GITHUB_RUN_ID', 'GITHUB_RUN_ATTEMPT'):
        if not re.fullmatch('[1-9][0-9]{0,19}', env.get(key, '')):
            raise ValueError('Original candidate dispatch run/attempt required')
    bindings = json.loads(bounded_original(env['MALIEV_FILE_BINDINGS_PATH'],
        env['MALIEV_FILE_BINDINGS_SHA256']).decode(), object_pairs_hook=unique_object)
    if set(bindings) != set(BINDING_KEYS):
        raise ValueError('Closed independently reviewed source bindings required')
    authority = validate_grant(bounded_original(env['MALIEV_FILE_ROOT_GRANT_PATH'],
        env['MALIEV_FILE_ROOT_GRANT_SHA256']), env['MALIEV_FILE_ROOT_GRANT_SHA256'], phase, bindings, now)
    return Admission('root-candidate', phase, bindings['candidateManifestSha256'],
                     'root:' + authority.lease_id, authority.expires_utc, authority)


def validate_ci_identity(env, phase, checkout, head, dirty, workflow_head, now):
    if phase not in PHASES or env.get('GITHUB_ACTIONS') != 'true' or env.get('GITHUB_REPOSITORY') != REPOSITORY:
        raise ValueError('Explicit protected GitHub CI identity required')
    if dirty or not re.fullmatch('[0-9a-f]{40}', head) or head != env.get('GITHUB_SHA'):
        raise ValueError('Uncommitted candidate or wrong checkout cannot enter protected CI')
    if Path(env.get('GITHUB_WORKSPACE', '')).resolve() != Path(checkout).resolve():
        raise ValueError('CI worktree differs from actual GitHub workspace')
    reference = env.get('GITHUB_WORKFLOW_REF', '')
    prefix = REPOSITORY + '/.github/workflows/'
    if not reference.startswith(prefix) or '@' not in reference:
        raise ValueError('Protected calling workflow identity unavailable')
    name, ref = reference[len(prefix):].split('@', 1)
    if name not in WORKFLOWS or env.get('GITHUB_EVENT_NAME') != WORKFLOWS[name]:
        raise ValueError('Dispatch/materialization event cannot enter normal protected CI')
    expected_ref = {'ci-main.yml': 'refs/heads/main', 'ci-develop.yml': 'refs/heads/develop', 'ci-staging.yml': 'refs/heads/staging'}
    if name in expected_ref and ref != expected_ref[name]:
        raise ValueError('Protected branch/ref differs')
    if name == 'pr-validation.yml' and not re.fullmatch('refs/pull/[1-9][0-9]*/merge', ref):
        raise ValueError('Protected PR merge ref differs')
    if workflow_head != env.get('GITHUB_WORKFLOW_SHA') or not re.fullmatch('[0-9a-f]{40}', workflow_head or ''):
        raise ValueError('Immutable calling workflow commit differs')
    for key in ('GITHUB_RUN_ID', 'GITHUB_RUN_ATTEMPT'):
        if not re.fullmatch('[1-9][0-9]{0,19}', env.get(key, '')):
            raise ValueError('Original run/attempt identity unavailable')
    if any(env.get(key) for key in ('MALIEV_FILE_ROOT_GRANT_PATH', 'MALIEV_FILE_ROOT_GRANT_SHA256',
                                  'MALIEV_FILE_BINDINGS_PATH', 'MALIEV_FILE_BINDINGS_SHA256')):
        raise ValueError('Candidate authority cannot select protected CI profile')
    if now.tzinfo is None:
        raise ValueError('Aware admission time required')
    claim = 'ci:' + env['GITHUB_RUN_ID'] + ':' + env['GITHUB_RUN_ATTEMPT'] + ':' + phase
    return Admission('protected-ci', phase, head, claim, now + timedelta(seconds=600))


def git_bytes(repository, arguments):
    # Only fixed read-only Git identity commands, finite exact-child cleanup by run().
    options = {}
    if os.geteuid() == 0:
        import pwd
        uid = int(os.environ['MALIEV_FILE_EVIDENCE_UID']); gid = int(os.environ['MALIEV_FILE_EVIDENCE_GID'])
        account = pwd.getpwuid(uid)
        if uid <= 0 or account.pw_gid != gid: raise ValueError('Original Git evidence owner differs')
        options = dict(user=uid, group=gid, extra_groups=os.getgrouplist(account.pw_name, gid))
    result = subprocess.run(['git', '-C', str(repository), *arguments], capture_output=True, timeout=5, **options)
    if result.returncode or len(result.stdout) > 1048576:
        raise ValueError('Actual bounded Git identity unavailable')
    return result.stdout


def admission(env, phase, repository, now):
    mode = env.get('MALIEV_FILE_ADMISSION_MODE')
    if mode == 'root-candidate':
        return candidate_admission(env, phase, now)
    if mode != 'protected-ci':
        raise ValueError('No default or self-issued phase authority')
    head = git_bytes(repository, ['rev-parse', 'HEAD']).decode('ascii').strip()
    dirty = git_bytes(repository, ['status', '--porcelain=v1', '--untracked-files=all'])
    workflow = env.get('GITHUB_WORKFLOW_SHA', '')
    if not re.fullmatch('[0-9a-f]{40}', workflow):
        raise ValueError('Original immutable workflow SHA required')
    result = validate_ci_identity(env, phase, repository, head, bool(dirty), workflow, now)
    # Calling workflow and reusable validator must match their actual Git objects.
    reference = env.get('GITHUB_WORKFLOW_REF', '').split('@', 1)[0]
    paths = [reference.removeprefix(REPOSITORY + '/'), '.github/workflows/_build-and-test.yml',
             '.github/actions/file-dotnet-validate/action.yml']
    for relative in paths:
        if relative.startswith('/') or '..' in Path(relative).parts or not relative.startswith('.github/'):
            raise ValueError('Foreign workflow source coordinate')
        actual = Path(repository) / relative
        if actual.is_symlink() or actual.read_bytes() != git_bytes(repository, ['show', workflow + ':' + relative]):
            raise ValueError('Calling/reusable workflow source differs from immutable commit')
    return result


def consume_once(value, directory):
    """Retain immutable consumed evidence; never delete it to renew a lease."""
    directory = Path(directory)
    directory.mkdir(mode=0o700, exist_ok=True)
    metadata = directory.lstat()
    if not stat.S_ISDIR(metadata.st_mode) or stat.S_IMODE(metadata.st_mode) != 0o700 or metadata.st_uid != os.geteuid():
        raise ValueError('Phase claim directory is foreign or not private')
    name = hashlib.sha256(value.claim_id.encode()).hexdigest() + '.json'
    raw = json.dumps({'origin': value.origin, 'phase': value.phase, 'sourceBinding': value.source_binding,
        'claimId': value.claim_id, 'expiresUtc': value.expires_utc.isoformat()}, sort_keys=True).encode()
    with (directory / name).open('xb') as stream:
        stream.write(raw); stream.flush(); os.fsync(stream.fileno())
    return directory / name
