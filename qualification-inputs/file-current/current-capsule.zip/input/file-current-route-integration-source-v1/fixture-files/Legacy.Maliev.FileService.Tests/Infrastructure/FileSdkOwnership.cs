using System.Globalization;
using System.Text.Json;

namespace Legacy.Maliev.FileService.Tests.Infrastructure;

// Local supervision evidence, not a credential or cryptographic authorization token.
internal static class FileSdkOwnership
{
    private static readonly object IntentLock = new();
    internal static string RunId => Check().Run;

    internal static (string Run, string Root) Check()
    {
        if (!OperatingSystem.IsLinux()) throw new PlatformNotSupportedException("Reviewed File SDK supervisor requires Linux cgroup v2.");
        string run = Environment.GetEnvironmentVariable("MALIEV_FILE_SDK_RUN") ?? "";
        string root = Environment.GetEnvironmentVariable("MALIEV_FILE_SDK_ROOT") ?? "";
        if (!Guid.TryParseExact(run, "N", out _) || !Path.IsPathFullyQualified(root))
            throw new InvalidOperationException("Missing exact supervised SDK run.");
        string expectedGroup = "/maliev-file-" + run;
        if (!File.ReadAllLines("/proc/self/cgroup").Contains("0::" + expectedGroup))
            throw new InvalidOperationException("Current test process is outside the owned SDK cgroup.");
        string group = "/sys/fs/cgroup" + expectedGroup;
        if (File.ReadAllText(Path.Combine(group, "memory.max")).Trim() != "2147483648"
            || File.ReadAllText(Path.Combine(group, "pids.max")).Trim() != "64"
            || File.ReadAllText(Path.Combine(group, "cpu.max")).Trim() != "100000 100000")
            throw new InvalidOperationException("Actual SDK resource caps differ from the reviewed lane.");
        var mode = File.GetUnixFileMode(root);
        if ((mode & (UnixFileMode.GroupRead | UnixFileMode.GroupWrite | UnixFileMode.GroupExecute
            | UnixFileMode.OtherRead | UnixFileMode.OtherWrite | UnixFileMode.OtherExecute)) != 0)
            throw new InvalidOperationException("SDK evidence root is not private.");
        using var document = JsonDocument.Parse(ReadBounded(Path.Combine(root, "admission.json")));
        var value = document.RootElement;
        if (value.GetProperty("origin").GetString() is not ("root-candidate" or "protected-ci")
            || value.GetProperty("phase").GetString() is not ("focused" or "full"))
            throw new InvalidOperationException("Only an admitted native test phase can acquire a backend.");
        if (value.GetProperty("run").GetString() != run || value.GetProperty("cgroup").GetString() != expectedGroup
            || DateTimeOffset.Parse(value.GetProperty("expiresUtc").GetString()!, CultureInfo.InvariantCulture) <= DateTimeOffset.UtcNow)
            throw new InvalidOperationException("SDK run evidence is foreign or expired.");
        return (run, root);
    }

    internal static (string Run, string Root, string SourceBinding, DateTimeOffset Expires) Admission()
    {
        var owner = Check();
        using var document = JsonDocument.Parse(ReadBounded(Path.Combine(owner.Root, "admission.json")));
        var value = document.RootElement;
        var source = value.GetProperty("sourceBinding").GetString();
        if (string.IsNullOrWhiteSpace(source)) throw new InvalidOperationException("Missing immutable admitted source identity.");
        return (owner.Run, owner.Root, source,
            DateTimeOffset.Parse(value.GetProperty("expiresUtc").GetString()!, CultureInfo.InvariantCulture));
    }

    internal static void RecordIntent(string scope, string childRun, string name, string image, string daemon)
    {
        var owner = Check();
        using var admission = JsonDocument.Parse(ReadBounded(Path.Combine(owner.Root, "admission.json")));
        if (admission.RootElement.GetProperty("daemon").GetString() != daemon)
            throw new InvalidOperationException("SDK and test container daemon identities differ.");
        string directory = Path.Combine(owner.Root, "intents");
        lock (IntentLock)
        {
        // An immutable intent reserves capacity before Create. This exact SDK-root
        // lock also serializes independent fixture processes, not just threads.
        var lockPath = Path.Combine(owner.Root, "backend-admission.lock");
        if (File.Exists(lockPath) && (File.GetAttributes(lockPath) & FileAttributes.ReparsePoint) != 0)
            throw new InvalidOperationException("Backend admission lock identity is unsafe.");
        using var reservation = new FileStream(lockPath, FileMode.OpenOrCreate,
            FileAccess.ReadWrite, FileShare.None, 1, FileOptions.WriteThrough);
        if (Directory.EnumerateFiles(directory, "*.json").Take(513).Count() >= 512)
            throw new InvalidOperationException("SDK container intent cap reached before acquisition.");
        if (Directory.EnumerateFiles(directory, "*.json").Count(path =>
            !File.Exists(Path.Combine(owner.Root, "absent-" + Path.GetFileName(path)))) >= 2)
            throw new InvalidOperationException("At most two exact ephemeral backends may be live.");
        // Fail closed before Create: exclusive immutable evidence, no connection string or credentials.
        var bytes = JsonSerializer.SerializeToUtf8Bytes(new
        {
            sdkRun = owner.Run, scope, childRun, name, image, daemon,
            owner = "file-native-qualification-20261008", createdUtc = DateTimeOffset.UtcNow,
        });
        if (bytes.Length > 4096) throw new InvalidOperationException("Container intent exceeds its bounded schema.");
        using var stream = new FileStream(Path.Combine(directory, childRun + ".json"), FileMode.CreateNew,
            FileAccess.Write, FileShare.Read, 4096, FileOptions.WriteThrough);
        stream.Write(bytes);
        stream.Flush(flushToDisk: true);
        }
    }

    internal static void RecordPublication(string childRun, string id, string daemon)
    {
        var owner = Check();
        Persist(owner.Root, "published-" + childRun + ".json", new { sdkRun = owner.Run, childRun, id, daemon });
    }

    internal static void RecordAbsence(string childRun)
    {
        var owner = Check();
        Persist(owner.Root, "absent-" + childRun + ".json", new { sdkRun = owner.Run, childRun, actualAbsence = true });
    }

    private static void Persist(string root, string name, object value)
    {
        var bytes = JsonSerializer.SerializeToUtf8Bytes(value);
        string path = Path.Combine(root, name);
        if (File.Exists(path))
        {
            if (!ReadBounded(path).AsSpan().SequenceEqual(bytes))
                throw new InvalidOperationException("Immutable SDK ownership receipt changed.");
            return;
        }
        using var stream = new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.Read,
            4096, FileOptions.WriteThrough);
        stream.Write(bytes);
        stream.Flush(flushToDisk: true);
    }

    private static byte[] ReadBounded(string path)
    {
        using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
        var bytes = new byte[4097];
        int length = 0;
        while (length < bytes.Length)
        {
            int read = stream.Read(bytes, length, bytes.Length - length);
            if (read == 0) break;
            length += read;
        }
        if (length > 4096) throw new InvalidOperationException("SDK ownership receipt exceeds its bound.");
        return bytes[..length];
    }
}
