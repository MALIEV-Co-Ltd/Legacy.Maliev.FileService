using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Net;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text.Json;
using Docker.DotNet;
using Docker.DotNet.Models;
using DotNet.Testcontainers.Builders;
using DotNet.Testcontainers.Configurations;
using DotNet.Testcontainers.Containers;
using StackExchange.Redis;

namespace Legacy.Maliev.FileService.Tests.Infrastructure;

// This fixture owns only its exact disposable Redis container, never a Docker-wide resource.
internal sealed class OwnedRedisLease : IAsyncDisposable
{
    private static readonly SemaphoreSlim AllocationSlot = new(1, 1);
    private static int allocationQuarantined;
    private readonly CancellationTokenSource lifetime = new(TimeSpan.FromMinutes(3));
    private readonly CancellationTokenSource finished = new();
    private readonly object cleanupSync = new();
    private readonly Guid run = Guid.NewGuid();
    private readonly DateTimeOffset allocatedAfter = DateTimeOffset.UtcNow;
    private readonly Dictionary<string, string> labels;
    private readonly string name;
    private readonly string ledgerPath;
    private readonly string candidateIdentity;
    private readonly string dockerEndpoint;
    private readonly IContainer container;
    private readonly IDockerClient docker;
    private readonly Task watchdog;
    private readonly TaskCompletionSource startupSettled = new(TaskCreationOptions.RunContinuationsAsynchronously);
    private readonly TaskCompletionSource consumerSettled = new(TaskCreationOptions.RunContinuationsAsynchronously);
    private bool consumerAdmitted;
    private bool settlementVerified;
    private Task? cleanup;
    private Task? disposal;
    private Snapshot? expected;
    private IConnectionMultiplexer? connection;
    private bool started;
    private bool quarantined;
    private string? knownContainerId;
    private string? daemon;
    private FileStageCheckpoint? checkpoints;

    private OwnedRedisLease(Admission admission)
    {
        IDockerClient? allocatedClient = null;
        try
        {
            candidateIdentity = admission.CandidateId;
            name = "file-redis-" + run.ToString("N");
            var sdkOwner = FileSdkOwnership.Check();
            labels = new Dictionary<string, string>
            {
                ["codex.owner"] = "file-replay-tests",
                ["codex.run"] = run.ToString("N"),
                ["codex.ownerPid"] = Environment.ProcessId.ToString(CultureInfo.InvariantCulture),
                ["codex.ownerStartUtc"] = ProcessStartUtc().ToString("O"),
                ["codex.expiresUtc"] = allocatedAfter.AddMinutes(3).ToString("O"),
                ["codex.persistentData"] = "false",
                ["maliev.codex.owner"] = "file-native-qualification-20261008",
                ["maliev.codex.sdk-run"] = sdkOwner.Run,
                ["maliev.codex.run"] = run.ToString("N"),
                ["maliev.codex.parent-run"] = run.ToString("N"),
                ["maliev.codex.expires-utc"] = allocatedAfter.AddMinutes(3).ToString("O"),
                ["maliev.codex.persistent-data"] = "false",
            };
            var directory = Environment.GetEnvironmentVariable("CODEX_FILE_RESOURCE_LEDGER_DIR")
                ?? Path.Combine(sdkOwner.Root, "redis-ledgers");
            Directory.CreateDirectory(directory);
            ledgerPath = Path.Combine(directory, run.ToString("N") + ".json");
            var endpoint = TestcontainersSettings.OS.DockerEndpointAuthConfig;
            if (!string.IsNullOrEmpty(endpoint.Endpoint.UserInfo)
                || (endpoint.Endpoint.Scheme is not ("npipe" or "unix") && !endpoint.Endpoint.IsLoopback))
                throw new InvalidOperationException("Owned Redis requires a local Docker endpoint.");
            dockerEndpoint = endpoint.Endpoint.ToString();
            docker = allocatedClient = endpoint.GetDockerClientConfiguration(run).CreateClient();
            container = new ContainerBuilder("redis:8-alpine")
                .WithDockerEndpoint(endpoint).WithName(name).WithLabel(labels)
                .WithCleanUp(false).WithAutoRemove(false)
                .WithCommand("redis-server", "--save", "", "--appendonly", "no", "--maxmemory", "64mb", "--maxmemory-policy", "noeviction")
                .WithPortBinding(6379, true)
                .WithCreateParameterModifier(parameters =>
                {
                    parameters.HostConfig.Memory = 128L * 1024 * 1024;
                    parameters.HostConfig.MemorySwap = parameters.HostConfig.Memory;
                    parameters.HostConfig.Tmpfs = new Dictionary<string, string> { ["/data"] = "rw,size=64m" };
                    parameters.HostConfig.NanoCPUs = 500_000_000;
                    foreach (var binding in parameters.HostConfig.PortBindings["6379/tcp"]) binding.HostIP = "127.0.0.1";
                })
                .WithWaitStrategy(Wait.ForUnixContainer().UntilInternalTcpPortIsAvailable(6379)).Build();
            WriteLedger("Reserved", admission.CandidateId);
            watchdog = WatchdogAsync();
        }
        catch
        {
            try { allocatedClient?.Dispose(); }
            finally
            {
                lifetime.Dispose();
                finished.Dispose();
            }
            throw;
        }
    }

    public CancellationToken Token => lifetime.Token;
    public IConnectionMultiplexer Connection => connection ?? throw new InvalidOperationException("Owned Redis is not connected.");

    public static async Task<OwnedRedisLease> StartAsync(FileStageCheckpoint? checkpoints = null)
    {
        using var wait = new CancellationTokenSource(TimeSpan.FromSeconds(30));
        await AllocationSlot.WaitAsync(wait.Token);
        OwnedRedisLease? lease = null;
        try
        {
            if (Volatile.Read(ref allocationQuarantined) != 0) throw new InvalidOperationException("Previous Redis ownership uncertainty blocks further allocation.");
            var admission = await AdmitAsync(); // Before constructing or allocating a container/client.
            lease = new OwnedRedisLease(admission);
            lease.checkpoints = checkpoints;
            try
            {
                lease.daemon = (await lease.docker.System.GetSystemInfoAsync(lease.Token)).ID;
                if (string.IsNullOrWhiteSpace(lease.daemon)) throw new InvalidOperationException("Local Docker daemon identity unavailable.");
                FileSdkOwnership.RecordIntent(lease.run.ToString("N"), lease.run.ToString("N"), lease.name, "redis:8-alpine", lease.daemon);
                await lease.container.StartAsync(lease.Token);
                lease.knownContainerId = lease.container.Id;
                FileSdkOwnership.RecordPublication(lease.run.ToString("N"), lease.knownContainerId, lease.daemon);
                lease.expected = Capture(await lease.docker.Containers.InspectContainerAsync(lease.container.Id, lease.Token));
                lease.Validate(lease.expected, running: true);
                lease.started = true;
                lease.WriteLedger("Started", admission.CandidateId);
                // Cleanup cannot dispose Docker or release allocation while startup owns publication.
                var connected = await ConnectionMultiplexer.ConnectAsync(
                    $"127.0.0.1:{lease.container.GetMappedPublicPort(6379)},abortConnect=true,connectTimeout=5000,connectRetry=0");
                lease.connection = connected;
                lease.Token.ThrowIfCancellationRequested();
                lease.consumerAdmitted = true;
            }
            finally { lease.startupSettled.TrySetResult(); }
            return lease;
        }
        catch (Exception failure)
        {
            checkpoints?.NoteFailure(FileStageCheckpoint.Stage.Startup, FileStageCheckpoint.FailureOrigin.StartupAction, failure);
            await ObserveStartupCleanupAsync(failure, async () =>
            {
                if (lease is not null) await lease.DisposeAsync();
                else AllocationSlot.Release();
            }, checkpoints);
            throw;
        }
    }

    private Task WatchdogAsync() => RunWatchdogAsync(lifetime.Token, finished.Token, CleanupOnceAsync);

    internal static async Task RunWatchdogAsync(CancellationToken lifetimeToken, CancellationToken finishedToken, Func<Task> cleanup)
    {
        using var signal = CancellationTokenSource.CreateLinkedTokenSource(lifetimeToken, finishedToken);
        try { await Task.Delay(Timeout.InfiniteTimeSpan, signal.Token); }
        catch (OperationCanceledException) when (signal.IsCancellationRequested) { }
        if (!finishedToken.IsCancellationRequested) await cleanup();
    }

    private Task CleanupOnceAsync()
    {
        lock (cleanupSync) return cleanup ??= CleanupAsync();
    }

    public ValueTask DisposeAsync()
    {
        lock (cleanupSync) return new ValueTask(disposal ??= checkpoints is null ? DisposeCoreAsync()
            : checkpoints.RunCleanupAsync(FileStageCheckpoint.Stage.ResourceDisposal, DisposeCoreAsync));
    }

    private async Task DisposeCoreAsync()
    {
        try
        {
            // The fixture calls disposal only after its HTTP producers have settled.
            consumerSettled.TrySetResult();
            finished.Cancel();
            lifetime.Cancel();
            await JoinCleanupAsync(CleanupOnceAsync, watchdog, checkpoints);
            if (quarantined) throw new InvalidOperationException("Owned Redis cleanup quarantined evidence; inspect its resource ledger.");
        }
        finally
        {
            // Unsettled work retains its token/handles for exact parent recovery.
            if (settlementVerified) { lifetime.Dispose(); finished.Dispose(); }
        }
    }

    internal enum CleanupSecondaryCategory { Other, Cancellation, InvalidOperation, Io, Timeout, Aggregate }
    internal const string StartupCleanupCategoryKey = "MALIEV.Redis.StartupCleanupCategory";
    internal const string WatchdogCleanupCategoryKey = "MALIEV.Redis.WatchdogCleanupCategory";

    private static void RecordCleanupSecondary(Exception primary, Exception secondary, string key)
    {
        var category = secondary switch
        {
            OperationCanceledException => CleanupSecondaryCategory.Cancellation,
            InvalidOperationException => CleanupSecondaryCategory.InvalidOperation,
            IOException => CleanupSecondaryCategory.Io,
            TimeoutException => CleanupSecondaryCategory.Timeout,
            AggregateException => CleanupSecondaryCategory.Aggregate,
            _ => CleanupSecondaryCategory.Other,
        };
        try { primary.Data[key] = category; }
        catch { /* Diagnostic failure cannot replace the original causal exception. */ }
    }

    internal static async Task ObserveStartupCleanupAsync(Exception initiatingFailure, Func<Task> cleanup,
        FileStageCheckpoint? checkpoints)
    {
        try { await cleanup(); }
        catch (Exception cleanupFailure)
        {
            RecordCleanupSecondary(initiatingFailure, cleanupFailure, StartupCleanupCategoryKey);
            checkpoints?.NoteFailure(FileStageCheckpoint.Stage.ResourceDisposal,
                FileStageCheckpoint.FailureOrigin.Action, cleanupFailure);
        }
    }

    internal static async Task JoinCleanupAsync(Func<Task> cleanupOnce, Task watchdogTask, FileStageCheckpoint? checkpoints)
    {
        System.Runtime.ExceptionServices.ExceptionDispatchInfo? primary = null;
        try
        {
            if (checkpoints is null) await cleanupOnce();
            else await checkpoints.ObserveCleanupAsync(FileStageCheckpoint.Stage.CleanupTask, cleanupOnce);
        }
        catch (Exception cleanupFailure)
        {
            primary = System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(cleanupFailure);
        }
        try
        {
            // Join the same owned task even when cleanup faulted; a pending watchdog
            // remains in custody and cannot be reported as released.
            if (checkpoints is null) await watchdogTask;
            else await checkpoints.ObserveCleanupAsync(FileStageCheckpoint.Stage.WatchdogJoin, () => watchdogTask);
        }
        catch (Exception watchdogFailure)
        {
            if (primary is null)
                primary = System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(watchdogFailure);
            else RecordCleanupSecondary(primary.SourceException, watchdogFailure, WatchdogCleanupCategoryKey);
        }
        primary?.Throw();
    }

    private async Task CleanupAsync()
    {
        using var cleanupDeadline = new CancellationTokenSource(TimeSpan.FromSeconds(30));
        var token = cleanupDeadline.Token; // Independent of the expired test/request token.
        try
        {
            // Expiry requests cancellation; it is not proof that startup or HTTP work stopped.
            Task SettleAsync() => AwaitSettlementAsync(startupSettled.Task,
                () => consumerAdmitted ? consumerSettled.Task : Task.CompletedTask, token);
            if (checkpoints is null) await SettleAsync();
            else await checkpoints.ObserveCleanupAsync(FileStageCheckpoint.Stage.ConsumerSettlement, SettleAsync);
            settlementVerified = true;
            if (connection is not null)
            {
                try { await connection.CloseAsync(false).WaitAsync(TimeSpan.FromSeconds(5)); }
                catch { /* Disposal and the fresh server client gate still execute. */ }
                try { connection.Dispose(); }
                catch { quarantined = true; Interlocked.Exchange(ref allocationQuarantined, 1); }
            }
            if (expected is null)
            {
                var matches = await docker.Containers.ListContainersAsync(new ContainersListParameters
                {
                    All = true,
                    Filters = new Dictionary<string, IDictionary<string, bool>>
                    {
                        ["label"] = new Dictionary<string, bool> { ["codex.run=" + run.ToString("N")] = true },
                    },
                }, token);
                if (matches.Count != 1) throw new InvalidOperationException("Startup resource identity is uncertain.");
                knownContainerId = matches[0].ID;
                expected = Capture(await docker.Containers.InspectContainerAsync(matches[0].ID, token));
            }
            if (daemon is null || (await docker.System.GetSystemInfoAsync(token)).ID != daemon)
                throw new InvalidOperationException("Docker daemon changed; cleanup ownership retained.");
            var current = Capture(await docker.Containers.InspectContainerAsync(expected.Id, token));
            Validate(current, running: current.Running);
            if (current.Running)
            {
                // The observer is itself one Redis client; any other reader/client blocks cleanup.
                var clients = await container.ExecAsync(["redis-cli", "--raw", "CLIENT", "LIST"], token);
                ValidateExclusiveClientProbe(clients.ExitCode, clients.Stderr, clients.Stdout);
                current = Capture(await docker.Containers.InspectContainerAsync(expected.Id, token));
                Validate(current, running: true);
                var lastClients = await container.ExecAsync(["redis-cli", "--raw", "CLIENT", "LIST"], token);
                ValidateExclusiveClientProbe(lastClients.ExitCode, lastClients.Stderr, lastClients.Stdout);
                // Stop returns only after Docker has stopped this exact container; never force-remove a running resource.
                await docker.Containers.StopContainerAsync(expected.Id, new ContainerStopParameters { WaitBeforeKillSeconds = 5 }, token);
                current = Capture(await docker.Containers.InspectContainerAsync(expected.Id, token));
                Validate(current, running: false);
            }
            await docker.Containers.RemoveContainerAsync(expected.Id,
                new ContainerRemoveParameters { Force = false, RemoveVolumes = false }, token);
            try
            {
                _ = await docker.Containers.InspectContainerAsync(expected.Id, token);
                throw new InvalidOperationException("Removed Redis container remains present.");
            }
            catch (DockerApiException exception) when (exception.StatusCode == HttpStatusCode.NotFound) { }
            var remaining = await docker.Containers.ListContainersAsync(new ContainersListParameters { All = true }, token);
            if (remaining.Any(item => item.ID == expected.Id || (item.Labels.TryGetValue("codex.run", out var value) && value == run.ToString("N"))))
                throw new InvalidOperationException("Owned Redis resource remains present.");
            FileSdkOwnership.RecordAbsence(run.ToString("N"));
            WriteLedger("Removed", null, quarantined ? "ConnectionDisposeUnverified" : null);
        }
        catch (Exception exception)
        {
            quarantined = true;
            Interlocked.Exchange(ref allocationQuarantined, 1);
            WriteLedger("Quarantined", null, exception.GetType().Name);
        }
        finally
        {
            if (settlementVerified)
            {
                try
                {
                    if (checkpoints is null) docker.Dispose();
                    else await checkpoints.ObserveCleanupAsync(FileStageCheckpoint.Stage.ClientRelease,
                        () => { docker.Dispose(); return Task.CompletedTask; });
                }
                finally
                {
                    if (checkpoints is null) AllocationSlot.Release();
                    else await checkpoints.ObserveCleanupAsync(FileStageCheckpoint.Stage.SlotRelease,
                        () => { AllocationSlot.Release(); return Task.CompletedTask; });
                }
            }
            // Otherwise retain handles and allocation quarantine until parent owner recovery.

        }
    }

    internal static async Task AwaitSettlementAsync(Task startup, Func<Task> consumer, CancellationToken token)
    {
        await startup.WaitAsync(token);
        await consumer().WaitAsync(token);
    }

    private void Validate(Snapshot current, bool running)
    {
        if (expected is null) throw new InvalidOperationException("Owned Redis identity was not captured.");
        ValidateResource(current, expected, labels, name, allocatedAfter, running, started);
        using var owner = Process.GetCurrentProcess();
        if (owner.Id.ToString(CultureInfo.InvariantCulture) != labels["codex.ownerPid"]
            || owner.StartTime.ToUniversalTime().ToString("O") != labels["codex.ownerStartUtc"])
            throw new InvalidOperationException("Owning process identity changed.");
    }

    internal static void ValidateResource(Snapshot current, Snapshot expected, IReadOnlyDictionary<string, string> labels,
        string name, DateTimeOffset allocatedAfter, bool running, bool started)
    {
        if (current.Id.Length != 64 || !current.Id.All(Uri.IsHexDigit) || current.Id != expected.Id || current.Image != expected.Image
            || current.CreatedUtc != expected.CreatedUtc || current.StartedAt != expected.StartedAt
            || current.Name != "/" + name || current.Running != running
            || (running && (current.Pid != expected.Pid || current.Pid <= 0))
            || labels.Any(item => !current.Labels.TryGetValue(item.Key, out var value) || value != item.Value)
            || current.CreatedUtc < allocatedAfter.AddSeconds(-2) || current.TmpfsTargets.Length != 1 || current.TmpfsTargets[0] != "/data"
            || current.Mounts.Length > 1 || current.Mounts.Any(mount => mount != "tmpfs:/data:::True") || !current.DeclaredLoopback
            || (running && !current.Mounts.SequenceEqual(expected.Mounts)) || current.ActiveExecCount != 0
            || (running && (current.PortBindings.Length != 1 || !current.PortBindings[0].StartsWith("127.0.0.1:", StringComparison.Ordinal)))
            || (started && running && !current.PortBindings.SequenceEqual(expected.PortBindings)))
            throw new InvalidOperationException("Owned Redis identity/mount/port evidence changed.");
    }

    private static Snapshot Capture(ContainerInspectResponse response) => new(
        response.ID, response.Image, new DateTimeOffset(response.Created.ToUniversalTime()), response.State.StartedAt,
        response.State.Pid, response.Name, response.State.Running, new Dictionary<string, string>(response.Config.Labels),
        response.Mounts.Select(mount => mount.Type + ":" + mount.Destination + ":" + (mount.Name ?? "") + ":" + (mount.Source ?? "") + ":" + mount.RW).ToArray(),
        response.NetworkSettings.Ports.Where(item => item.Key == "6379/tcp")
            .SelectMany(item => item.Value ?? []).Select(port => port.HostIP + ":" + port.HostPort).Order().ToArray(),
        response.HostConfig.PortBindings.TryGetValue("6379/tcp", out var declared)
            && declared.Count == 1 && declared[0].HostIP == "127.0.0.1"
            && response.HostConfig.Memory == 128L * 1024 * 1024 && response.HostConfig.MemorySwap == response.HostConfig.Memory
            && response.HostConfig.NanoCPUs == 500_000_000
            && response.HostConfig.Tmpfs.TryGetValue("/data", out var temporary) && temporary == "rw,size=64m",
        response.HostConfig.Tmpfs.Keys.Order().ToArray(), response.ExecIDs?.Count ?? 0);

    internal static void ValidateExclusiveClientProbe(long? exitCode, string stderr, string stdout)
    {
        var lines = stdout.Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        if (exitCode is not 0 || !string.IsNullOrWhiteSpace(stderr) || lines.Length != 1)
            throw new InvalidOperationException("Redis readers/clients are not quiescent.");
        var fields = lines[0].Split(' ', StringSplitOptions.RemoveEmptyEntries);
        if (!fields.Contains("cmd=client|list", StringComparer.Ordinal)
            || !fields.Any(value => value.StartsWith("addr=127.0.0.1:", StringComparison.Ordinal))
            || !fields.Any(value => value.StartsWith("id=", StringComparison.Ordinal)
                && long.TryParse(value.AsSpan(3), NumberStyles.None, CultureInfo.InvariantCulture, out var id) && id > 0))
            throw new InvalidOperationException("Redis client observation is malformed.");
    }

    private void WriteLedger(string state, string? candidate, string? failureCategory = null)
    {
        using var owner = Process.GetCurrentProcess();
        var body = JsonSerializer.Serialize(new
        {
            ownerTask = "File replay regression tests", run = run.ToString("N"), state, candidate = candidate ?? candidateIdentity, dockerEndpoint,
            ownerPid = owner.Id, ownerStartUtc = owner.StartTime.ToUniversalTime(), ownerExecutable = owner.MainModule?.FileName,
            container = expected, knownContainerId, expectedLabels = labels, finiteExpiryUtc = labels["codex.expiresUtc"],
            volumes = Array.Empty<string>(), persistentData = false, failureCategory,
        });
        File.WriteAllText(ledgerPath + ".tmp", body);
        File.Move(ledgerPath + ".tmp", ledgerPath, true);
    }

    private static Task<Admission> AdmitAsync()
    {
        if (AvailableMiB() < 4096) throw new InvalidOperationException("Owned Redis requires fresh available memory >=4096MiB.");
        var sdkOwner = FileSdkOwnership.Admission();
        using var current = Process.GetCurrentProcess();
        var record = new Admission(current.Id, current.StartTime.ToUniversalTime(), current.MainModule?.FileName ?? "",
            sdkOwner.SourceBinding, AssemblyDigest(), sdkOwner.Expires, true, "tests");
        ValidateAdmission(record, DateTimeOffset.UtcNow);
        return Task.FromResult(record);
    }

    internal static void ValidateAdmission(Admission? record, DateTimeOffset now)
    {
        if (record is null || !record.ExclusiveSlot || record.Phase != "tests" || record.ExpiresUtc <= now
            || record.ExpiresUtc > now.AddMinutes(30) || string.IsNullOrWhiteSpace(record.CandidateId)
            || record.TestAssemblySha256 != AssemblyDigest() || !IsOwnerAncestor(record.OwnerPid))
            throw new InvalidOperationException("Native owner lease is missing, expired or mismatched.");
        using var owner = Process.GetProcessById(record.OwnerPid);
        if (owner.HasExited || Math.Abs((owner.StartTime.ToUniversalTime() - record.OwnerStartUtc.UtcDateTime).TotalMilliseconds) >= 1
            || owner.MainModule?.FileName != record.OwnerExecutable)
            throw new InvalidOperationException("Native owner process identity changed.");
    }

    internal static string AssemblyDigest() => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(typeof(OwnedRedisLease).Assembly.Location)));
    private static DateTime ProcessStartUtc() { using var process = Process.GetCurrentProcess(); return process.StartTime.ToUniversalTime(); }

    private static bool IsOwnerAncestor(int ownerPid)
    {
        if (ownerPid <= 0) return false;
        var current = Environment.ProcessId;
        for (var depth = 0; depth < 32 && current > 0; depth++)
        {
            if (current == ownerPid) return true;
            if (OperatingSystem.IsLinux())
            {
                var stat = File.ReadAllText($"/proc/{current}/stat");
                current = int.Parse(stat[(stat.LastIndexOf(')') + 2)..].Split(' ')[1], CultureInfo.InvariantCulture);
            }
            else if (OperatingSystem.IsWindows())
            {
                using var process = Process.GetProcessById(current);
                var information = new ProcessBasicInformation();
                if (NtQueryInformationProcess(process.Handle, 0, ref information, Marshal.SizeOf<ProcessBasicInformation>(), out _) != 0) return false;
                current = information.ParentProcessId.ToInt32();
            }
            else return false;
        }
        return false;
    }

    private static ulong AvailableMiB()
    {
        if (OperatingSystem.IsLinux())
        {
            var line = File.ReadLines("/proc/meminfo").Single(value => value.StartsWith("MemAvailable:", StringComparison.Ordinal));
            return ulong.Parse(line.Split(' ', StringSplitOptions.RemoveEmptyEntries)[1], CultureInfo.InvariantCulture) / 1024;
        }
        if (OperatingSystem.IsWindows())
        {
            var status = new MemoryStatus { Length = (uint)Marshal.SizeOf<MemoryStatus>() };
            if (!GlobalMemoryStatusEx(ref status)) throw new InvalidOperationException("Memory admission unavailable.");
            return status.AvailablePhysical / (1024 * 1024);
        }
        throw new InvalidOperationException("Memory admission unavailable for this host.");
    }

    [SuppressMessage("Interoperability", "SYSLIB1054", Justification = "Marshal-backed Windows memory read avoids unsafe code in the test assembly.")]
    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GlobalMemoryStatusEx(ref MemoryStatus status);

    [SuppressMessage("Interoperability", "SYSLIB1054", Justification = "Marshal-backed process ancestry read avoids unsafe code in the test assembly.")]
    [DllImport("ntdll.dll")]
    private static extern int NtQueryInformationProcess(IntPtr process, int informationClass,
        ref ProcessBasicInformation information, int size, out int returnedSize);

    [StructLayout(LayoutKind.Sequential)]
    private struct ProcessBasicInformation
    {
        public IntPtr Reserved1;
        public IntPtr Peb;
        public IntPtr Reserved2;
        public IntPtr Reserved3;
        public IntPtr ProcessId;
        public IntPtr ParentProcessId;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct MemoryStatus
    {
        public uint Length;
        public uint MemoryLoad;
        public ulong TotalPhysical;
        public ulong AvailablePhysical;
        public ulong TotalPageFile;
        public ulong AvailablePageFile;
        public ulong TotalVirtual;
        public ulong AvailableVirtual;
        public ulong AvailableExtendedVirtual;
    }

    internal sealed record Admission(int OwnerPid, DateTimeOffset OwnerStartUtc, string OwnerExecutable,
        string CandidateId, string TestAssemblySha256, DateTimeOffset ExpiresUtc, bool ExclusiveSlot, string Phase);
    internal sealed record Snapshot(string Id, string Image, DateTimeOffset CreatedUtc, string StartedAt,
        long Pid, string Name, bool Running, Dictionary<string, string> Labels, string[] Mounts, string[] PortBindings, bool DeclaredLoopback, string[] TmpfsTargets, int ActiveExecCount);
}
