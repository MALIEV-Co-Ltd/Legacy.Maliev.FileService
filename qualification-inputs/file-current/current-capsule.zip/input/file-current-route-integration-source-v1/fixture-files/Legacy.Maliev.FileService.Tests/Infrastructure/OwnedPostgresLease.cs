using System.Net;
using Docker.DotNet;
using Docker.DotNet.Models;
using DotNet.Testcontainers.Configurations;
using Npgsql;
using Testcontainers.PostgreSql;

namespace Legacy.Maliev.FileService.Tests.Infrastructure;

internal sealed class OwnedPostgresLease(string parentRun, string imageTag = "postgres:18.1-bookworm") : IAsyncDisposable
{
    private const string Owner = "file-native-qualification-20261008";
    private readonly string name = "file-postgres-" + Guid.NewGuid().ToString("N");
    private readonly string run = Guid.NewGuid().ToString("N");
    private readonly DateTime admitted = DateTime.UtcNow;
    private DockerClientConfiguration? configuration;
    private DockerClient docker = null!;
    private PostgreSqlContainer container = null!;
    private Task? starting, disposal;
    private string? id, image, startedAt, mappedPort;
    private DateTime? created;
    private string? daemon;
    private bool absent;
    private bool uncertainCreation;
    internal bool IsAbsent => absent;
    internal string Run => run;

    public static async Task<OwnedPostgresLease> StartAsync()
    {
        _ = FileSdkOwnership.Check(); // Before Docker client/builder acquisition.
        var lease = new OwnedPostgresLease(Guid.NewGuid().ToString("N"), "postgres:18-alpine");
        try
        {
            lease.Prepare();
            using var startup = new CancellationTokenSource(TimeSpan.FromSeconds(30));
            await lease.StartAsync(startup.Token);
            return lease;
        }
        catch (Exception failure)
        {
            try { await lease.DisposeAsync(); }
            catch (Exception cleanup) { throw new AggregateException(failure, cleanup); }
            throw;
        }
    }

    public async ValueTask DisposeAsync()
    {
        using var cleanup = new CancellationTokenSource(TimeSpan.FromSeconds(30));
        await RemoveAfterQuiescenceAsync(cleanup.Token);
        ReleaseClient();
    }

    internal void Prepare()
    {
        if (imageTag is not ("postgres:18.1-bookworm" or "postgres:18-alpine"))
            throw new InvalidOperationException("Unreviewed PostgreSQL image profile.");
        var endpoint = OperatingSystem.IsWindows() ? "npipe://./pipe/docker_engine" : "unix:///var/run/docker.sock";
        configuration = new DockerClientConfiguration(new Uri(endpoint));
        docker = configuration.CreateClient();
        container = new PostgreSqlBuilder(imageTag)
            .WithDockerEndpoint(endpoint).WithName(name).WithCleanUp(false)
            .WithLabel("maliev.codex.owner", Owner).WithLabel("maliev.codex.run", run)
            .WithLabel("maliev.codex.parent-run", parentRun)
            .WithLabel("maliev.codex.sdk-run", FileSdkOwnership.RunId)
            .WithLabel("maliev.codex.expires-utc", admitted.AddSeconds(600).ToString("O"))
            .WithLabel("maliev.codex.persistent-data", "false")
            .WithEnvironment("PGDATA", "/var/lib/postgresql/18/docker")
            .WithCommand(new OverwriteEnumerable<string>(["postgres", "-c", "statement_timeout=15000", "-c", "idle_in_transaction_session_timeout=15000"]))
            .WithCreateParameterModifier(parameters =>
            {
                parameters.HostConfig!.Memory = 512L * 1024 * 1024;
                parameters.HostConfig.MemorySwap = 512L * 1024 * 1024;
                parameters.HostConfig.NanoCPUs = 1000000000;
                parameters.HostConfig.Tmpfs = new Dictionary<string, string> { ["/var/lib/postgresql"] = "rw,size=384m" };
                foreach (var bindings in parameters.HostConfig.PortBindings.Values)
                    foreach (var binding in bindings) binding.HostIP = "127.0.0.1";
            }).Build();
    }

    internal string Connection(string database) => new NpgsqlConnectionStringBuilder(container.GetConnectionString())
    {
        Database = database, Pooling = false, Timeout = 5, CommandTimeout = 15,
    }.ConnectionString;

    internal async Task StartAsync(CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        daemon = (await docker.System.GetSystemInfoAsync(cancellationToken)).ID;
        if (string.IsNullOrWhiteSpace(daemon)) throw new InvalidOperationException("Local Docker daemon identity unavailable.");
        cancellationToken.ThrowIfCancellationRequested();
        FileSdkOwnership.RecordIntent(parentRun, run, name, imageTag, daemon);
        // Keep the actual task, including a canceled waiting wrapper, until it genuinely settles.
        var reservation = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        starting = reservation.Task;
        var dispatched = false;
        try
        {
            cancellationToken.ThrowIfCancellationRequested();
            dispatched = true;
            await container.StartAsync(cancellationToken);
            reservation.TrySetResult();
        }
        catch (Exception failure) { uncertainCreation = dispatched; reservation.TrySetException(failure); throw; }
        var receipt = await InspectAsync(cancellationToken);
        if (receipt is null || !receipt.State.Running) throw new InvalidOperationException("Owned PostgreSQL is not ready.");
    }

    private async Task<ContainerInspectResponse?> InspectAsync(CancellationToken cancellationToken)
    {
        if (daemon is null)
        {
            if (starting is null) { absent = true; return null; }
            throw new InvalidOperationException("Unknown daemon retains container ownership.");
        }
        if ((await docker.System.GetSystemInfoAsync(cancellationToken)).ID != daemon)
            throw new InvalidOperationException("Docker daemon changed; destructive cleanup refused.");
        if (id is null)
        {
            // Reconcile uncertain Create acknowledgement using only the pre-registered UUID intent.
            var candidates = await docker.Containers.ListContainersAsync(new ContainersListParameters
            {
                All = true,
                Filters = new Dictionary<string, IDictionary<string, bool>> { ["name"] = new Dictionary<string, bool> { [name] = true } },
            }, cancellationToken);
            var exact = candidates.Where(item => item.Names.Contains("/" + name)).ToArray();
            if (exact.Length == 0)
            {
                if (uncertainCreation) throw new InvalidOperationException("Unacknowledged Create may still publish its UUID intent; ownership retained.");
                absent = true;
                return null;
            }
            if (exact.Length != 1) throw new InvalidOperationException("Uncertain container intent is ambiguous.");
            id = exact[0].ID;
        }
        ContainerInspectResponse value;
        try { value = await docker.Containers.InspectContainerAsync(id, cancellationToken); }
        catch (DockerApiException failure) when (failure.StatusCode == HttpStatusCode.NotFound) { absent = true; return null; }
        ValidateIdentity(value);
        if (!value.Config.Labels.TryGetValue("maliev.codex.sdk-run", out var sdkRun) || sdkRun != FileSdkOwnership.RunId)
            throw new InvalidOperationException("PostgreSQL belongs to a different SDK run.");
        FileSdkOwnership.RecordPublication(run, id!, daemon);
        if (value.State.Running)
        {
            var currentPort = value.NetworkSettings.Ports["5432/tcp"].Single().HostPort;
            if (mappedPort is not null && mappedPort != currentPort) throw new InvalidOperationException("Owned PostgreSQL mapped port changed.");
            mappedPort = currentPort;
        }
        created ??= value.Created;
        image ??= value.Image;
        if (!string.IsNullOrWhiteSpace(value.State.StartedAt) && value.State.StartedAt != "0001-01-01T00:00:00Z")
        {
            if (startedAt is not null && startedAt != value.State.StartedAt) throw new InvalidOperationException("Owned container was restarted.");
            startedAt = value.State.StartedAt;
        }
        return value;
    }

    internal void ValidateIdentity(ContainerInspectResponse value) =>
        FilePostgresContainerIdentity.Validate(value, new FilePostgresContainerExpectation(id, name, run, parentRun, admitted, created, image, imageTag));

    public async Task RemoveAfterQuiescenceAsync(CancellationToken cancellationToken)
    {
        if (starting is { IsCompleted: false })
            await starting.WaitAsync(cancellationToken);
        if (starting is { IsFaulted: true }) _ = starting.Exception;
        var receipt = await InspectAsync(cancellationToken);
        if (receipt is not null)
        {
            if (receipt.State.Running)
            {
                // Refuse teardown while any dependent PostgreSQL client remains, even idle.
                await using var connection = new NpgsqlConnection(Connection("postgres"));
                await connection.OpenAsync(cancellationToken);
                await using var command = connection.CreateCommand();
                command.CommandText = "SELECT COUNT(*) FROM pg_stat_activity WHERE backend_type='client backend' AND pid<>pg_backend_pid()";
                if (await command.ExecuteScalarAsync(cancellationToken) is not long clients || clients != 0)
                    throw new InvalidOperationException("PostgreSQL clients remain; backend retained.");
            }
            // The scope has already settled every frontend acquisition and host/context.
            receipt = await InspectAsync(cancellationToken);
            if (receipt is not null)
            {
                if (receipt.State.Running)
                    await docker.Containers.StopContainerAsync(id!, new ContainerStopParameters { WaitBeforeKillSeconds = 10 }, cancellationToken);
                var stopped = await InspectAsync(cancellationToken);
                if (stopped is not null && stopped.State.Running) throw new InvalidOperationException("Exact owned PostgreSQL has not stopped.");
                if (stopped is not null)
                    await docker.Containers.RemoveContainerAsync(id!, new ContainerRemoveParameters { Force = false, RemoveVolumes = false }, cancellationToken);
            }
        }
        if (await InspectAsync(cancellationToken) is not null || !absent)
            throw new InvalidOperationException("Exact-ID physical absence was not proven.");
        if (daemon is not null) FileSdkOwnership.RecordAbsence(run);
        if (container is not null)
        {
            disposal ??= container.DisposeAsync().AsTask();
            await disposal.WaitAsync(cancellationToken);
        }
    }

    public void ReleaseClient()
    {
        if (!absent) throw new InvalidOperationException("Docker ownership cannot be released before exact absence.");
        try { if (docker is not null) docker.Dispose(); }
        finally { configuration?.Dispose(); }
    }
}

internal sealed record FilePostgresContainerExpectation(string? Id, string Name, string Run, string ParentRun, DateTime Admitted, DateTime? Created, string? Image, string ImageTag = "postgres:18.1-bookworm");

internal static class FilePostgresContainerIdentity
{
    internal static void Validate(ContainerInspectResponse value, FilePostgresContainerExpectation expected)
    {
        var labels = value.Config.Labels;
        if (value.ID != expected.Id || value.Name != "/" + expected.Name || value.Created < expected.Admitted.AddSeconds(-5)
            || value.Created > expected.Admitted.AddSeconds(2700) || expected.Created is not null && value.Created != expected.Created
            || expected.Image is not null && value.Image != expected.Image
            || !labels.TryGetValue("maliev.codex.owner", out var owner) || owner != "file-native-qualification-20261008"
            || !labels.TryGetValue("maliev.codex.run", out var actualRun) || actualRun != expected.Run
            || !labels.TryGetValue("maliev.codex.parent-run", out var actualParent) || actualParent != expected.ParentRun
            || !labels.TryGetValue("maliev.codex.expires-utc", out var expiry) || expiry != expected.Admitted.AddSeconds(600).ToString("O")
            || !labels.TryGetValue("maliev.codex.persistent-data", out var persistent) || persistent != "false")
            throw new InvalidOperationException("Exact container birth/ownership identity mismatch.");
        if (value.HostConfig.Memory != 512L * 1024 * 1024 || value.HostConfig.MemorySwap != value.HostConfig.Memory
            || value.HostConfig.NanoCPUs != 1000000000
            || value.HostConfig.Tmpfs.Count != 1
            || !value.HostConfig.Tmpfs.TryGetValue("/var/lib/postgresql", out var options) || options != "rw,size=384m"
            || value.Mounts.Count > 1
            || value.Mounts.Any(mount => mount.Type != "tmpfs" || mount.Destination != "/var/lib/postgresql"))
            throw new InvalidOperationException("Owned PostgreSQL storage/caps mismatch.");
        if (value.HostConfig.PortBindings.Count != 1 || !value.HostConfig.PortBindings.TryGetValue("5432/tcp", out var ports)
            || ports.Count != 1 || ports[0].HostIP != "127.0.0.1")
            throw new InvalidOperationException("PostgreSQL must be loopback-only.");
        if (expected.ImageTag is not ("postgres:18.1-bookworm" or "postgres:18-alpine") || value.Config.Image != expected.ImageTag)
            throw new InvalidOperationException("PostgreSQL image variant changed.");
        if (value.State.Running && (!value.NetworkSettings.Ports.TryGetValue("5432/tcp", out var mapped) || mapped is null || mapped.Count != 1
            || mapped[0].HostIP != "127.0.0.1" || !int.TryParse(mapped[0].HostPort, out var actualPort) || actualPort is < 1 or > 65535))
            throw new InvalidOperationException("Running PostgreSQL lacks its exact tmpfs/loopback readiness binding.");
        if (value.Config.Cmd is null || !value.Config.Cmd.SequenceEqual(new[]
            { "postgres", "-c", "statement_timeout=15000", "-c", "idle_in_transaction_session_timeout=15000" })
            || value.ExecIDs is { Count: > 0 })
            throw new InvalidOperationException("PostgreSQL command or active executor differs.");
        if (value.Config.Env.SingleOrDefault(item => item.StartsWith("PGDATA=", StringComparison.Ordinal)) != "PGDATA=/var/lib/postgresql/18/docker")
            throw new InvalidOperationException("Unreviewed PG18 storage directory.");
    }
}
