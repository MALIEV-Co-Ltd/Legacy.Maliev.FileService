using System.Text.Json;

namespace Legacy.Maliev.FileService.Tests.Infrastructure;

// Fixed local test progress only: no input strings, payloads, environment or exception text.
internal sealed class FileStageCheckpoint
{
    internal enum Case { PostgreSqlFixture, RedisStoreFixture, ReplayPrincipal, LiteralKeyedPrefix }
    internal enum Stage { Startup, Database, HostClient, Request, Response, HostDisposal, ConsumerSettlement, ResourceDisposal, CleanupTask, WatchdogJoin, ClientRelease, SlotRelease, FactoryConstruction, ServicesScope, RedisSeed, RedisRead, RedisWrite, StartupReturn, LinkedTokenAcquisition, ConnectionAcquisition, ReplayOlderDatabase, ReplayNoncanonicalDatabase, ReplayCanonicalDatabase, MigrationActionReturn, MigrationCallerReturn }
    internal enum State { Entered, Completed, Failed }
    internal enum FailureOrigin { None, Action, StartupAction, AcquiredCompletionRecording }
    internal enum FailureCategory { None, Cancellation, RedisConnection, RedisTimeout, InvalidOperation, Io, Other }
    internal const int MaximumCases = 512;
    internal const int MaximumEvents = 64;
    internal const int MaximumBytes = 16384;
    private static readonly object AllocationLock = new();
    private readonly object sync = new();
    private readonly List<Entry> entries = [];
    private readonly Case caseId;
    private readonly string instance;
    private readonly string owner;
    private readonly Action<byte[]> persist;
    // Separate bounded categorical failure evidence; existing six-field events remain unchanged.
    internal enum ExceptionKind { Other, Cancellation, RedisConnection, RedisTimeout, InvalidOperation, Io, OutOfMemory, ThreadStart, TypeInitialization, TargetInvocation, Aggregate, Socket, Timeout }
    internal enum Relation { Root, Inner, AggregateChild }
    internal sealed record FailureNode(int Index, int Parent, Relation Relation, ExceptionKind Kind);
    internal sealed record FailureTree(FailureNode[] Nodes, bool Truncated);
    internal const int MaximumFailureNodes = 12;
    internal const int MaximumFailureDepth = 4;
    private readonly Action<byte[]>? persistFailure;
    private bool failureAttempted;
    private Exception? firstRecordingFailure;
    private bool primaryActionFailed;
    private sealed record Entry(int Sequence, Stage Stage, State State, DateTimeOffset Utc, FailureOrigin Origin, FailureCategory Category);

    internal FileStageCheckpoint(Case caseId, string instance, string owner, Action<byte[]> persist, Action<byte[]>? persistFailure = null)
    {
        if (!Enum.IsDefined(caseId) || !Guid.TryParseExact(instance, "N", out _) || !Guid.TryParseExact(owner, "N", out _))
            throw new InvalidOperationException("Invalid closed checkpoint identity.");
        this.caseId = caseId; this.instance = instance; this.owner = owner; this.persist = persist; this.persistFailure = persistFailure;
    }

    internal static FileStageCheckpoint Create(Case caseId)
    {
        var admitted = FileSdkOwnership.Check();
        var instance = Guid.NewGuid().ToString("N");
        var directory = Path.Combine(admitted.Root, "test-stages");
        var path = Reserve(directory, instance);
        // One sibling snapshot per case, in a separate directory so the case census stays unchanged.
        string? failurePath = null;
        return new(caseId, instance, admitted.Run, bytes => PersistAtomic(path, bytes), bytes =>
        {
            failurePath ??= Reserve(Path.Combine(admitted.Root, "test-failures"), instance);
            PersistAtomic(failurePath, bytes);
        });
    }

    internal static void PersistAtomic(string path, byte[] bytes, Action<FileStream, byte[]>? write = null,
        Action<FileStream>? flush = null, Action<string, string>? replace = null)
    {
        if (bytes.Length > MaximumBytes || new FileInfo(path).LinkTarget is not null
            || new DirectoryInfo(Path.GetDirectoryName(path)!).LinkTarget is not null)
            throw new InvalidOperationException("Checkpoint file identity or byte bound failed.");
        // One fixed same-directory staging file per reserved case, never modify the committed snapshot.
        var pending = path + ".pending";
        var created = false;
        Exception? originalFailure = null;
        try
        {
            using (var stream = new FileStream(pending, FileMode.CreateNew, FileAccess.Write, FileShare.None,
                4096, FileOptions.WriteThrough))
            {
                created = true;
                if (write is null) stream.Write(bytes); else write(stream, bytes);
                if (flush is null) stream.Flush(flushToDisk: true); else flush(stream);
            }
            if (replace is null) File.Replace(pending, path, destinationBackupFileName: null); else replace(pending, path);
        }
        catch (Exception failure) { originalFailure = failure; throw; }
        finally
        {
            // Never remove a pre-existing/foreign staging file after exclusive creation failed.
            try { if (created && File.Exists(pending)) File.Delete(pending); }
            catch when (originalFailure is not null) { /* Keep the causal writer failure and bounded pending evidence. */ }
        }
    }

    internal static string Reserve(string directory, string instance)
    {
        if (!Guid.TryParseExact(instance, "N", out _)) throw new InvalidOperationException("Invalid fixed checkpoint filename.");
        lock (AllocationLock)
        {
            Directory.CreateDirectory(directory);
            if (new DirectoryInfo(directory).LinkTarget is not null
                || Directory.EnumerateFileSystemEntries(directory).Take(MaximumCases + 1).Count() >= MaximumCases)
                throw new InvalidOperationException("Checkpoint directory identity or case bound failed.");
            var path = Path.Combine(directory, instance + ".json");
            using var reserved = new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.Read);
            return path;
        }
    }

    internal void Record(Stage stage, State state, FailureOrigin origin = FailureOrigin.None, FailureCategory category = FailureCategory.None)
    {
        lock (sync)
        {
            try
            {
                if (!Enum.IsDefined(stage) || !Enum.IsDefined(state) || !Enum.IsDefined(origin) || !Enum.IsDefined(category)
                    || (origin == FailureOrigin.None) != (category == FailureCategory.None)
                    || (origin != FailureOrigin.None && state != State.Failed)
                    || entries.Count >= MaximumEvents)
                    throw new InvalidOperationException("Checkpoint closed schema or event bound failed.");
                var proposed = entries.Append(new Entry(entries.Count + 1, stage, state, DateTimeOffset.UtcNow, origin, category)).ToArray();
                var bytes = JsonSerializer.SerializeToUtf8Bytes(new { schemaVersion = 1, owner, instance, caseId, events = proposed });
                if (bytes.Length > MaximumBytes) throw new InvalidOperationException("Checkpoint byte bound failed.");
                persist(bytes);
                entries.Add(proposed[^1]);
            }
            catch (Exception failure)
            {
                firstRecordingFailure ??= failure; // One bounded causal failure; later successful writes never erase it.
                throw;
            }
        }
    }

    internal T Run<T>(Stage stage, Func<T> action)
    {
        if (typeof(IAsyncDisposable).IsAssignableFrom(typeof(T)) && !typeof(IDisposable).IsAssignableFrom(typeof(T)))
            throw new InvalidOperationException("Async-only acquisitions require the async checkpoint wrapper.");
        Record(stage, State.Entered); // Persist before entering a possibly blocked synchronous operation.
        T result;
        try { result = action(); }
        catch (Exception failure) { NoteFailure(stage, FailureOrigin.Action, failure); throw; } // Preserve the original action failure.
        try { Record(stage, State.Completed); }
        catch (Exception failure)
        {
            NoteFailure(stage, FailureOrigin.AcquiredCompletionRecording, failure);
            try { if (result is IDisposable disposable) disposable.Dispose(); }
            catch { /* Preserve the original persistence failure; parent custody remains authoritative. */ }
            throw;
        }
        return result;
    }

    internal async Task<T> RunAsync<T>(Stage stage, Func<Task<T>> action)
    {
        Record(stage, State.Entered);
        T result;
        try { result = await action(); }
        catch (Exception failure) { NoteFailure(stage, FailureOrigin.Action, failure); throw; }
        try { Record(stage, State.Completed); }
        catch (Exception failure)
        {
            NoteFailure(stage, FailureOrigin.AcquiredCompletionRecording, failure);
            try
            {
                if (result is IAsyncDisposable asynchronous) await asynchronous.DisposeAsync();
                else if (result is IDisposable disposable) disposable.Dispose();
            }
            catch { /* Preserve the original persistence failure; parent custody remains authoritative. */ }
            throw;
        }
        return result;
    }

    internal async Task RunAsync(Stage stage, Func<Task> action)
    {
        Record(stage, State.Entered);
        try { await action(); }
        catch (Exception failure) { NoteFailure(stage, FailureOrigin.Action, failure); throw; }
        Record(stage, State.Completed);
    }

    internal async Task RunCleanupAsync(Stage stage, Func<Task> action)
    {
        try { Record(stage, State.Entered); }
        catch { /* Sticky recording failure is surfaced only after cleanup. */ }
        try { await action(); } // Evidence failure must never suppress actual cleanup.
        catch (Exception failure) { NoteFailure(stage, FailureOrigin.Action, failure); throw; }
        try { Record(stage, State.Completed); }
        catch { /* Sticky recording failure is surfaced only after cleanup. */ }
        Exception? recordingFailure;
        lock (sync) recordingFailure = primaryActionFailed ? null : firstRecordingFailure;
        if (recordingFailure is not null)
            System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(recordingFailure).Throw();
    }

    internal async Task ObserveCleanupAsync(Stage stage, Func<Task> action)
    {
        // This observer surrounds one gate inside an enclosing cleanup, so evidence faults must
        // not interrupt subsequent connection/container cleanup or the settlement assignment.
        try { Record(stage, State.Entered); }
        catch { /* Enclosing cleanup and final parent receipts remain authoritative. */ }
        try { await action(); }
        catch (Exception failure) { NoteFailure(stage, FailureOrigin.Action, failure); throw; }
        try { Record(stage, State.Completed); }
        catch { /* Cleanup proceeds even when completed evidence cannot be persisted. */ }
    }

    internal static FailureTree DescribeFailure(Exception failure)
    {
        var nodes = new List<FailureNode>();
        var seen = new HashSet<Exception>(ReferenceEqualityComparer.Instance);
        var truncated = false;
        var visits = 0;
        void Visit(Exception current, int parent, Relation relation, int depth)
        {
            if (depth > MaximumFailureDepth || visits >= MaximumFailureNodes)
            { truncated = true; return; }
            visits++;
            if (!seen.Add(current))
            { truncated = true; return; }
            var index = nodes.Count;
            var kind = current switch
            {
                OutOfMemoryException => ExceptionKind.OutOfMemory,
                System.Threading.ThreadStartException => ExceptionKind.ThreadStart,
                TypeInitializationException => ExceptionKind.TypeInitialization,
                System.Reflection.TargetInvocationException => ExceptionKind.TargetInvocation,
                AggregateException => ExceptionKind.Aggregate,
                OperationCanceledException => ExceptionKind.Cancellation,
                StackExchange.Redis.RedisConnectionException => ExceptionKind.RedisConnection,
                StackExchange.Redis.RedisTimeoutException => ExceptionKind.RedisTimeout,
                System.Net.Sockets.SocketException => ExceptionKind.Socket,
                TimeoutException => ExceptionKind.Timeout,
                InvalidOperationException => ExceptionKind.InvalidOperation,
                IOException => ExceptionKind.Io,
                _ => ExceptionKind.Other,
            };
            nodes.Add(new(index, parent, relation, kind));
            if (current is AggregateException aggregate)
            {
                foreach (var child in aggregate.InnerExceptions)
                {
                    if (visits >= MaximumFailureNodes) { truncated = true; break; }
                    Visit(child, index, Relation.AggregateChild, depth + 1);
                }
            }
            else if (current.InnerException is { } inner) Visit(inner, index, Relation.Inner, depth + 1);
        }
        Visit(failure, -1, Relation.Root, 0);
        return new(nodes.ToArray(), truncated);
    }

    internal void NoteFailure(Stage stage, FailureOrigin origin, Exception failure)
    {
        if (origin is FailureOrigin.Action or FailureOrigin.StartupAction)
            lock (sync) primaryActionFailed = true;
        var category = failure switch
        {
            OperationCanceledException => FailureCategory.Cancellation,
            StackExchange.Redis.RedisConnectionException => FailureCategory.RedisConnection,
            StackExchange.Redis.RedisTimeoutException => FailureCategory.RedisTimeout,
            InvalidOperationException => FailureCategory.InvalidOperation,
            IOException => FailureCategory.Io,
            _ => FailureCategory.Other,
        };
        // Retain the first causal relation; a later watchdog cancellation must not overwrite it.
        // Diagnostic faults cannot replace the primary failure or suppress cleanup.
        try
        {
            lock (sync)
            {
                if (persistFailure is not null && !failureAttempted
                    && Enum.IsDefined(stage) && Enum.IsDefined(origin) && origin != FailureOrigin.None)
                {
                    failureAttempted = true; // Even an unavailable first receipt must not become a later cause.
                    var tree = DescribeFailure(failure);
                    var bytes = JsonSerializer.SerializeToUtf8Bytes(new
                    {
                        schemaVersion = 1, owner, instance, caseId, stage, origin,
                        sequence = 1, utc = DateTimeOffset.UtcNow,
                        processId = Environment.ProcessId, tree,
                    });
                    if (bytes.Length > MaximumBytes) throw new InvalidOperationException("Failure evidence exceeds its byte bound.");
                    persistFailure(bytes);
                }
            }
        }
        catch { /* The original exception and original stage writer remain authoritative. */ }
        try { Record(stage, State.Failed, origin, category); }
        catch { /* Retain original failure and the last successfully persisted checkpoint. */ }
    }
}
