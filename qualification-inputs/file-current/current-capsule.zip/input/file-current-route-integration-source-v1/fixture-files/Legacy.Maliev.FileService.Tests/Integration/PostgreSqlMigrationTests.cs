using Legacy.Maliev.FileService.Tests.Infrastructure;
using Legacy.Maliev.FileService.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.EntityFrameworkCore.Migrations.Operations;

namespace Legacy.Maliev.FileService.Tests.Integration;

[CollectionDefinition(Name)]
public sealed class PostgreSqlCollection : ICollectionFixture<PostgreSqlFixture>
{
    public const string Name = "FilePostgreSQL";
}

public sealed class PostgreSqlFixture : IAsyncLifetime
{
    private OwnedPostgresLease? container;

    public async Task InitializeAsync() => container = await OwnedPostgresLease.StartAsync();

    public async Task DisposeAsync() { if (container is not null) await container.DisposeAsync(); }

    public FileDbContext CreateContext()
    {
        var options = new DbContextOptionsBuilder<FileDbContext>().UseNpgsql(container!.Connection("postgres")).Options;
        return new FileDbContext(options);
    }
}

[Collection(PostgreSqlCollection.Name)]
public sealed class PostgreSqlMigrationTests(PostgreSqlFixture fixture)
{
    private const string InitialMigration = "20260715033302_InitialPostgresCompatibility";
    private const string InstantQuoteMigration = "20260719033405_AddInstantQuoteUploadWorkflow";
    private const string StorageMoveMigration = "20260929015203_AddStorageMoveJournal";
    private const string QuarantineIntentMigration = "20261001023704_AddQuarantineUploadIntent";
    private const string SizeNullabilityMigration = "20261006070500_RestoreLegacyUploadSizeNullability";

    private const string ReferenceNullabilityMigration = "20261006073000_RestoreLegacyUploadReferenceNullability";

    [Fact]
    public async Task InitialMigration_FreshPostgreSql_CreatesLegacyUploadTableWithoutCustomXmin()
    {
        await using var context = fixture.CreateContext();

        await context.Database.MigrateAsync();

        await context.Database.OpenConnectionAsync();
        await using var command = context.Database.GetDbConnection().CreateCommand();
        command.CommandText = """
            SELECT COUNT(*)
            FROM information_schema.columns
            WHERE table_schema = 'public'
              AND table_name = 'Upload'
              AND column_name IN ('ID', 'Bucket', 'ContentType', 'Name', 'Size', 'CreatedDate', 'ModifiedDate');
            """;
        var columnCount = Convert.ToInt32(await command.ExecuteScalarAsync(), System.Globalization.CultureInfo.InvariantCulture);
        Assert.Equal(7, columnCount);

        command.CommandText = "SELECT xmin FROM \"Upload\" LIMIT 0;";
        await command.ExecuteNonQueryAsync();

        command.CommandText = """
            SELECT COUNT(*)
            FROM information_schema.columns
            WHERE table_schema = 'public'
              AND ((table_name = 'InstantQuoteFinalization' AND column_name = 'QuotationRequestId')
                OR (table_name = 'InstantQuoteUploadFile' AND column_name = 'FinalizedQuotationRequestId'))
              AND data_type = 'integer';
            """;
        var integerAuthorityColumns = Convert.ToInt32(
            await command.ExecuteScalarAsync(),
            System.Globalization.CultureInfo.InvariantCulture);
        Assert.Equal(2, integerAuthorityColumns);

        command.CommandText = """
            SELECT COUNT(*)
            FROM information_schema.columns
            WHERE table_schema = 'public'
              AND table_name = 'InstantQuoteUploadFile'
              AND column_name = 'TemporaryCleanupCompleted'
              AND data_type = 'boolean'
              AND column_default = 'false';
            """;
        var cleanupColumnCount = Convert.ToInt32(
            await command.ExecuteScalarAsync(),
            System.Globalization.CultureInfo.InvariantCulture);
        Assert.Equal(1, cleanupColumnCount);
    }

    [Fact]
    public void MigrationInventory_ContainsReviewedAdditiveMigrations()
    {
        using var context = fixture.CreateContext();
        var migrations = context.GetService<IMigrationsAssembly>().Migrations.Keys.ToArray();

        // Inventory only: actual Up/shape/rollback/retention/model tests establish behavior.
        Assert.Equal([InitialMigration, InstantQuoteMigration, StorageMoveMigration, QuarantineIntentMigration, SizeNullabilityMigration, ReferenceNullabilityMigration], migrations);
    }

    [Fact]
    public void InstantQuoteMigration_UpOperations_AreAdditiveWithoutDataTransformsOrCustomXmin()
    {
        using var context = fixture.CreateContext();
        var assembly = context.GetService<IMigrationsAssembly>();
        var migrationType = assembly.Migrations[InstantQuoteMigration];
        var migration = assembly.CreateMigration(migrationType, context.Database.ProviderName!);

        Assert.DoesNotContain(migration.UpOperations, operation => operation is DropColumnOperation
            or DropTableOperation
            or AlterColumnOperation
            or SqlOperation);

        var createdColumns = migration.UpOperations
            .OfType<CreateTableOperation>()
            .SelectMany(operation => operation.Columns)
            .ToArray();
        Assert.DoesNotContain(createdColumns, column => string.Equals(column.Name, "xmin", StringComparison.OrdinalIgnoreCase));
    }

    [Fact]
    public async Task InstantQuoteMigration_HistoricalRollbackThenUp_PreservesOriginalWorkflowSchemaContract()
    {
        await using var context = fixture.CreateContext();
        await ResetSchemaAsync(context);
        try
        {
            var migrator = context.GetService<IMigrator>();
            await migrator.MigrateAsync(InstantQuoteMigration);
            await migrator.MigrateAsync(InitialMigration);
            Assert.False(await TableExistsAsync(context, "InstantQuoteUploadSession"));

            await migrator.MigrateAsync(InstantQuoteMigration);

            Assert.True(await TableExistsAsync(context, "InstantQuoteUploadSession"));
            Assert.True(await TableExistsAsync(context, "InstantQuoteUploadFile"));
            Assert.True(await TableExistsAsync(context, "InstantQuoteFinalization"));
            Assert.False(await TableExistsAsync(context, "StorageMoveJournal"));
            Assert.False(await TableExistsAsync(context, "QuarantineUploadIntent"));
            Assert.False(context.Database.HasPendingModelChanges());
        }
        finally
        {
            await context.Database.CloseConnectionAsync();
            await ResetSchemaAsync(context);
        }
    }

    private static async Task<bool> TableExistsAsync(FileDbContext context, string tableName)
    {
        await context.Database.OpenConnectionAsync();
        await using var command = context.Database.GetDbConnection().CreateCommand();
        command.CommandText = "SELECT to_regclass(@table_name) IS NOT NULL;";
        var parameter = command.CreateParameter();
        parameter.ParameterName = "table_name";
        parameter.Value = $"public.\"{tableName}\"";
        command.Parameters.Add(parameter);
        return (bool)(await command.ExecuteScalarAsync())!;
    }

    private static Task ResetSchemaAsync(FileDbContext context) =>
        context.Database.ExecuteSqlRawAsync("DROP SCHEMA IF EXISTS public CASCADE; CREATE SCHEMA public;");
}
